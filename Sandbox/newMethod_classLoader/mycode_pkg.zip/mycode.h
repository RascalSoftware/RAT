//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: mycode.h
//
// MATLAB Coder version            : 5.0
// C/C++ source code generated on  : 08-Jan-2021 10:39:07
//
#ifndef MYCODE_H
#define MYCODE_H

// Include Files
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "mycode_types.h"

// Type Definitions
#include "myclass.h"

// Function Declarations
extern int mycode();

#endif

//
// File trailer for mycode.h
//
// [EOF]
//

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: mycode_initialize.cpp
//
// MATLAB Coder version            : 5.0
// C/C++ source code generated on  : 08-Jan-2021 10:39:07
//

// Include Files
#include "mycode_initialize.h"
#include "mycode.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void mycode_initialize()
{
}

//
// File trailer for mycode_initialize.cpp
//
// [EOF]
//

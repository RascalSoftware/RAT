//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: mycode_terminate.cpp
//
// MATLAB Coder version            : 5.0
// C/C++ source code generated on  : 08-Jan-2021 10:39:07
//

// Include Files
#include "mycode_terminate.h"
#include "mycode.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void mycode_terminate()
{
  // (no terminate code required)
}

//
// File trailer for mycode_terminate.cpp
//
// [EOF]
//

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: mycode_terminate.h
//
// MATLAB Coder version            : 5.0
// C/C++ source code generated on  : 08-Jan-2021 10:39:07
//
#ifndef MYCODE_TERMINATE_H
#define MYCODE_TERMINATE_H

// Include Files
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "mycode_types.h"

// Function Declarations
extern void mycode_terminate();

#endif

//
// File trailer for mycode_terminate.h
//
// [EOF]
//

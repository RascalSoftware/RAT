//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: mycode_types.h
//
// MATLAB Coder version            : 5.0
// C/C++ source code generated on  : 08-Jan-2021 10:39:07
//
#ifndef MYCODE_TYPES_H
#define MYCODE_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for mycode_types.h
//
// [EOF]
//

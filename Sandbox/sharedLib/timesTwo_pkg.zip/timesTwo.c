/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * timesTwo.c
 *
 * Code generation for function 'timesTwo'
 *
 */

/* Include files */
#include "timesTwo.h"

/* Function Definitions */
double timesTwo(double in)
{
  return in * 2.0;
}

/* End of code generation (timesTwo.c) */

/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * timesTwo_initialize.c
 *
 * Code generation for function 'timesTwo_initialize'
 *
 */

/* Include files */
#include "timesTwo.h"
#include "timesTwo_initialize.h"

/* Function Definitions */
void timesTwo_initialize(void)
{
}

/* End of code generation (timesTwo_initialize.c) */

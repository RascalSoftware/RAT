/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * timesTwo_terminate.c
 *
 * Code generation for function 'timesTwo_terminate'
 *
 */

/* Include files */
#include "timesTwo.h"
#include "timesTwo_terminate.h"

/* Function Definitions */
void timesTwo_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (timesTwo_terminate.c) */

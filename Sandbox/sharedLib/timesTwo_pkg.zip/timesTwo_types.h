/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * timesTwo_types.h
 *
 * Code generation for function 'timesTwo'
 *
 */

#ifndef TIMESTWO_TYPES_H
#define TIMESTWO_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (timesTwo_types.h) */

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_deopt.h
//
// Code generation for function 'RAT_deopt'
//
#ifndef RAT_DEOPT_H
#define RAT_DEOPT_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_wrap_1;
  struct cell_wrap_8;
  struct cell_wrap_6;
  struct struct3_T;
  struct d_struct_T;
}

// Function Declarations
namespace RAT
{
  void RAT_deopt(const struct0_T *problem, const ::coder::array<cell_wrap_1, 2U>
                 &problemDef_cells_f1, const ::coder::array<cell_wrap_8, 2U>
                 &problemDef_cells_f2, const ::coder::array<cell_wrap_1, 2U>
                 &problemDef_cells_f3, const ::coder::array<cell_wrap_8, 2U>
                 &problemDef_cells_f4, const ::coder::array<cell_wrap_8, 2U>
                 &problemDef_cells_f5, const ::coder::array<cell_wrap_8, 1U>
                 &problemDef_cells_f6, const ::coder::array<cell_wrap_6, 2U>
                 &problemDef_cells_f14, const ::coder::array<char_T, 2U>
                 &controls_para, const ::coder::array<char_T, 2U>
                 &controls_display, real_T controls_calcSld, const real_T
                 controls_resamPars[2], const struct3_T *controls_checks, const
                 d_struct_T *S_struct, ::coder::array<real_T, 2U> &FVr_bestmem);
}

#endif

// End of code generation (RAT_deopt.h)

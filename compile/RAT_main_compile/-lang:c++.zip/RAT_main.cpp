//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main.cpp
//
// Code generation for function 'RAT_main'
//

// Include files
#include "RAT_main.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_types.h"
#include "lower.h"
#include "rt_nonfinite.h"
#include "runDE.h"
#include "runSimplex.h"
#include "singleCalculation.h"
#include "strcmp.h"
#include "coder_array.h"
#include "coder_bounded_array.h"
#include <stdio.h>

// Function Declarations
namespace RAT
{
  static void cast(const ::coder::array<cell_wrap_1, 2U> &t1_f1, const ::coder::
                   array<cell_wrap_2, 2U> &t1_f2, const ::coder::array<
                   cell_wrap_1, 2U> &t1_f3, const ::coder::array<cell_wrap_3, 2U>
                   &t1_f4, const ::coder::array<cell_wrap_4, 2U> &t1_f5, const ::
                   coder::array<cell_wrap_5, 1U> &t1_f6, const ::coder::array<
                   cell_wrap_0, 2U> &t1_f7, const ::coder::array<cell_wrap_0, 2U>
                   &t1_f8, const ::coder::array<cell_wrap_0, 2U> &t1_f9, const ::
                   coder::array<cell_wrap_0, 2U> &t1_f10, const ::coder::array<
                   cell_wrap_0, 2U> &t1_f11, const ::coder::array<cell_wrap_0,
                   2U> &t1_f12, const ::coder::array<cell_wrap_0, 2U> &t1_f13,
                   const ::coder::array<cell_wrap_6, 2U> &t1_f14, cell_10 *b);
  static void cast(const ::coder::array<cell_wrap_2, 2U> &b, ::coder::array<
                   cell_wrap_8, 2U> &c);
  static void cast(const ::coder::array<cell_wrap_3, 2U> &b, ::coder::array<
                   cell_wrap_8, 2U> &c);
  static void cast(const ::coder::array<cell_wrap_4, 2U> &b, ::coder::array<
                   cell_wrap_8, 2U> &c);
  static void cast(const ::coder::array<cell_wrap_5, 1U> &b, ::coder::array<
                   cell_wrap_8, 1U> &c);
}

// Function Definitions
namespace RAT
{
  static void cast(const ::coder::array<cell_wrap_1, 2U> &t1_f1, const ::coder::
                   array<cell_wrap_2, 2U> &t1_f2, const ::coder::array<
                   cell_wrap_1, 2U> &t1_f3, const ::coder::array<cell_wrap_3, 2U>
                   &t1_f4, const ::coder::array<cell_wrap_4, 2U> &t1_f5, const ::
                   coder::array<cell_wrap_5, 1U> &t1_f6, const ::coder::array<
                   cell_wrap_0, 2U> &t1_f7, const ::coder::array<cell_wrap_0, 2U>
                   &t1_f8, const ::coder::array<cell_wrap_0, 2U> &t1_f9, const ::
                   coder::array<cell_wrap_0, 2U> &t1_f10, const ::coder::array<
                   cell_wrap_0, 2U> &t1_f11, const ::coder::array<cell_wrap_0,
                   2U> &t1_f12, const ::coder::array<cell_wrap_0, 2U> &t1_f13,
                   const ::coder::array<cell_wrap_6, 2U> &t1_f14, cell_10 *b)
  {
    int32_T i;
    int32_T loop_ub;
    b->f1.set_size(1, t1_f1.size(1));
    loop_ub = t1_f1.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f1[i] = t1_f1[i];
    }

    cast(t1_f2, b->f2);
    b->f3.set_size(1, t1_f3.size(1));
    loop_ub = t1_f3.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f3[i] = t1_f3[i];
    }

    cast(t1_f4, b->f4);
    cast(t1_f5, b->f5);
    cast(t1_f6, b->f6);
    b->f7.set_size(1, t1_f7.size(1));
    loop_ub = t1_f7.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f7[i] = t1_f7[i];
    }

    b->f8.set_size(1, t1_f8.size(1));
    loop_ub = t1_f8.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f8[i] = t1_f8[i];
    }

    b->f9.set_size(1, t1_f9.size(1));
    loop_ub = t1_f9.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f9[i] = t1_f9[i];
    }

    b->f10.set_size(1, t1_f10.size(1));
    loop_ub = t1_f10.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f10[i] = t1_f10[i];
    }

    b->f11.set_size(1, t1_f11.size(1));
    loop_ub = t1_f11.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f11[i] = t1_f11[i];
    }

    b->f12.set_size(1, t1_f12.size(1));
    loop_ub = t1_f12.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f12[i] = t1_f12[i];
    }

    b->f13.set_size(1, t1_f13.size(1));
    loop_ub = t1_f13.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f13[i] = t1_f13[i];
    }

    b->f14.set_size(1, t1_f14.size(1));
    loop_ub = t1_f14.size(1);
    for (i = 0; i < loop_ub; i++) {
      b->f14[i] = t1_f14[i];
    }
  }

  static void cast(const ::coder::array<cell_wrap_2, 2U> &b, ::coder::array<
                   cell_wrap_8, 2U> &c)
  {
    int32_T i;
    c.set_size(1, b.size(1));
    i = b.size(1) - 1;
    for (int32_T i1{0}; i1 <= i; i1++) {
      int32_T loop_ub;
      loop_ub = b[i1].f1.size(1);
      c[c.size(0) * i1].f1.set_size(b[b.size(0) * i1].f1.size(0), b[b.size(0) *
        i1].f1.size(1));
      for (int32_T i2{0}; i2 < loop_ub; i2++) {
        int32_T b_loop_ub;
        b_loop_ub = b[i1].f1.size(0);
        for (int32_T i3{0}; i3 < b_loop_ub; i3++) {
          c[i1].f1[i3 + c[i1].f1.size(0) * i2] = b[i1].f1[i3 + b[i1].f1.size(0) *
            i2];
        }
      }
    }
  }

  static void cast(const ::coder::array<cell_wrap_3, 2U> &b, ::coder::array<
                   cell_wrap_8, 2U> &c)
  {
    int32_T i;
    c.set_size(1, b.size(1));
    i = b.size(1) - 1;
    for (int32_T i1{0}; i1 <= i; i1++) {
      int32_T loop_ub;
      loop_ub = b[i1].f1.size[1];
      c[c.size(0) * i1].f1.set_size(b[b.size(0) * i1].f1.size[0], b[b.size(0) *
        i1].f1.size[1]);
      for (int32_T i2{0}; i2 < loop_ub; i2++) {
        int32_T b_loop_ub;
        b_loop_ub = b[i1].f1.size[0];
        for (int32_T i3{0}; i3 < b_loop_ub; i3++) {
          c[i1].f1[c[i1].f1.size(0) * i2] = b[i1].f1.data[b[i1].f1.size[0] * i2];
        }
      }
    }
  }

  static void cast(const ::coder::array<cell_wrap_4, 2U> &b, ::coder::array<
                   cell_wrap_8, 2U> &c)
  {
    int32_T i;
    c.set_size(1, b.size(1));
    i = b.size(1) - 1;
    for (int32_T i1{0}; i1 <= i; i1++) {
      int32_T loop_ub;
      loop_ub = b[i1].f1.size(1);
      c[c.size(0) * i1].f1.set_size(b[b.size(0) * i1].f1.size(0), b[b.size(0) *
        i1].f1.size(1));
      for (int32_T i2{0}; i2 < loop_ub; i2++) {
        int32_T b_loop_ub;
        b_loop_ub = b[i1].f1.size(0);
        for (int32_T i3{0}; i3 < b_loop_ub; i3++) {
          c[i1].f1[c[i1].f1.size(0) * i2] = b[i1].f1[b[i1].f1.size(0) * i2];
        }
      }
    }
  }

  static void cast(const ::coder::array<cell_wrap_5, 1U> &b, ::coder::array<
                   cell_wrap_8, 1U> &c)
  {
    int32_T i;
    c.set_size(b.size(0));
    i = b.size(0);
    for (int32_T i1{0}; i1 < i; i1++) {
      int32_T loop_ub;
      loop_ub = b[i1].f1.size[1];
      c[i1].f1.set_size(b[i1].f1.size[0], b[i1].f1.size[1]);
      for (int32_T i2{0}; i2 < loop_ub; i2++) {
        int32_T b_loop_ub;
        b_loop_ub = b[i1].f1.size[0];
        for (int32_T i3{0}; i3 < b_loop_ub; i3++) {
          c[i1].f1[c[i1].f1.size(0) * i2] = b[i1].f1.data[b[i1].f1.size[0] * i2];
        }
      }
    }
  }

  void RAT_main(const struct0_T *problemDef, const cell_7 *problemDef_cells,
                const struct1_T *problemDef_limits, const struct2_T *controls,
                const struct4_T *, struct0_T *outProblemDef, struct5_T *problem,
                cell_wrap_9 results_data[], int32_T results_size[2])
  {
    ::coder::array<char_T, 2U> switch_expression;
    ::coder::array<int8_T, 1U> t2_calculations_all_chis;
    ::coder::bounded_array<cell_wrap_9, 6U, 2U> result;
    ::coder::bounded_array<cell_wrap_9, 6U, 2U> results;
    b_struct_T b_problem;
    b_struct_T c_problem;
    cell_10 r6;
    cell_wrap_8 r;
    cell_wrap_8 r1;
    cell_wrap_8 r2;
    cell_wrap_8 r3;
    cell_wrap_8 r4;
    cell_wrap_8 r5;
    int32_T i;
    int32_T loop_ub;
    int32_T loop_ub_tmp;
    result.size[0] = 6;
    result.size[1] = 1;
    for (i = 0; i < 6; i++) {
      result.data[i].f1.set_size(0);
    }

    r.f1.set_size(1, 1);
    r.f1[0] = 0.0;
    result.data[0].f1.set_size(1);
    result.data[0].f1[0] = r;
    r1.f1.set_size(1, 1);
    r1.f1[0] = 0.0;
    result.data[1].f1.set_size(1);
    result.data[1].f1[0] = r1;
    r2.f1.set_size(1, 1);
    r2.f1[0] = 0.0;
    result.data[2].f1.set_size(1);
    result.data[2].f1[0] = r2;
    r3.f1.set_size(1, 1);
    r3.f1[0] = 0.0;
    result.data[3].f1.set_size(1);
    result.data[3].f1[0] = r3;
    r4.f1.set_size(1, 1);
    r4.f1[0] = 0.0;
    result.data[4].f1.set_size(1);
    result.data[4].f1[0] = r4;
    r5.f1.set_size(1, 1);
    r5.f1[0] = 0.0;
    result.data[5].f1.set_size(1);
    result.data[5].f1[0] = r5;
    results_size[0] = 6;
    results_size[1] = 1;
    for (i = 0; i < 6; i++) {
      results_data[i] = result.data[i];
    }

    loop_ub_tmp = static_cast<int32_T>(problemDef->numberOfContrasts);
    t2_calculations_all_chis.set_size(loop_ub_tmp);
    problem->ssubs.set_size(loop_ub_tmp);
    problem->backgrounds.set_size(loop_ub_tmp);
    problem->qshifts.set_size(loop_ub_tmp);
    problem->scalefactors.set_size(loop_ub_tmp);
    problem->nbairs.set_size(loop_ub_tmp);
    problem->nbsubs.set_size(loop_ub_tmp);
    problem->resolutions.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      t2_calculations_all_chis[i] = 0;
      problem->ssubs[i] = 0.0;
      problem->backgrounds[i] = 0.0;
      problem->qshifts[i] = 0.0;
      problem->scalefactors[i] = 0.0;
      problem->nbairs[i] = 0.0;
      problem->nbsubs[i] = 0.0;
      problem->resolutions[i] = 0.0;
    }

    problem->calculations.all_chis.set_size(t2_calculations_all_chis.size(0));
    loop_ub = t2_calculations_all_chis.size(0);
    for (i = 0; i < loop_ub; i++) {
      problem->calculations.all_chis[i] = 0.0;
    }

    problem->calculations.sum_chi = 0.0;
    problem->allSubRough.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->allSubRough[i] = 0.0;
    }

    problem->resample.set_size(loop_ub_tmp, 1);
    for (i = 0; i < 1; i++) {
      for (loop_ub = 0; loop_ub < loop_ub_tmp; loop_ub++) {
        problem->resample[loop_ub] = 0.0;
      }
    }

    //  Make empty bayes results even though we may not fill it (for output purposes)
    *outProblemDef = *problemDef;

    // Decide what we are doing....
    coder::lower(controls->proc, switch_expression);
    if (coder::internal::b_strcmp(switch_expression)) {
      loop_ub = 0;
    } else if (coder::internal::c_strcmp(switch_expression)) {
      loop_ub = 1;
    } else if (coder::internal::d_strcmp(switch_expression)) {
      loop_ub = 2;
    } else {
      loop_ub = -1;
    }

    switch (loop_ub) {
     case 0:
      // Just a single reflectivity calculation
      cast(problemDef_cells->f1, problemDef_cells->f2, problemDef_cells->f3,
           problemDef_cells->f4, problemDef_cells->f5, problemDef_cells->f6,
           problemDef_cells->f7, problemDef_cells->f8, problemDef_cells->f9,
           problemDef_cells->f10, problemDef_cells->f11, problemDef_cells->f12,
           problemDef_cells->f13, problemDef_cells->f14, &r6);
      singleCalculation(problemDef, &r6, controls, &b_problem, results.data,
                        results.size);
      problem->ssubs.set_size(b_problem.ssubs.size(0));
      loop_ub = b_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->ssubs[i] = b_problem.ssubs[i];
      }

      problem->backgrounds.set_size(b_problem.backgrounds.size(0));
      loop_ub = b_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->backgrounds[i] = b_problem.backgrounds[i];
      }

      problem->qshifts.set_size(b_problem.qshifts.size(0));
      loop_ub = b_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->qshifts[i] = b_problem.qshifts[i];
      }

      problem->scalefactors.set_size(b_problem.scalefactors.size(0));
      loop_ub = b_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->scalefactors[i] = b_problem.scalefactors[i];
      }

      problem->nbairs.set_size(b_problem.nbairs.size(0));
      loop_ub = b_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbairs[i] = b_problem.nbairs[i];
      }

      problem->nbsubs.set_size(b_problem.nbsubs.size(0));
      loop_ub = b_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbsubs[i] = b_problem.nbsubs[i];
      }

      problem->resolutions.set_size(b_problem.resolutions.size(0));
      loop_ub = b_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->resolutions[i] = b_problem.resolutions[i];
      }

      problem->calculations = b_problem.calculations;
      problem->allSubRough.set_size(b_problem.allSubRough.size(0));
      loop_ub = b_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->allSubRough[i] = b_problem.allSubRough[i];
      }

      problem->resample.set_size(1, b_problem.resample.size(1));
      loop_ub = b_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        problem->resample[problem->resample.size(0) * i] = b_problem.resample[i];
      }

      results_size[0] = 1;
      results_size[1] = 6;
      for (i = 0; i < 6; i++) {
        results_data[results_size[0] * i] = results.data[i];
      }
      break;

     case 1:
      if (!coder::internal::o_strcmp(controls->display)) {
        //  This is an overloaded version of 'ratSendTextOutput' for the compile.
        //  The 'real' one is the output class. We will think of a better solution
        //  later on.
        //  if isnumeric(outText)
        //      outText = sprintf('%g',outText);
        //  end
        printf("%s \n", "\nRunning simplex\n\n");
        fflush(stdout);
      }

      cast(problemDef_cells->f1, problemDef_cells->f2, problemDef_cells->f3,
           problemDef_cells->f4, problemDef_cells->f5, problemDef_cells->f6,
           problemDef_cells->f7, problemDef_cells->f8, problemDef_cells->f9,
           problemDef_cells->f10, problemDef_cells->f11, problemDef_cells->f12,
           problemDef_cells->f13, problemDef_cells->f14, &r6);
      runSimplex(outProblemDef, &r6, problemDef_limits, controls, &c_problem,
                 results.data, results.size);
      b_problem.ssubs.set_size(c_problem.ssubs.size(0));
      loop_ub = c_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.ssubs[i] = c_problem.ssubs[i];
      }

      b_problem.backgrounds.set_size(c_problem.backgrounds.size(0));
      loop_ub = c_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.backgrounds[i] = c_problem.backgrounds[i];
      }

      b_problem.qshifts.set_size(c_problem.qshifts.size(0));
      loop_ub = c_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.qshifts[i] = c_problem.qshifts[i];
      }

      b_problem.scalefactors.set_size(c_problem.scalefactors.size(0));
      loop_ub = c_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.scalefactors[i] = c_problem.scalefactors[i];
      }

      b_problem.nbairs.set_size(c_problem.nbairs.size(0));
      loop_ub = c_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbairs[i] = c_problem.nbairs[i];
      }

      b_problem.nbsubs.set_size(c_problem.nbsubs.size(0));
      loop_ub = c_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbsubs[i] = c_problem.nbsubs[i];
      }

      b_problem.resolutions.set_size(c_problem.resolutions.size(0));
      loop_ub = c_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resolutions[i] = c_problem.resolutions[i];
      }

      b_problem.allSubRough.set_size(c_problem.allSubRough.size(0));
      loop_ub = c_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.allSubRough[i] = c_problem.allSubRough[i];
      }

      b_problem.resample.set_size(1, c_problem.resample.size(1));
      loop_ub = c_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resample[i] = c_problem.resample[i];
      }

      problem->ssubs.set_size(b_problem.ssubs.size(0));
      loop_ub = b_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->ssubs[i] = b_problem.ssubs[i];
      }

      problem->backgrounds.set_size(b_problem.backgrounds.size(0));
      loop_ub = b_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->backgrounds[i] = b_problem.backgrounds[i];
      }

      problem->qshifts.set_size(b_problem.qshifts.size(0));
      loop_ub = b_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->qshifts[i] = b_problem.qshifts[i];
      }

      problem->scalefactors.set_size(b_problem.scalefactors.size(0));
      loop_ub = b_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->scalefactors[i] = b_problem.scalefactors[i];
      }

      problem->nbairs.set_size(b_problem.nbairs.size(0));
      loop_ub = b_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbairs[i] = b_problem.nbairs[i];
      }

      problem->nbsubs.set_size(b_problem.nbsubs.size(0));
      loop_ub = b_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbsubs[i] = b_problem.nbsubs[i];
      }

      problem->resolutions.set_size(b_problem.resolutions.size(0));
      loop_ub = b_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->resolutions[i] = b_problem.resolutions[i];
      }

      problem->calculations = c_problem.calculations;
      problem->allSubRough.set_size(b_problem.allSubRough.size(0));
      loop_ub = b_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->allSubRough[i] = b_problem.allSubRough[i];
      }

      problem->resample.set_size(1, b_problem.resample.size(1));
      loop_ub = b_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        problem->resample[problem->resample.size(0) * i] = b_problem.resample[i];
      }

      results_size[0] = 1;
      results_size[1] = 6;
      for (i = 0; i < 6; i++) {
        results_data[results_size[0] * i] = results.data[i];
      }
      break;

     case 2:
      if (!coder::internal::o_strcmp(controls->display)) {
        //  This is an overloaded version of 'ratSendTextOutput' for the compile.
        //  The 'real' one is the output class. We will think of a better solution
        //  later on.
        //  if isnumeric(outText)
        //      outText = sprintf('%g',outText);
        //  end
        printf("%s \n", "\nRunning Differential Evolution\n\n");
        fflush(stdout);
      }

      cast(problemDef_cells->f1, problemDef_cells->f2, problemDef_cells->f3,
           problemDef_cells->f4, problemDef_cells->f5, problemDef_cells->f6,
           problemDef_cells->f7, problemDef_cells->f8, problemDef_cells->f9,
           problemDef_cells->f10, problemDef_cells->f11, problemDef_cells->f12,
           problemDef_cells->f13, problemDef_cells->f14, &r6);
      runDE(outProblemDef, &r6, problemDef_limits, controls, &c_problem,
            results.data, results.size);
      b_problem.ssubs.set_size(c_problem.ssubs.size(0));
      loop_ub = c_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.ssubs[i] = c_problem.ssubs[i];
      }

      b_problem.backgrounds.set_size(c_problem.backgrounds.size(0));
      loop_ub = c_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.backgrounds[i] = c_problem.backgrounds[i];
      }

      b_problem.qshifts.set_size(c_problem.qshifts.size(0));
      loop_ub = c_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.qshifts[i] = c_problem.qshifts[i];
      }

      b_problem.scalefactors.set_size(c_problem.scalefactors.size(0));
      loop_ub = c_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.scalefactors[i] = c_problem.scalefactors[i];
      }

      b_problem.nbairs.set_size(c_problem.nbairs.size(0));
      loop_ub = c_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbairs[i] = c_problem.nbairs[i];
      }

      b_problem.nbsubs.set_size(c_problem.nbsubs.size(0));
      loop_ub = c_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbsubs[i] = c_problem.nbsubs[i];
      }

      b_problem.resolutions.set_size(c_problem.resolutions.size(0));
      loop_ub = c_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resolutions[i] = c_problem.resolutions[i];
      }

      b_problem.allSubRough.set_size(c_problem.allSubRough.size(0));
      loop_ub = c_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.allSubRough[i] = c_problem.allSubRough[i];
      }

      b_problem.resample.set_size(1, c_problem.resample.size(1));
      loop_ub = c_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resample[i] = c_problem.resample[i];
      }

      problem->ssubs.set_size(b_problem.ssubs.size(0));
      loop_ub = b_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->ssubs[i] = b_problem.ssubs[i];
      }

      problem->backgrounds.set_size(b_problem.backgrounds.size(0));
      loop_ub = b_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->backgrounds[i] = b_problem.backgrounds[i];
      }

      problem->qshifts.set_size(b_problem.qshifts.size(0));
      loop_ub = b_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->qshifts[i] = b_problem.qshifts[i];
      }

      problem->scalefactors.set_size(b_problem.scalefactors.size(0));
      loop_ub = b_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->scalefactors[i] = b_problem.scalefactors[i];
      }

      problem->nbairs.set_size(b_problem.nbairs.size(0));
      loop_ub = b_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbairs[i] = b_problem.nbairs[i];
      }

      problem->nbsubs.set_size(b_problem.nbsubs.size(0));
      loop_ub = b_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbsubs[i] = b_problem.nbsubs[i];
      }

      problem->resolutions.set_size(b_problem.resolutions.size(0));
      loop_ub = b_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->resolutions[i] = b_problem.resolutions[i];
      }

      problem->calculations = c_problem.calculations;
      problem->allSubRough.set_size(b_problem.allSubRough.size(0));
      loop_ub = b_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->allSubRough[i] = b_problem.allSubRough[i];
      }

      problem->resample.set_size(1, b_problem.resample.size(1));
      loop_ub = b_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        problem->resample[problem->resample.size(0) * i] = b_problem.resample[i];
      }

      results_size[0] = 1;
      results_size[1] = 6;
      for (i = 0; i < 6; i++) {
        results_data[results_size[0] * i] = results.data[i];
      }

      //      case 'bayes'
      //          if ~strcmpi(controls.display,'off')
      //              ratSendTextOutput(sprintf('\nRunning DRAM\n\n'));
      //          end
      //          [outProblemDef,problem,results,bayesResults] = runDram(problemDef,problemDef_cells,problemDef_limits,controls,priors);
      //      case 'ns'
      //          if ~strcmpi(controls.display,'off')
      //              ratSendTextOutput(sprintf('\nRunning Nested Sampler\n\n'));
      //          end
      //          [outProblemDef,problem,results,bayesResults] = runNestedSampler(problemDef,problemDef_cells,problemDef_limits,controls);
      //      case 'paramonte'
      //          % TODO
      break;
    }
  }
}

// End of code generation (RAT_main.cpp)

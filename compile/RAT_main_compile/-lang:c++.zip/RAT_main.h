//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main.h
//
// Code generation for function 'RAT_main'
//
#ifndef RAT_MAIN_H
#define RAT_MAIN_H

// Include files
#include "RAT_main_types.h"
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  extern void RAT_main(const struct0_T *problemDef, const cell_7
                       *problemDef_cells, const struct1_T *problemDef_limits,
                       const struct2_T *controls, const struct4_T *priors,
                       struct0_T *outProblemDef, struct5_T *problem, cell_wrap_9
                       results_data[], int32_T results_size[2]);
}

#endif

// End of code generation (RAT_main.h)

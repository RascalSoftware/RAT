//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main_data.h
//
// Code generation for function 'RAT_main_data'
//
#ifndef RAT_MAIN_DATA_H
#define RAT_MAIN_DATA_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
namespace RAT
{
  extern uint32_T state[625];
  extern omp_nest_lock_t emlrtNestLockGlobal;
  extern const char_T cv[128];
}

#endif

// End of code generation (RAT_main_data.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main_initialize.cpp
//
// Code generation for function 'RAT_main_initialize'
//

// Include files
#include "RAT_main_initialize.h"
#include "RAT_main_data.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace RAT
{
  void RAT_main_initialize()
  {
    omp_init_nest_lock(&emlrtNestLockGlobal);
    eml_rand_mt19937ar_stateful_init();
  }
}

// End of code generation (RAT_main_initialize.cpp)

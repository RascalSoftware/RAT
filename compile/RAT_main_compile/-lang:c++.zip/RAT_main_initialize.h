//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main_initialize.h
//
// Code generation for function 'RAT_main_initialize'
//
#ifndef RAT_MAIN_INITIALIZE_H
#define RAT_MAIN_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  extern void RAT_main_initialize();
}

#endif

// End of code generation (RAT_main_initialize.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main_internal_types.h
//
// Code generation for function 'RAT_main'
//
#ifndef RAT_MAIN_INTERNAL_TYPES_H
#define RAT_MAIN_INTERNAL_TYPES_H

// Include files
#include "RAT_main_types.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Type Definitions
namespace RAT
{
  struct struct_T
  {
    real_T I_nc;
    real_T FVr_ca;
    real_T I_no;
    real_T FVr_oa;
  };

  struct cell_wrap_16
  {
    real_T f1[5];
  };

  struct b_struct_T
  {
    ::coder::array<real_T, 1U> ssubs;
    ::coder::array<real_T, 1U> backgrounds;
    ::coder::array<real_T, 1U> qshifts;
    ::coder::array<real_T, 1U> scalefactors;
    ::coder::array<real_T, 1U> nbairs;
    ::coder::array<real_T, 1U> nbsubs;
    ::coder::array<real_T, 1U> resolutions;
    struct6_T calculations;
    ::coder::array<real_T, 1U> allSubRough;
    ::coder::array<real_T, 2U> resample;
  };

  struct cell_10
  {
    ::coder::array<cell_wrap_1, 2U> f1;
    ::coder::array<cell_wrap_8, 2U> f2;
    ::coder::array<cell_wrap_1, 2U> f3;
    ::coder::array<cell_wrap_8, 2U> f4;
    ::coder::array<cell_wrap_8, 2U> f5;
    ::coder::array<cell_wrap_8, 1U> f6;
    ::coder::array<cell_wrap_0, 2U> f7;
    ::coder::array<cell_wrap_0, 2U> f8;
    ::coder::array<cell_wrap_0, 2U> f9;
    ::coder::array<cell_wrap_0, 2U> f10;
    ::coder::array<cell_wrap_0, 2U> f11;
    ::coder::array<cell_wrap_0, 2U> f12;
    ::coder::array<cell_wrap_0, 2U> f13;
    ::coder::array<cell_wrap_6, 2U> f14;
  };

  struct cell_11
  {
    ::coder::array<cell_wrap_8, 1U> f1;
    ::coder::array<cell_wrap_8, 1U> f2;
    ::coder::array<cell_wrap_8, 1U> f3;
    ::coder::array<cell_wrap_8, 1U> f4;
    ::coder::array<cell_wrap_8, 1U> f5;
    ::coder::array<cell_wrap_8, 1U> f6;
  };

  struct cell_wrap_12
  {
    ::coder::array<real_T, 2U> f1;
  };

  struct cell_wrap_14
  {
    ::coder::array<real_T, 2U> f1;
  };

  struct cell_wrap_15
  {
    ::coder::array<real_T, 2U> f1;
  };

  struct cell_wrap_31
  {
    ::coder::array<real_T, 2U> f1;
  };

  struct cell_wrap_32
  {
    ::coder::array<real_T, 2U> f1;
  };

  struct c_struct_T
  {
    real_T iterations;
    real_T funcCount;
    char_T algorithm[33];
    ::coder::array<char_T, 2U> message;
  };

  struct d_struct_T
  {
    ::coder::bounded_array<real_T, 1U, 1U> I_lentol;
    ::coder::bounded_array<real_T, 50U, 2U> FVr_x;
    ::coder::bounded_array<real_T, 50U, 2U> FVr_lim_up;
    ::coder::bounded_array<real_T, 50U, 2U> FVr_lim_lo;
    real_T I_NP;
    real_T F_weight;
    real_T F_CR;
    real_T I_D;
    ::coder::array<real_T, 2U> FVr_minbound;
    ::coder::array<real_T, 2U> FVr_maxbound;
    real_T I_bnd_constr;
    real_T I_itermax;
    real_T F_VTR;
    real_T I_strategy;
    real_T I_refresh;
    real_T I_plotting;
    ::coder::array<real_T, 2U> FM_pop;
    ::coder::array<real_T, 2U> FVr_bestmem;
  };

  struct cell_20
  {
    ::coder::array<real_T, 2U> f1;
  };

  struct e_struct_T
  {
    ::coder::array<real_T, 1U> LB;
    ::coder::array<real_T, 1U> UB;
    ::coder::array<real_T, 1U> BoundClass;
  };
}

#endif

// End of code generation (RAT_main_internal_types.h)

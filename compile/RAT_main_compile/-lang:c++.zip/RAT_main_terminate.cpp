//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main_terminate.cpp
//
// Code generation for function 'RAT_main_terminate'
//

// Include files
#include "RAT_main_terminate.h"
#include "RAT_main_data.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace RAT
{
  void RAT_main_terminate()
  {
    omp_destroy_nest_lock(&emlrtNestLockGlobal);
  }
}

// End of code generation (RAT_main_terminate.cpp)

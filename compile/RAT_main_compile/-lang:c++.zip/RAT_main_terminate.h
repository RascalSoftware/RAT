//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// RAT_main_terminate.h
//
// Code generation for function 'RAT_main_terminate'
//
#ifndef RAT_MAIN_TERMINATE_H
#define RAT_MAIN_TERMINATE_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  extern void RAT_main_terminate();
}

#endif

// End of code generation (RAT_main_terminate.h)

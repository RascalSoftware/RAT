//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abeles_single.h
//
// Code generation for function 'abeles_single'
//
#ifndef ABELES_SINGLE_H
#define ABELES_SINGLE_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  void abeles_single(const ::coder::array<real_T, 1U> &x, const ::coder::array<
                     real_T, 2U> &sld, real_T nbair, real_T nbsub, real_T
                     nrepeats, real_T rsub, real_T layers, real_T points, ::
                     coder::array<real_T, 1U> &out);
}

#endif

// End of code generation (abeles_single.h)

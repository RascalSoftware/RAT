//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// allocateParamsToLayers.cpp
//
// Code generation for function 'allocateParamsToLayers'
//

// Include files
#include "allocateParamsToLayers.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_types.h"
#include "length.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace RAT
{
  void allocateParamsToLayers(const ::coder::array<real_T, 2U> &params, const ::
    coder::array<cell_wrap_8, 1U> &layersDetails, ::coder::array<cell_wrap_16,
    2U> &outLayers)
  {
    real_T thisOutLayer[5];
    int32_T i;

    //  Allocates parameters from the parameter array to the correct layers
    //
    //  This function takes the list of all layers in 'layersDetails',
    //  then loops over all the layers, putting in the correct
    //  parameter value from the parameters array into each layer in
    //  the 'outLayers' cell array
    for (i = 0; i < 5; i++) {
      thisOutLayer[i] = 0.0;
    }

    outLayers.set_size(1, layersDetails.size(0));
    i = layersDetails.size(0);
    for (int32_T b_i{0}; b_i < i; b_i++) {
      int32_T i1;
      i1 = coder::internal::intlength(layersDetails[b_i].f1.size(0),
        layersDetails[b_i].f1.size(1));
      for (int32_T n{0}; n <= i1 - 2; n++) {
        if (!std::isnan(layersDetails[b_i].f1[n])) {
          thisOutLayer[n] = params[static_cast<int32_T>(layersDetails[b_i].f1[n])
            - 1];
        } else {
          thisOutLayer[n] = rtNaN;
        }
      }

      thisOutLayer[coder::internal::intlength(layersDetails[b_i].f1.size(0),
        layersDetails[b_i].f1.size(1)) - 1] = layersDetails[b_i]
        .f1[layersDetails[b_i].f1.size(0) * layersDetails[b_i].f1.size(1) - 1];
      for (i1 = 0; i1 < 5; i1++) {
        outLayers[b_i].f1[i1] = thisOutLayer[i1];
      }
    }
  }
}

// End of code generation (allocateParamsToLayers.cpp)

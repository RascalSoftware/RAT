//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// fitsetup.cpp
//
// Code generation for function 'fitsetup'
//

// Include files
#include "fitsetup.h"
#include "RAT_main_types.h"
#include "blockedSummation.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void fitsetup(struct0_T *problemDef, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f7, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f8, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f9, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f10, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f11, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f12, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f13, const ::coder::array<real_T, 2U>
                &problemDef_limits_params, const ::coder::array<real_T, 2U>
                &problemDef_limits_backs, const ::coder::array<real_T, 2U>
                &problemDef_limits_scales, const ::coder::array<real_T, 2U>
                &problemDef_limits_shifts, const ::coder::array<real_T, 2U>
                &problemDef_limits_nba, const ::coder::array<real_T, 2U>
                &problemDef_limits_nbs, const ::coder::array<real_T, 2U>
                &problemDef_limits_res, const struct3_T *controls_checks, ::
                coder::array<cell_wrap_0, 1U> &fitNames)
  {
    ::coder::array<real_T, 2U> fitconstr;
    ::coder::array<real_T, 2U> otherconstr;
    ::coder::array<real_T, 1U> otherpars;
    real_T b_y;
    real_T c_y;
    real_T d_y;
    real_T e_y;
    real_T f_y;
    real_T g_y;
    real_T numberOfFitted;
    real_T numberOfTotal;
    real_T y;
    int32_T i;
    int32_T i1;
    int32_T loop_ub_tmp;
    int32_T n;
    int32_T numberOfTotal_idx_0_tmp;
    uint32_T fitCounter;
    uint32_T otherCounter;

    // Separate out the params array into fitting
    // and unfitting arrays.
    // problem = getappdata(0,'problem');
    //  controls.checks.params_fitYesNo = ones(length(problem.params),1);
    //  controls.checks.backs_fitYesNo = ones(length(problem.backs),1);
    //  controls.checks.scales_fitYesNo = ones(length(problem.scalefac),1);
    //  controls.checks.nbairs_fitYesNo = ones(length(problem.nba),1);
    //  controls.checks.nbsubs_fitYesNo = ones(length(problem.nbs),1);
    //  controls.checks.resol_fitYesNo = ones(length(problem.resolution),1);
    //  calculation.limits.params = problem.constr;
    //  calculation.limits.backs = problem.backs_constr;
    //  calculation.limits.scales = problem.scale_constr;
    //  calculation.limits.shifts = problem.shifts_constr;
    //  calculation.limits.nba = problem.nbairs_constr;
    //  calculation.limits.nbs = problem.nbsubs_constr;
    //  calculation.limits.res = problem.resolution_constr;
    // We need to pack the parameters into seperate vectors
    // of those that are being fitted, and those that are
    // held constant.
    if (controls_checks->params_fitYesNo.size(1) == 0) {
      y = 0.0;
    } else {
      y = coder::nestedIter(controls_checks->params_fitYesNo,
                            controls_checks->params_fitYesNo.size(1));
    }

    if (controls_checks->backs_fitYesNo.size(1) == 0) {
      b_y = 0.0;
    } else {
      b_y = coder::nestedIter(controls_checks->backs_fitYesNo,
        controls_checks->backs_fitYesNo.size(1));
    }

    if (controls_checks->scales_fitYesNo.size(1) == 0) {
      c_y = 0.0;
    } else {
      c_y = coder::nestedIter(controls_checks->scales_fitYesNo,
        controls_checks->scales_fitYesNo.size(1));
    }

    if (controls_checks->shifts_fitYesNo.size(1) == 0) {
      d_y = 0.0;
    } else {
      d_y = coder::nestedIter(controls_checks->shifts_fitYesNo,
        controls_checks->shifts_fitYesNo.size(1));
    }

    if (controls_checks->nbairs_fitYesNo.size(1) == 0) {
      e_y = 0.0;
    } else {
      e_y = coder::nestedIter(controls_checks->nbairs_fitYesNo,
        controls_checks->nbairs_fitYesNo.size(1));
    }

    if (controls_checks->nbsubs_fitYesNo.size(1) == 0) {
      f_y = 0.0;
    } else {
      f_y = coder::nestedIter(controls_checks->nbsubs_fitYesNo,
        controls_checks->nbsubs_fitYesNo.size(1));
    }

    if (controls_checks->resol_fitYesNo.size(1) == 0) {
      g_y = 0.0;
    } else {
      g_y = coder::nestedIter(controls_checks->resol_fitYesNo,
        controls_checks->resol_fitYesNo.size(1));
    }

    numberOfFitted = (((((y + b_y) + c_y) + d_y) + e_y) + f_y) + g_y;
    numberOfTotal = (((((static_cast<real_T>(problemDef->params.size(1)) +
                         static_cast<real_T>(problemDef->backs.size(1))) +
                        static_cast<real_T>(problemDef->sf.size(1))) +
                       static_cast<real_T>(problemDef->shifts.size(1))) +
                      static_cast<real_T>(problemDef->nba.size(1))) +
                     static_cast<real_T>(problemDef->nbs.size(1))) +
      static_cast<real_T>(problemDef->res.size(1));

    // zeros(numberOfFitted,1);
    numberOfTotal_idx_0_tmp = static_cast<int32_T>(numberOfTotal -
      numberOfFitted);
    otherpars.set_size(numberOfTotal_idx_0_tmp);
    for (i = 0; i < numberOfTotal_idx_0_tmp; i++) {
      otherpars[i] = 0.0;
    }

    loop_ub_tmp = static_cast<int32_T>(numberOfFitted);
    fitconstr.set_size(loop_ub_tmp, 2);
    otherconstr.set_size(numberOfTotal_idx_0_tmp, 2);
    for (i = 0; i < 2; i++) {
      for (i1 = 0; i1 < loop_ub_tmp; i1++) {
        fitconstr[i1 + fitconstr.size(0) * i] = 0.0;
      }

      for (i1 = 0; i1 < numberOfTotal_idx_0_tmp; i1++) {
        otherconstr[i1 + otherconstr.size(0) * i] = 0.0;
      }
    }

    // limits = problemDef.limits;
    fitNames.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      fitNames[i].f1.set_size(1, 0);
    }

    fitCounter = 1U;
    otherCounter = 1U;
    i = controls_checks->params_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->params_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->params[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_params[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_params[n + problemDef_limits_params.size(0)];
        loop_ub_tmp = problemDef_cells_f7[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f7[problemDef_cells_f7.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f7[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->params[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_params[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_params[n + problemDef_limits_params.size(0)];
        otherCounter++;
      }
    }

    // Also do the same for backgrounds...
    i = controls_checks->backs_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->backs_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->backs[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_backs[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_backs[n + problemDef_limits_backs.size(0)];
        loop_ub_tmp = problemDef_cells_f8[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f8[problemDef_cells_f8.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f8[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->backs[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_backs[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_backs[n + problemDef_limits_backs.size(0)];
        otherCounter++;
      }
    }

    // ..also for the scale factors
    i = controls_checks->scales_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->scales_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->sf[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_scales[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_scales[n + problemDef_limits_scales.size(0)];
        loop_ub_tmp = problemDef_cells_f9[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f9[problemDef_cells_f9.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f9[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->sf[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_scales[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_scales[n + problemDef_limits_scales.size(0)];
        otherCounter++;
      }
    }

    // Need qshifts
    i = controls_checks->shifts_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->shifts_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->shifts[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_shifts[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_shifts[n + problemDef_limits_shifts.size(0)];
        loop_ub_tmp = problemDef_cells_f10[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f10[problemDef_cells_f10.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f10[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->shifts[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_shifts[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_shifts[n + problemDef_limits_shifts.size(0)];
        otherCounter++;
      }
    }

    // Nbairs
    i = controls_checks->nbairs_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->nbairs_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->nba[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_nba[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_nba[n + problemDef_limits_nba.size(0)];
        loop_ub_tmp = problemDef_cells_f11[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f11[problemDef_cells_f11.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f11[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->nba[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_nba[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_nba[n + problemDef_limits_nba.size(0)];
        otherCounter++;
      }
    }

    // NBsubs
    i = controls_checks->nbsubs_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->nbsubs_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->nbs[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_nbs[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_nbs[n + problemDef_limits_nbs.size(0)];
        loop_ub_tmp = problemDef_cells_f12[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f12[problemDef_cells_f12.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f12[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->nbs[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_nbs[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_nbs[n + problemDef_limits_nbs.size(0)];
        otherCounter++;
      }
    }

    // Resolution.....
    i = controls_checks->resol_fitYesNo.size(1);
    for (n = 0; n < i; n++) {
      if (controls_checks->resol_fitYesNo[n] == 1.0) {
        problemDef->fitpars[static_cast<int32_T>(fitCounter) - 1] =
          problemDef->res[n];
        fitconstr[static_cast<int32_T>(fitCounter) - 1] =
          problemDef_limits_res[n];
        fitconstr[(static_cast<int32_T>(fitCounter) + fitconstr.size(0)) - 1] =
          problemDef_limits_res[n + problemDef_limits_res.size(0)];
        loop_ub_tmp = problemDef_cells_f13[n].f1.size(1);
        fitNames[static_cast<int32_T>(fitCounter) - 1].f1.set_size(1,
          problemDef_cells_f13[problemDef_cells_f13.size(0) * n].f1.size(1));
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          fitNames[static_cast<int32_T>(fitCounter) - 1].f1[i1] =
            problemDef_cells_f13[n].f1[i1];
        }

        fitCounter++;
      } else {
        otherpars[static_cast<int32_T>(otherCounter) - 1] = problemDef->res[n];
        otherconstr[static_cast<int32_T>(otherCounter) - 1] =
          problemDef_limits_res[n];
        otherconstr[(static_cast<int32_T>(otherCounter) + otherconstr.size(0)) -
          1] = problemDef_limits_res[n + problemDef_limits_res.size(0)];
        otherCounter++;
      }
    }

    numberOfTotal_idx_0_tmp = otherpars.size(0);
    problemDef->otherpars.set_size(otherpars.size(0), 1);
    for (i = 0; i < 1; i++) {
      for (i1 = 0; i1 < numberOfTotal_idx_0_tmp; i1++) {
        problemDef->otherpars[i1] = otherpars[i1];
      }
    }

    problemDef->fitconstr.set_size(fitconstr.size(0), 2);
    problemDef->otherconstr.set_size(otherconstr.size(0), 2);
    loop_ub_tmp = fitconstr.size(0);
    numberOfTotal_idx_0_tmp = otherconstr.size(0);
    for (i = 0; i < 2; i++) {
      for (i1 = 0; i1 < loop_ub_tmp; i1++) {
        problemDef->fitconstr[i1 + problemDef->fitconstr.size(0) * i] =
          fitconstr[i1 + fitconstr.size(0) * i];
      }

      for (i1 = 0; i1 < numberOfTotal_idx_0_tmp; i1++) {
        problemDef->otherconstr[i1 + problemDef->otherconstr.size(0) * i] =
          otherconstr[i1 + otherconstr.size(0) * i];
      }
    }

    // Check the bounds on all the selected
    //  out = checkBounds(problemDef,controls);
    //  if strcmp(out{1},'fail')
    //      return
    //  end
  }
}

// End of code generation (fitsetup.cpp)

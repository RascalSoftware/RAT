//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// fitsetup.h
//
// Code generation for function 'fitsetup'
//
#ifndef FITSETUP_H
#define FITSETUP_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_wrap_0;
  struct struct3_T;
}

// Function Declarations
namespace RAT
{
  void fitsetup(struct0_T *problemDef, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f7, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f8, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f9, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f10, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f11, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f12, const ::coder::array<cell_wrap_0, 2U>
                &problemDef_cells_f13, const ::coder::array<real_T, 2U>
                &problemDef_limits_params, const ::coder::array<real_T, 2U>
                &problemDef_limits_backs, const ::coder::array<real_T, 2U>
                &problemDef_limits_scales, const ::coder::array<real_T, 2U>
                &problemDef_limits_shifts, const ::coder::array<real_T, 2U>
                &problemDef_limits_nba, const ::coder::array<real_T, 2U>
                &problemDef_limits_nbs, const ::coder::array<real_T, 2U>
                &problemDef_limits_res, const struct3_T *controls_checks, ::
                coder::array<cell_wrap_0, 1U> &fitNames);
}

#endif

// End of code generation (fitsetup.h)

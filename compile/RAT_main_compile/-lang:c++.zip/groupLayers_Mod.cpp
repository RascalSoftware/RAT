//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// groupLayers_Mod.cpp
//
// Code generation for function 'groupLayers_Mod'
//

// Include files
#include "groupLayers_Mod.h"
#include "rt_nonfinite.h"
#include "strcmp.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace RAT
{
  void groupLayers_Mod(const ::coder::array<real_T, 2U> &allLayers, real_T
                       allRoughs, const ::coder::array<char_T, 2U> &geometry,
                       real_T nbair, real_T nbsubs, ::coder::array<real_T, 2U>
                       &outLayers, real_T *outSsubs)
  {
    ::coder::array<real_T, 2U> layers;
    ::coder::array<real_T, 1U> roughs;
    int32_T b_loop_ub;
    int32_T i;
    int32_T loop_ub;

    // Arrange layers according to geometry and apply any coverage correction.
    //
    //  USAGE::
    //
    //      [outLayers, outSsubs] = groupLayers_Mod(allLayers,allRoughs,numberOfContrasts,geometry,nbairs,nbsubs)
    //
    //  INPUTS:
    //
    //      * allLayers =         cell array, one for each contrast. Each cell is the list of layer values for each contrast.
    //      * allRoughs =         Double of substrate roughness for each contrast.
    //      * numberOfContrasts = double.
    //      * geometry =          'Air / Liquid (or solid)' or 'Solid / Liquid'
    //      * nbairs =            vector of nbair values.
    //      * nbsubs =            vector of nbsub values.
    //
    //      The paratt calculation procedds through the
    //      z,rho,rough stack, and the parameter 'ssub' in
    //      callParatt is the final roughness encountered.
    //
    //      * For air liquid 'ssub' is therefore the substrate roughness.
    //
    //      * For solid liquid, the substrate roughness is the first roughness encountered, and 'ssub' is then the roughness of the outermost layer
    //
    //  Outputs:
    //
    //      * outLayers = cell array of layers param values for each contrast.
    //
    //      * outSsubs =  vector of substrate roughness values.
    //
    // outLayers = cell(1,numberOfContrasts);
    // outSsubs = zeros(1,numberOfContrasts);
    // for i = 1:numberOfContrasts
    *outSsubs = allRoughs;
    layers.set_size(allLayers.size(0), 5);
    loop_ub = allLayers.size(0);
    for (i = 0; i < 5; i++) {
      for (b_loop_ub = 0; b_loop_ub < loop_ub; b_loop_ub++) {
        layers[b_loop_ub + layers.size(0) * i] = 0.0;
      }
    }

    if (allLayers.size(0) != 0) {
      if (coder::internal::l_strcmp(geometry)) {
        layers.set_size(allLayers.size(0), 5);
        loop_ub = allLayers.size(0);
        for (i = 0; i < 5; i++) {
          for (b_loop_ub = 0; b_loop_ub < loop_ub; b_loop_ub++) {
            layers[b_loop_ub + layers.size(0) * i] = allLayers[b_loop_ub +
              allLayers.size(0) * i];
          }
        }

        // s_sub = rsub;
      } else {
        int32_T c_loop_ub;
        *outSsubs = allLayers[(allLayers.size(0) + allLayers.size(0) * 2) - 1];
        if (allLayers.size(0) > 1) {
          loop_ub = allLayers.size(0);
          roughs.set_size(allLayers.size(0));
          roughs[0] = allRoughs;
          for (i = 0; i <= loop_ub - 2; i++) {
            roughs[i + 1] = allLayers[i + allLayers.size(0) * 2];
          }
        } else {
          roughs.set_size(1);
          roughs[0] = allRoughs;
        }

        loop_ub = allLayers.size(0);
        b_loop_ub = allLayers.size(0);
        c_loop_ub = allLayers.size(0);
        layers.set_size(allLayers.size(0), 4);
        for (i = 0; i < loop_ub; i++) {
          layers[i] = allLayers[i];
        }

        for (i = 0; i < b_loop_ub; i++) {
          layers[i + layers.size(0)] = allLayers[i + allLayers.size(0)];
        }

        loop_ub = roughs.size(0);
        for (i = 0; i < loop_ub; i++) {
          layers[i + layers.size(0) * 2] = roughs[i];
        }

        for (i = 0; i < c_loop_ub; i++) {
          layers[i + layers.size(0) * 3] = allLayers[i + allLayers.size(0) * 3];
        }
      }

      // Deal with the %coverage if present
      i = allLayers.size(0);
      for (int32_T j{0}; j < i; j++) {
        real_T pc_add;
        real_T this_pcw;
        this_pcw = allLayers[j + allLayers.size(0) * 3];
        if (allLayers[j + allLayers.size(0) * 4] == 1.0) {
          pc_add = nbair;
        } else {
          pc_add = nbsubs;
        }

        if (!std::isnan(this_pcw)) {
          layers[j + layers.size(0)] = pc_add * (this_pcw / 100.0) + (1.0 -
            this_pcw / 100.0) * layers[j + layers.size(0)];
        }
      }
    }

    //      problem.layers{i} = layers;
    //      problem.ssubs(i) = s_sub;
    if (layers.size(0) != 0) {
      loop_ub = layers.size(0);
      outLayers.set_size(layers.size(0), 3);
      for (i = 0; i < 3; i++) {
        for (b_loop_ub = 0; b_loop_ub < loop_ub; b_loop_ub++) {
          outLayers[b_loop_ub + outLayers.size(0) * i] = layers[b_loop_ub +
            layers.size(0) * i];
        }
      }
    } else {
      outLayers.set_size(1, 3);
      outLayers[0] = 0.0;
      outLayers[outLayers.size(0)] = 0.0;
      outLayers[outLayers.size(0) * 2] = 0.0;
    }
  }

  void groupLayers_Mod(const ::coder::array<real_T, 2U> &allLayers, real_T
                       allRoughs, const ::coder::array<char_T, 2U> &geometry, ::
                       coder::array<real_T, 2U> &outLayers, real_T *outSsubs)
  {
    ::coder::array<real_T, 2U> layers;
    ::coder::array<real_T, 1U> roughs;
    int32_T b_loop_ub;
    int32_T i;
    int32_T i1;
    int32_T loop_ub;
    uint32_T unnamed_idx_0;

    // Arrange layers according to geometry and apply any coverage correction.
    //
    //  USAGE::
    //
    //      [outLayers, outSsubs] = groupLayers_Mod(allLayers,allRoughs,numberOfContrasts,geometry,nbairs,nbsubs)
    //
    //  INPUTS:
    //
    //      * allLayers =         cell array, one for each contrast. Each cell is the list of layer values for each contrast.
    //      * allRoughs =         Double of substrate roughness for each contrast.
    //      * numberOfContrasts = double.
    //      * geometry =          'Air / Liquid (or solid)' or 'Solid / Liquid'
    //      * nbairs =            vector of nbair values.
    //      * nbsubs =            vector of nbsub values.
    //
    //      The paratt calculation procedds through the
    //      z,rho,rough stack, and the parameter 'ssub' in
    //      callParatt is the final roughness encountered.
    //
    //      * For air liquid 'ssub' is therefore the substrate roughness.
    //
    //      * For solid liquid, the substrate roughness is the first roughness encountered, and 'ssub' is then the roughness of the outermost layer
    //
    //  Outputs:
    //
    //      * outLayers = cell array of layers param values for each contrast.
    //
    //      * outSsubs =  vector of substrate roughness values.
    //
    // outLayers = cell(1,numberOfContrasts);
    // outSsubs = zeros(1,numberOfContrasts);
    // for i = 1:numberOfContrasts
    *outSsubs = allRoughs;
    unnamed_idx_0 = static_cast<uint32_T>(allLayers.size(0));
    layers.set_size(allLayers.size(0), allLayers.size(1));
    loop_ub = allLayers.size(1);
    for (i = 0; i < loop_ub; i++) {
      b_loop_ub = static_cast<int32_T>(unnamed_idx_0);
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        layers[i1 + layers.size(0) * i] = 0.0;
      }
    }

    if (allLayers.size(0) != 0) {
      if (coder::internal::l_strcmp(geometry)) {
        layers.set_size(allLayers.size(0), allLayers.size(1));
        loop_ub = allLayers.size(1);
        for (i = 0; i < loop_ub; i++) {
          b_loop_ub = allLayers.size(0);
          for (i1 = 0; i1 < b_loop_ub; i1++) {
            layers[i1 + layers.size(0) * i] = allLayers[i1 + allLayers.size(0) *
              i];
          }
        }

        // s_sub = rsub;
      } else {
        *outSsubs = allLayers[(allLayers.size(0) + allLayers.size(0) * 2) - 1];
        if (allLayers.size(0) > 1) {
          loop_ub = allLayers.size(0);
          roughs.set_size(allLayers.size(0));
          roughs[0] = allRoughs;
          for (i = 0; i <= loop_ub - 2; i++) {
            roughs[i + 1] = allLayers[i + allLayers.size(0) * 2];
          }
        } else {
          roughs.set_size(1);
          roughs[0] = allRoughs;
        }

        loop_ub = allLayers.size(0);
        b_loop_ub = allLayers.size(0);
        layers.set_size(allLayers.size(0), 3);
        for (i = 0; i < loop_ub; i++) {
          layers[i] = allLayers[i];
        }

        for (i = 0; i < b_loop_ub; i++) {
          layers[i + layers.size(0)] = allLayers[i + allLayers.size(0)];
        }

        loop_ub = roughs.size(0);
        for (i = 0; i < loop_ub; i++) {
          layers[i + layers.size(0) * 2] = roughs[i];
        }
      }

      // Deal with the %coverage if present
    }

    //      problem.layers{i} = layers;
    //      problem.ssubs(i) = s_sub;
    if (layers.size(0) != 0) {
      loop_ub = layers.size(0);
      outLayers.set_size(layers.size(0), 3);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          outLayers[i1 + outLayers.size(0) * i] = layers[i1 + layers.size(0) * i];
        }
      }
    } else {
      outLayers.set_size(1, 3);
      outLayers[0] = 0.0;
      outLayers[outLayers.size(0)] = 0.0;
      outLayers[outLayers.size(0) * 2] = 0.0;
    }
  }
}

// End of code generation (groupLayers_Mod.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// groupLayers_Mod.h
//
// Code generation for function 'groupLayers_Mod'
//
#ifndef GROUPLAYERS_MOD_H
#define GROUPLAYERS_MOD_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  void groupLayers_Mod(const ::coder::array<real_T, 2U> &allLayers, real_T
                       allRoughs, const ::coder::array<char_T, 2U> &geometry,
                       real_T nbair, real_T nbsubs, ::coder::array<real_T, 2U>
                       &outLayers, real_T *outSsubs);
  void groupLayers_Mod(const ::coder::array<real_T, 2U> &allLayers, real_T
                       allRoughs, const ::coder::array<char_T, 2U> &geometry, ::
                       coder::array<real_T, 2U> &outLayers, real_T *outSsubs);
}

#endif

// End of code generation (groupLayers_Mod.h)

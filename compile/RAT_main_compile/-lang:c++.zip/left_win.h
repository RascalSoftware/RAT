//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// left_win.h
//
// Code generation for function 'left_win'
//
#ifndef LEFT_WIN_H
#define LEFT_WIN_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  real_T left_win(real_T S_x_I_no, real_T S_x_FVr_oa, real_T S_y_FVr_oa);
}

#endif

// End of code generation (left_win.h)

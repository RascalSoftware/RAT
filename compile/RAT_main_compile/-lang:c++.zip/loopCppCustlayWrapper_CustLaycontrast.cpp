//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// loopCppCustlayWrapper_CustLaycontrast.cpp
//
// Code generation for function 'loopCppCustlayWrapper_CustLaycontrast'
//

// Include files
#include "loopCppCustlayWrapper_CustLaycontrast.h"
#include "RAT_main_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Function Definitions
namespace RAT
{
  void loopCppCustlayWrapper_CustLaycontrast(real_T numberOfContrasts, ::coder::
    array<cell_wrap_30, 1U> &allLayers, ::coder::array<real_T, 1U> &allRoughs)
  {
    int32_T loop_ub_tmp;

    //  This is the function that deals with the *C++ Custom User Scripts*.
    //  This calls a mex called **testDLL_mex** which is a wrapper for the C++ class Library in **libManager.h**.
    //  Library Class uses **dylib.hpp** to load the dynamic library at runtime. The dynamic library would be the
    //  user's custom c++ script compiled into a **DLL/dylib/.so** file.
    //
    //      INPUTS:
    //
    //         * cBacks  :         Which background value is associated with each contrast
    //         * cShifts  :        Which qz_shift value is associated with each contrast
    //         * cScales  :        Which scalefactor value is associated with each contrast
    //         * cNbas  :          Which NBa value is associated with each contrast
    //         * cNbss  :          Which Nbs value is associated with each contrast
    //         * cRes  :           Which resolution value is associated with each contrast
    //         * backs  :          List of all background values.
    //         * shifts  :         List of all qz-shift values
    //         * sf :              List of all scalefactor values
    //         * nba :             List of all nba values
    //         * nbs :             List of all nbs values
    //         * res :             List of all resolution values
    //         * cCustFiles :
    //         * numberOfContrasts : Number of contrasts
    //         * customFiles :      Cell of all custom user script files
    //         * params :           Structure of all parameters
    //
    //
    //      OUTPUTS:
    //
    //         * allLayers :        Cell of all layers
    //         * allRoughs :        Cell of all roughnesses
    //
    loop_ub_tmp = static_cast<int32_T>(numberOfContrasts);
    allLayers.set_size(loop_ub_tmp);
    allRoughs.set_size(loop_ub_tmp);
    for (int32_T i{0}; i < loop_ub_tmp; i++) {
      allLayers[i].f1.size[0] = 2;
      allLayers[i].f1.size[1] = 1;
      allLayers[i].f1.data[0] = 1.0;
      allLayers[i].f1.data[1] = 1.0;
      allRoughs[i] = 0.0;
    }

    // ; % dll name must be same as function name
    // customFiles{1}{3};
    //      strLibName = string(LibName);
    //      strfunctionName = string(functionName);
  }
}

// End of code generation (loopCppCustlayWrapper_CustLaycontrast.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// loopCppCustlayWrapper_CustLaysingle.cpp
//
// Code generation for function 'loopCppCustlayWrapper_CustLaysingle'
//

// Include files
#include "loopCppCustlayWrapper_CustLaysingle.h"
#include "RAT_main_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Function Definitions
namespace RAT
{
  void loopCppCustlayWrapper_CustLaysingle(real_T numberOfContrasts, ::coder::
    array<cell_wrap_30, 1U> &allLayers, ::coder::array<real_T, 1U> &allRoughs)
  {
    int32_T loop_ub_tmp;
    loop_ub_tmp = static_cast<int32_T>(numberOfContrasts);
    allLayers.set_size(loop_ub_tmp);
    allRoughs.set_size(loop_ub_tmp);
    for (int32_T i{0}; i < loop_ub_tmp; i++) {
      allLayers[i].f1.size[0] = 2;
      allLayers[i].f1.size[1] = 1;
      allLayers[i].f1.data[0] = 1.0;
      allLayers[i].f1.data[1] = 1.0;
      allRoughs[i] = 0.0;
    }

    // ; % dll name must be same as function name
    // customFiles{1}{3};
    //      strLibName = string(LibName);
    //      strfunctionName = string(functionName);
  }
}

// End of code generation (loopCppCustlayWrapper_CustLaysingle.cpp)

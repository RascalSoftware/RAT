//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// lower.cpp
//
// Code generation for function 'lower'
//

// Include files
#include "lower.h"
#include "RAT_main_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  namespace coder
  {
    void lower(const ::coder::array<char_T, 2U> &x, ::coder::array<char_T, 2U>
               &y)
    {
      int32_T i;
      y.set_size(1, x.size(1));
      i = x.size(1);
      for (int32_T k{0}; k < i; k++) {
        y[k] = cv[static_cast<uint8_T>(x[k]) & 127];
      }
    }
  }
}

// End of code generation (lower.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// power.cpp
//
// Code generation for function 'power'
//

// Include files
#include "power.h"
#include "RAT_main_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  namespace coder
  {
    void power(const ::coder::array<real_T, 1U> &a, ::coder::array<real_T, 1U>
               &y)
    {
      int32_T N;
      y.set_size(a.size(0));
      N = a.size(0);
      for (int32_T k{0}; k < N; k++) {
        y[k] = rt_powd_snf(a[k], 2.0);
      }
    }
  }
}

// End of code generation (power.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// ratFminsearch.h
//
// Code generation for function 'ratFminsearch'
//
#ifndef RATFMINSEARCH_H
#define RATFMINSEARCH_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_wrap_1;
  struct cell_wrap_8;
  struct cell_wrap_6;
  struct struct2_T;
  struct e_struct_T;
  struct c_struct_T;
}

// Function Declarations
namespace RAT
{
  void ratFminsearch(::coder::array<real_T, 1U> &x, real_T options_MaxIter,
                     real_T options_MaxFunEvals, real_T options_TolX, real_T
                     options_TolFun, const char_T dis_data[], const int32_T
                     dis_size[2], const struct0_T *varargin_1, const ::coder::
                     array<cell_wrap_1, 2U> &varargin_2_f1, const ::coder::array<
                     cell_wrap_8, 2U> &varargin_2_f2, const ::coder::array<
                     cell_wrap_1, 2U> &varargin_2_f3, const ::coder::array<
                     cell_wrap_8, 2U> &varargin_2_f4, const ::coder::array<
                     cell_wrap_8, 2U> &varargin_2_f5, const ::coder::array<
                     cell_wrap_8, 1U> &varargin_2_f6, const ::coder::array<
                     cell_wrap_6, 2U> &varargin_2_f14, const struct2_T
                     *varargin_4, const e_struct_T *varargin_5, real_T *fval,
                     real_T *exitflag, c_struct_T *output);
}

#endif

// End of code generation (ratFminsearch.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// ratSendTextOutput.cpp
//
// Code generation for function 'ratSendTextOutput'
//

// Include files
#include "ratSendTextOutput.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <stdio.h>

// Function Definitions
namespace RAT
{
  void ratSendTextOutput(const ::coder::array<char_T, 2U> &outText)
  {
    ::coder::array<char_T, 2U> varargin_1;
    int32_T loop_ub;

    //  This is an overloaded version of 'ratSendTextOutput' for the compile.
    //  The 'real' one is the output class. We will think of a better solution
    //  later on.
    //  if isnumeric(outText)
    //      outText = sprintf('%g',outText);
    //  end
    varargin_1.set_size(1, outText.size(1) + 1);
    loop_ub = outText.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      varargin_1[i] = outText[i];
    }

    varargin_1[outText.size(1)] = '\x00';
    printf("%s \n", &varargin_1[0]);
    fflush(stdout);
  }
}

// End of code generation (ratSendTextOutput.cpp)

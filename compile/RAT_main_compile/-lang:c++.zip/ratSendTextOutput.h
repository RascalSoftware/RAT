//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// ratSendTextOutput.h
//
// Code generation for function 'ratSendTextOutput'
//
#ifndef RATSENDTEXTOUTPUT_H
#define RATSENDTEXTOUTPUT_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  void ratSendTextOutput(const ::coder::array<char_T, 2U> &outText);
}

#endif

// End of code generation (ratSendTextOutput.h)

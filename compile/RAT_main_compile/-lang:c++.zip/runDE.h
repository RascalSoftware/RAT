//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// runDE.h
//
// Code generation for function 'runDE'
//
#ifndef RUNDE_H
#define RUNDE_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct struct3_T;
  struct cell_wrap_1;
  struct cell_wrap_8;
  struct cell_wrap_6;
  struct struct_T;
  struct cell_10;
  struct struct1_T;
  struct struct2_T;
  struct b_struct_T;
  struct cell_wrap_9;
}

// Function Declarations
namespace RAT
{
  struct_T intrafun(const ::coder::array<real_T, 2U> &p, struct0_T *problemDef,
                    const ::coder::array<char_T, 2U> &controls_para, real_T
                    controls_calcSld, const real_T controls_resamPars[2], const
                    struct3_T *controls_checks, const ::coder::array<cell_wrap_1,
                    2U> &problemDef_cells_f1, const ::coder::array<cell_wrap_8,
                    2U> &problemDef_cells_f2, const ::coder::array<cell_wrap_1,
                    2U> &problemDef_cells_f3, const ::coder::array<cell_wrap_8,
                    2U> &problemDef_cells_f4, const ::coder::array<cell_wrap_8,
                    2U> &problemDef_cells_f5, const ::coder::array<cell_wrap_8,
                    1U> &problemDef_cells_f6, const ::coder::array<cell_wrap_6,
                    2U> &problemDef_cells_f14);
  void runDE(struct0_T *problemDef, const cell_10 *problemDef_cells, const
             struct1_T *problemDef_limits, const struct2_T *controls, b_struct_T
             *problem, cell_wrap_9 result_data[], int32_T result_size[2]);
}

#endif

// End of code generation (runDE.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// runSimplex.cpp
//
// Code generation for function 'runSimplex'
//

// Include files
#include "runSimplex.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_types.h"
#include "fitsetup.h"
#include "ratFminsearch.h"
#include "reflectivity_calculation_wrapper.h"
#include "rt_nonfinite.h"
#include "simplex_xtransform.h"
#include "strcmp.h"
#include "unpackparams.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace RAT
{
  void runSimplex(struct0_T *problemDef, const cell_10 *problemDef_cells, const
                  struct1_T *problemDef_limits, const struct2_T *controls,
                  b_struct_T *problem, cell_wrap_9 result_data[], int32_T
                  result_size[2])
  {
    static const char_T cv1[6]{ 'n', 'o', 't', 'i', 'f', 'y' };

    static const char_T b_cv[5]{ 'f', 'i', 'n', 'a', 'l' };

    ::coder::array<cell_wrap_0, 1U> b_problemDef;
    ::coder::array<real_T, 1U> x;
    ::coder::array<real_T, 1U> x0u;
    c_struct_T output;
    cell_11 result;
    e_struct_T expl_temp;
    real_T exitflag;
    real_T fval;
    int32_T dis_size[2];
    int32_T b_i;
    int32_T i;
    int32_T outsize_idx_0;
    char_T dis_data[6];
    fitsetup(problemDef, problemDef_cells->f7, problemDef_cells->f8,
             problemDef_cells->f9, problemDef_cells->f10, problemDef_cells->f11,
             problemDef_cells->f12, problemDef_cells->f13,
             problemDef_limits->params, problemDef_limits->backs,
             problemDef_limits->scales, problemDef_limits->shifts,
             problemDef_limits->nba, problemDef_limits->nbs,
             problemDef_limits->res, &controls->checks, b_problemDef);
    if (coder::internal::p_strcmp(controls->display)) {
      outsize_idx_0 = 0;
    } else if (coder::internal::q_strcmp(controls->display)) {
      outsize_idx_0 = 1;
    } else if (coder::internal::r_strcmp(controls->display)) {
      outsize_idx_0 = 2;
    } else if (coder::internal::s_strcmp(controls->display)) {
      outsize_idx_0 = 3;
    } else {
      outsize_idx_0 = -1;
    }

    switch (outsize_idx_0) {
     case 0:
      dis_size[0] = 1;
      dis_size[1] = 4;
      dis_data[0] = 'n';
      dis_data[1] = 'o';
      dis_data[2] = 'n';
      dis_data[3] = 'e';
      break;

     case 1:
      dis_size[0] = 1;
      dis_size[1] = 4;
      dis_data[0] = 'i';
      dis_data[1] = 't';
      dis_data[2] = 'e';
      dis_data[3] = 'r';
      break;

     case 2:
      dis_size[0] = 1;
      dis_size[1] = 6;
      for (i = 0; i < 6; i++) {
        dis_data[i] = cv1[i];
      }
      break;

     case 3:
      dis_size[0] = 1;
      dis_size[1] = 5;
      for (i = 0; i < 5; i++) {
        dis_data[i] = b_cv[i];
      }
      break;

     default:
      dis_size[0] = 1;
      dis_size[1] = 5;
      for (i = 0; i < 5; i++) {
        dis_data[i] = b_cv[i];
      }
      break;
    }

    outsize_idx_0 = problemDef->fitconstr.size(0);
    expl_temp.LB.set_size(outsize_idx_0);
    for (i = 0; i < outsize_idx_0; i++) {
      expl_temp.LB[i] = problemDef->fitconstr[i];
    }

    outsize_idx_0 = problemDef->fitconstr.size(0);
    expl_temp.UB.set_size(outsize_idx_0);
    for (i = 0; i < outsize_idx_0; i++) {
      expl_temp.UB[i] = problemDef->fitconstr[i + problemDef->fitconstr.size(0)];
    }

    //  size checks
    if (problemDef->fitconstr.size(0) == 0) {
      outsize_idx_0 = problemDef->fitpars.size(0) * problemDef->fitpars.size(1);
      expl_temp.LB.set_size(outsize_idx_0);
      for (i = 0; i < outsize_idx_0; i++) {
        expl_temp.LB[i] = rtMinusInf;
      }
    }

    if (problemDef->fitconstr.size(0) == 0) {
      outsize_idx_0 = problemDef->fitpars.size(0) * problemDef->fitpars.size(1);
      expl_temp.UB.set_size(outsize_idx_0);
      for (i = 0; i < outsize_idx_0; i++) {
        expl_temp.UB[i] = rtInf;
      }
    }

    //  stuff into a struct to pass around
    // varargin;
    // problemDef.modelFilename;%fun;
    //  0 --> unconstrained variable
    //  1 --> lower bound only
    //  2 --> upper bound only
    //  3 --> dual finite bounds
    outsize_idx_0 = problemDef->fitpars.size(0) * problemDef->fitpars.size(1);
    expl_temp.BoundClass.set_size(outsize_idx_0);
    for (i = 0; i < outsize_idx_0; i++) {
      expl_temp.BoundClass[i] = 0.0;
    }

    i = problemDef->fitpars.size(0) * problemDef->fitpars.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      expl_temp.BoundClass[b_i] = static_cast<real_T>((!std::isinf
        (expl_temp.LB[b_i])) && (!std::isnan(expl_temp.LB[b_i]))) +
        static_cast<real_T>(((!std::isinf(expl_temp.UB[b_i])) && (!std::isnan
        (expl_temp.UB[b_i]))) << 1);
    }

    //  transform starting values into their unconstrained
    //  surrogates. Check for infeasible starting guesses.
    outsize_idx_0 = problemDef->fitpars.size(0) * problemDef->fitpars.size(1);
    x0u.set_size(outsize_idx_0);
    for (i = 0; i < outsize_idx_0; i++) {
      x0u[i] = problemDef->fitpars[i];
    }

    i = problemDef->fitpars.size(0) * problemDef->fitpars.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      switch (static_cast<int32_T>(expl_temp.BoundClass[b_i])) {
       case 1:
        //  lower bound only
        if (problemDef->fitpars[b_i] <= expl_temp.LB[b_i]) {
          //  infeasible starting value. Use bound.
          x0u[b_i] = 0.0;
        } else {
          x0u[b_i] = std::sqrt(problemDef->fitpars[b_i] - expl_temp.LB[b_i]);
        }
        break;

       case 2:
        //  upper bound only
        if (problemDef->fitpars[b_i] >= expl_temp.UB[b_i]) {
          //  infeasible starting value. use bound.
          x0u[b_i] = 0.0;
        } else {
          x0u[b_i] = std::sqrt(expl_temp.UB[b_i] - problemDef->fitpars[b_i]);
        }
        break;

       case 3:
        //  lower and upper bounds
        if (problemDef->fitpars[b_i] <= expl_temp.LB[b_i]) {
          //  infeasible starting value
          x0u[b_i] = -1.5707963267948966;
        } else if (problemDef->fitpars[b_i] >= expl_temp.UB[b_i]) {
          //  infeasible starting value
          x0u[b_i] = 1.5707963267948966;
        } else {
          x0u[b_i] = 2.0 * (problemDef->fitpars[b_i] - expl_temp.LB[b_i]) /
            (expl_temp.UB[b_i] - expl_temp.LB[b_i]) - 1.0;
          x0u[b_i] = std::asin(std::fmax(-1.0, std::fmin(1.0, x0u[b_i])));
        }
        break;

       default:
        //  unconstrained variable. x0u(i) is set.
        break;
      }
    }

    //  now we can call fminsearch, but with our own
    //  intra-objective function.
    ratFminsearch(x0u, controls->maxIter, controls->maxFunEvals, controls->tolX,
                  controls->tolFun, dis_data, dis_size, problemDef,
                  problemDef_cells->f1, problemDef_cells->f2,
                  problemDef_cells->f3, problemDef_cells->f4,
                  problemDef_cells->f5, problemDef_cells->f6,
                  problemDef_cells->f14, controls, &expl_temp, &fval, &exitflag,
                  &output);

    // [xu,fval,exitflag,output] = simplex(@simplexIntrafun,x0u,problemDef,problemDef_cells,problemDef_limits,controls,options,params,300);
    //  undo the variable transformations into the original space
    simplex_xtransform(x0u, expl_temp.LB, expl_temp.UB, expl_temp.BoundClass, x);

    //  final reshape
    // x = reshape(x,xsize);
    outsize_idx_0 = x.size(0);
    problemDef->fitpars.set_size(x.size(0), 1);
    for (i = 0; i < 1; i++) {
      for (int32_T i1{0}; i1 < outsize_idx_0; i1++) {
        problemDef->fitpars[i1] = x[i1];
      }
    }

    unpackparams(problemDef, controls->checks.params_fitYesNo,
                 controls->checks.backs_fitYesNo,
                 controls->checks.shifts_fitYesNo,
                 controls->checks.scales_fitYesNo,
                 controls->checks.nbairs_fitYesNo,
                 controls->checks.nbsubs_fitYesNo,
                 controls->checks.resol_fitYesNo);
    reflectivity_calculation_wrapper(problemDef, problemDef_cells, controls,
      problem, &result);
    result_size[0] = 1;
    result_size[1] = 6;
    result_data[0].f1.set_size(result.f1.size(0));
    outsize_idx_0 = result.f1.size(0);
    for (i = 0; i < outsize_idx_0; i++) {
      result_data[0].f1[i] = result.f1[i];
    }

    result_data[result_size[0]].f1.set_size(result.f2.size(0));
    outsize_idx_0 = result.f2.size(0);
    for (i = 0; i < outsize_idx_0; i++) {
      result_data[1].f1[i] = result.f2[i];
    }

    result_data[result_size[0] * 2].f1.set_size(result.f3.size(0));
    outsize_idx_0 = result.f3.size(0);
    for (i = 0; i < outsize_idx_0; i++) {
      result_data[2].f1[i] = result.f3[i];
    }

    result_data[result_size[0] * 3].f1.set_size(result.f4.size(0));
    outsize_idx_0 = result.f4.size(0);
    for (i = 0; i < outsize_idx_0; i++) {
      result_data[3].f1[i] = result.f4[i];
    }

    result_data[result_size[0] * 4].f1.set_size(result.f5.size(0));
    outsize_idx_0 = result.f5.size(0);
    for (i = 0; i < outsize_idx_0; i++) {
      result_data[4].f1[i] = result.f5[i];
    }

    result_data[result_size[0] * 5].f1.set_size(result.f6.size(0));
    outsize_idx_0 = result.f6.size(0);
    for (i = 0; i < outsize_idx_0; i++) {
      result_data[5].f1[i] = result.f6[i];
    }
  }
}

// End of code generation (runSimplex.cpp)

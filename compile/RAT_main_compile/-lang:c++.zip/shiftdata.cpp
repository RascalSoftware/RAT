//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// shiftdata.cpp
//
// Code generation for function 'shiftdata'
//

// Include files
#include "shiftdata.h"
#include "find.h"
#include "linspace.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void shiftdata(real_T scalefac, real_T horshift, real_T dataPresent, ::coder::
                 array<real_T, 2U> &data, const real_T dataLimits[2], const
                 real_T simLimits_data[], ::coder::array<real_T, 2U>
                 &shifted_data)
  {
    ::coder::array<real_T, 1U> c_data;
    ::coder::array<int32_T, 1U> lowIndex;
    ::coder::array<boolean_T, 1U> d_data;
    real_T dv1[3][100];
    real_T dv[100];

    //  Shifts the data according to scale factor. If there is no data, makes
    //  x-data over the simulation range.
    //
    //  INPUTS:
    //
    //      * scalefac = problem.scalefactors;
    //      * horshift = problem.qshifts;
    //      * numberOfContrasts = problem.numberOfContrasts;
    //      * dataPresent = problem.dataPresent;
    //      * allData = problem.data;
    //      * dataLimits = problem.dataLimits;
    switch (static_cast<int32_T>(dataPresent)) {
     case 1:
      {
        int32_T b_data;
        int32_T b_lowIndex;
        int32_T hiIndex;
        int32_T i;
        int32_T i1;
        int32_T loop_ub;
        if (scalefac == 0.0) {
          scalefac = 1.0E-30;
        }

        b_data = data.size(0) - 1;
        c_data.set_size(data.size(0));
        for (i = 0; i <= b_data; i++) {
          c_data[i] = data[i] + horshift;
        }

        loop_ub = c_data.size(0);
        for (i = 0; i < loop_ub; i++) {
          data[i] = c_data[i];
        }

        b_data = data.size(0) - 1;
        c_data.set_size(data.size(0));
        for (i = 0; i <= b_data; i++) {
          c_data[i] = data[i + data.size(0)] / scalefac;
        }

        loop_ub = c_data.size(0);
        for (i = 0; i < loop_ub; i++) {
          data[i + data.size(0)] = c_data[i];
        }

        b_data = data.size(0) - 1;
        c_data.set_size(data.size(0));
        for (i = 0; i <= b_data; i++) {
          c_data[i] = data[i + data.size(0) * 2] / scalefac;
        }

        loop_ub = c_data.size(0);
        for (i = 0; i < loop_ub; i++) {
          data[i + data.size(0) * 2] = c_data[i];
        }

        loop_ub = data.size(0);
        d_data.set_size(data.size(0));
        for (i = 0; i < loop_ub; i++) {
          d_data[i] = (data[i] < dataLimits[0]);
        }

        coder::eml_find(d_data, lowIndex);
        if (lowIndex.size(0) != 0) {
          b_lowIndex = lowIndex[lowIndex.size(0) - 1];
        } else {
          b_lowIndex = 1;
        }

        loop_ub = data.size(0);
        d_data.set_size(data.size(0));
        for (i = 0; i < loop_ub; i++) {
          d_data[i] = (data[i] > dataLimits[1]);
        }

        coder::eml_find(d_data, lowIndex);
        if (lowIndex.size(0) != 0) {
          hiIndex = lowIndex[0];
        } else {
          hiIndex = data.size(0);
        }

        if (b_lowIndex > hiIndex) {
          i = 0;
          i1 = 0;
        } else {
          i = b_lowIndex - 1;
          i1 = hiIndex;
        }

        loop_ub = data.size(1);
        b_data = i1 - i;
        shifted_data.set_size(b_data, data.size(1));
        for (i1 = 0; i1 < loop_ub; i1++) {
          for (int32_T i2{0}; i2 < b_data; i2++) {
            shifted_data[i2 + shifted_data.size(0) * i1] = data[(i + i2) +
              data.size(0) * i1];
          }
        }
      }
      break;

     default:
      {
        int32_T i;
        coder::linspace(simLimits_data[0], simLimits_data[1], dv);
        for (i = 0; i < 100; i++) {
          dv1[0][i] = dv[i];
          dv1[1][i] = 0.0;
          dv1[2][i] = 0.0;
        }

        shifted_data.set_size(100, 3);
        for (i = 0; i < 3; i++) {
          for (int32_T i1{0}; i1 < 100; i1++) {
            shifted_data[i1 + shifted_data.size(0) * i] = dv1[i][i1];
          }
        }
      }
      break;
    }
  }
}

// End of code generation (shiftdata.cpp)

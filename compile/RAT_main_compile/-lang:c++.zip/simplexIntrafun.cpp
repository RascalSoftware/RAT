//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// simplexIntrafun.cpp
//
// Code generation for function 'simplexIntrafun'
//

// Include files
#include "simplexIntrafun.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_types.h"
#include "reflectivity_calculation_wrapper.h"
#include "rt_nonfinite.h"
#include "simplex_xtransform.h"
#include "unpackparams.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  real_T simplexIntrafun(const ::coder::array<real_T, 1U> &x, struct0_T
    *problemDef, const ::coder::array<cell_wrap_1, 2U> &problemDef_cells_f1,
    const ::coder::array<cell_wrap_8, 2U> &problemDef_cells_f2, const ::coder::
    array<cell_wrap_1, 2U> &problemDef_cells_f3, const ::coder::array<
    cell_wrap_8, 2U> &problemDef_cells_f4, const ::coder::array<cell_wrap_8, 2U>
    &problemDef_cells_f5, const ::coder::array<cell_wrap_8, 1U>
    &problemDef_cells_f6, const ::coder::array<cell_wrap_6, 2U>
    &problemDef_cells_f14, const struct2_T *controls, const ::coder::array<
    real_T, 1U> &params_LB, const ::coder::array<real_T, 1U> &params_UB, const ::
    coder::array<real_T, 1U> &params_BoundClass)
  {
    ::coder::array<real_T, 1U> xtrans;
    b_struct_T b_problemDef;
    cell_10 expl_temp;
    cell_11 result;
    int32_T i;
    int32_T xtrans_idx_0;

    // problemDef,problemDef_cells,problemDef_limits,controls,params,300
    //  transform variables, then call original function
    //  transform
    simplex_xtransform(x, params_LB, params_UB, params_BoundClass, xtrans);

    // Unpck the params..
    xtrans_idx_0 = xtrans.size(0);
    problemDef->fitpars.set_size(xtrans.size(0), 1);
    for (i = 0; i < 1; i++) {
      for (int32_T i1{0}; i1 < xtrans_idx_0; i1++) {
        problemDef->fitpars[i1] = xtrans[i1];
      }
    }

    unpackparams(problemDef, controls->checks.params_fitYesNo,
                 controls->checks.backs_fitYesNo,
                 controls->checks.shifts_fitYesNo,
                 controls->checks.scales_fitYesNo,
                 controls->checks.nbairs_fitYesNo,
                 controls->checks.nbsubs_fitYesNo,
                 controls->checks.resol_fitYesNo);
    expl_temp.f14.set_size(1, problemDef_cells_f14.size(1));
    xtrans_idx_0 = problemDef_cells_f14.size(1);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f14[i] = problemDef_cells_f14[i];
    }

    expl_temp.f6.set_size(problemDef_cells_f6.size(0));
    xtrans_idx_0 = problemDef_cells_f6.size(0);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f6[i] = problemDef_cells_f6[i];
    }

    expl_temp.f5.set_size(1, problemDef_cells_f5.size(1));
    xtrans_idx_0 = problemDef_cells_f5.size(1);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f5[i] = problemDef_cells_f5[i];
    }

    expl_temp.f4.set_size(1, problemDef_cells_f4.size(1));
    xtrans_idx_0 = problemDef_cells_f4.size(1);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f4[i] = problemDef_cells_f4[i];
    }

    expl_temp.f3.set_size(1, problemDef_cells_f3.size(1));
    xtrans_idx_0 = problemDef_cells_f3.size(1);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f3[i] = problemDef_cells_f3[i];
    }

    expl_temp.f2.set_size(1, problemDef_cells_f2.size(1));
    xtrans_idx_0 = problemDef_cells_f2.size(1);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f2[i] = problemDef_cells_f2[i];
    }

    expl_temp.f1.set_size(1, problemDef_cells_f1.size(1));
    xtrans_idx_0 = problemDef_cells_f1.size(1);
    for (i = 0; i < xtrans_idx_0; i++) {
      expl_temp.f1[i] = problemDef_cells_f1[i];
    }

    reflectivity_calculation_wrapper(problemDef, &expl_temp, controls,
      &b_problemDef, &result);
    return b_problemDef.calculations.sum_chi;
  }
}

// End of code generation (simplexIntrafun.cpp)

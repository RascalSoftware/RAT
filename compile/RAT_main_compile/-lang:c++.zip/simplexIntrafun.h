//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// simplexIntrafun.h
//
// Code generation for function 'simplexIntrafun'
//
#ifndef SIMPLEXINTRAFUN_H
#define SIMPLEXINTRAFUN_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_wrap_1;
  struct cell_wrap_8;
  struct cell_wrap_6;
  struct struct2_T;
}

// Function Declarations
namespace RAT
{
  real_T simplexIntrafun(const ::coder::array<real_T, 1U> &x, struct0_T
    *problemDef, const ::coder::array<cell_wrap_1, 2U> &problemDef_cells_f1,
    const ::coder::array<cell_wrap_8, 2U> &problemDef_cells_f2, const ::coder::
    array<cell_wrap_1, 2U> &problemDef_cells_f3, const ::coder::array<
    cell_wrap_8, 2U> &problemDef_cells_f4, const ::coder::array<cell_wrap_8, 2U>
    &problemDef_cells_f5, const ::coder::array<cell_wrap_8, 1U>
    &problemDef_cells_f6, const ::coder::array<cell_wrap_6, 2U>
    &problemDef_cells_f14, const struct2_T *controls, const ::coder::array<
    real_T, 1U> &params_LB, const ::coder::array<real_T, 1U> &params_UB, const ::
    coder::array<real_T, 1U> &params_BoundClass);
}

#endif

// End of code generation (simplexIntrafun.h)

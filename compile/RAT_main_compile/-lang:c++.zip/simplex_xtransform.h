//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// simplex_xtransform.h
//
// Code generation for function 'simplex_xtransform'
//
#ifndef SIMPLEX_XTRANSFORM_H
#define SIMPLEX_XTRANSFORM_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  void simplex_xtransform(const ::coder::array<real_T, 1U> &x, const ::coder::
    array<real_T, 1U> &params_LB, const ::coder::array<real_T, 1U> &params_UB,
    const ::coder::array<real_T, 1U> &params_BoundClass, ::coder::array<real_T,
    1U> &xtrans);
}

#endif

// End of code generation (simplex_xtransform.h)

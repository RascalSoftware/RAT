//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// singleCalculation.cpp
//
// Code generation for function 'singleCalculation'
//

// Include files
#include "singleCalculation.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_types.h"
#include "reflectivity_calculation_wrapper.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void singleCalculation(const struct0_T *problemDef, const cell_10
    *problemDef_cells, const struct2_T *controls, b_struct_T *problem,
    cell_wrap_9 result_data[], int32_T result_size[2])
  {
    cell_11 result;
    int32_T i;
    int32_T loop_ub;

    // Just call the reflectivity calculation.
    // Any additional argument checking etc will go in here...
    reflectivity_calculation_wrapper(problemDef, problemDef_cells, controls,
      problem, &result);
    result_size[0] = 1;
    result_size[1] = 6;
    result_data[0].f1.set_size(result.f1.size(0));
    loop_ub = result.f1.size(0);
    for (i = 0; i < loop_ub; i++) {
      result_data[0].f1[i] = result.f1[i];
    }

    result_data[result_size[0]].f1.set_size(result.f2.size(0));
    loop_ub = result.f2.size(0);
    for (i = 0; i < loop_ub; i++) {
      result_data[1].f1[i] = result.f2[i];
    }

    result_data[result_size[0] * 2].f1.set_size(result.f3.size(0));
    loop_ub = result.f3.size(0);
    for (i = 0; i < loop_ub; i++) {
      result_data[2].f1[i] = result.f3[i];
    }

    result_data[result_size[0] * 3].f1.set_size(result.f4.size(0));
    loop_ub = result.f4.size(0);
    for (i = 0; i < loop_ub; i++) {
      result_data[3].f1[i] = result.f4[i];
    }

    result_data[result_size[0] * 4].f1.set_size(result.f5.size(0));
    loop_ub = result.f5.size(0);
    for (i = 0; i < loop_ub; i++) {
      result_data[4].f1[i] = result.f5[i];
    }

    result_data[result_size[0] * 5].f1.set_size(result.f6.size(0));
    loop_ub = result.f6.size(0);
    for (i = 0; i < loop_ub; i++) {
      result_data[5].f1[i] = result.f6[i];
    }
  }
}

// End of code generation (singleCalculation.cpp)

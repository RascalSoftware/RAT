//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// singleCalculation.h
//
// Code generation for function 'singleCalculation'
//
#ifndef SINGLECALCULATION_H
#define SINGLECALCULATION_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_10;
  struct struct2_T;
  struct b_struct_T;
  struct cell_wrap_9;
}

// Function Declarations
namespace RAT
{
  void singleCalculation(const struct0_T *problemDef, const cell_10
    *problemDef_cells, const struct2_T *controls, b_struct_T *problem,
    cell_wrap_9 result_data[], int32_T result_size[2]);
}

#endif

// End of code generation (singleCalculation.h)

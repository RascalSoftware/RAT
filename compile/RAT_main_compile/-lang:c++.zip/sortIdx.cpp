//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// sortIdx.cpp
//
// Code generation for function 'sortIdx'
//

// Include files
#include "sortIdx.h"
#include "mergesort.h"
#include "rt_nonfinite.h"
#include "sortLE.h"
#include "coder_array.h"

// Function Declarations
namespace RAT
{
  namespace coder
  {
    namespace internal
    {
      static void merge(::coder::array<int32_T, 2U> &idx, ::coder::array<real_T,
                        2U> &x, int32_T offset, int32_T np, int32_T nq, ::coder::
                        array<int32_T, 1U> &iwork, ::coder::array<real_T, 1U>
                        &xwork);
    }
  }
}

// Function Definitions
namespace RAT
{
  namespace coder
  {
    namespace internal
    {
      static void merge(::coder::array<int32_T, 2U> &idx, ::coder::array<real_T,
                        2U> &x, int32_T offset, int32_T np, int32_T nq, ::coder::
                        array<int32_T, 1U> &iwork, ::coder::array<real_T, 1U>
                        &xwork)
      {
        if (nq != 0) {
          int32_T iout;
          int32_T j;
          int32_T n_tmp;
          int32_T p;
          int32_T q;
          n_tmp = np + nq;
          for (j = 0; j < n_tmp; j++) {
            iout = offset + j;
            iwork[j] = idx[iout];
            xwork[j] = x[iout];
          }

          p = 0;
          q = np;
          iout = offset - 1;
          int32_T exitg1;
          do {
            exitg1 = 0;
            iout++;
            if (xwork[p] <= xwork[q]) {
              idx[iout] = iwork[p];
              x[iout] = xwork[p];
              if (p + 1 < np) {
                p++;
              } else {
                exitg1 = 1;
              }
            } else {
              idx[iout] = iwork[q];
              x[iout] = xwork[q];
              if (q + 1 < n_tmp) {
                q++;
              } else {
                q = iout - p;
                for (j = p + 1; j <= np; j++) {
                  iout = q + j;
                  idx[iout] = iwork[j - 1];
                  x[iout] = xwork[j - 1];
                }

                exitg1 = 1;
              }
            }
          } while (exitg1 == 0);
        }
      }

      void merge_block(::coder::array<int32_T, 2U> &idx, ::coder::array<real_T,
                       2U> &x, int32_T offset, int32_T n, int32_T preSortLevel, ::
                       coder::array<int32_T, 1U> &iwork, ::coder::array<real_T,
                       1U> &xwork)
      {
        int32_T bLen;
        int32_T nPairs;
        nPairs = n >> preSortLevel;
        bLen = 1 << preSortLevel;
        while (nPairs > 1) {
          int32_T nTail;
          int32_T tailOffset;
          if ((nPairs & 1) != 0) {
            nPairs--;
            tailOffset = bLen * nPairs;
            nTail = n - tailOffset;
            if (nTail > bLen) {
              merge(idx, x, offset + tailOffset, bLen, nTail - bLen, iwork,
                    xwork);
            }
          }

          tailOffset = bLen << 1;
          nPairs >>= 1;
          for (nTail = 0; nTail < nPairs; nTail++) {
            merge(idx, x, offset + nTail * tailOffset, bLen, bLen, iwork, xwork);
          }

          bLen = tailOffset;
        }

        if (n > bLen) {
          merge(idx, x, offset, bLen, n - bLen, iwork, xwork);
        }
      }

      void merge_pow2_block(::coder::array<int32_T, 2U> &idx, ::coder::array<
                            real_T, 2U> &x, int32_T offset)
      {
        real_T xwork[256];
        int32_T iwork[256];
        for (int32_T b{0}; b < 6; b++) {
          int32_T bLen;
          int32_T bLen2;
          int32_T nPairs;
          bLen = 1 << (b + 2);
          bLen2 = bLen << 1;
          nPairs = 256 >> (b + 3);
          for (int32_T k{0}; k < nPairs; k++) {
            int32_T blockOffset;
            int32_T iout;
            int32_T j;
            int32_T p;
            int32_T q;
            blockOffset = offset + k * bLen2;
            for (j = 0; j < bLen2; j++) {
              iout = blockOffset + j;
              iwork[j] = idx[iout];
              xwork[j] = x[iout];
            }

            p = 0;
            q = bLen;
            iout = blockOffset - 1;
            int32_T exitg1;
            do {
              exitg1 = 0;
              iout++;
              if (xwork[p] <= xwork[q]) {
                idx[iout] = iwork[p];
                x[iout] = xwork[p];
                if (p + 1 < bLen) {
                  p++;
                } else {
                  exitg1 = 1;
                }
              } else {
                idx[iout] = iwork[q];
                x[iout] = xwork[q];
                if (q + 1 < bLen2) {
                  q++;
                } else {
                  iout -= p;
                  for (j = p + 1; j <= bLen; j++) {
                    q = iout + j;
                    idx[q] = iwork[j - 1];
                    x[q] = xwork[j - 1];
                  }

                  exitg1 = 1;
                }
              }
            } while (exitg1 == 0);
          }
        }
      }

      void sortIdx(const ::coder::array<real_T, 2U> &x, ::coder::array<int32_T,
                   2U> &idx)
      {
        ::coder::array<int32_T, 1U> iwork;
        int32_T b_i;
        int32_T i;
        int32_T k;
        int32_T loop_ub;
        int32_T qEnd;
        idx.set_size(1, x.size(1));
        loop_ub = x.size(1);
        for (i = 0; i < loop_ub; i++) {
          idx[i] = 0;
        }

        loop_ub = x.size(1) + 1;
        iwork.set_size(x.size(1));
        i = x.size(1) - 1;
        for (k = 1; k <= i; k += 2) {
          if (sortLE(x, k, k + 1)) {
            idx[k - 1] = k;
            idx[k] = k + 1;
          } else {
            idx[k - 1] = k + 1;
            idx[k] = k;
          }
        }

        if ((x.size(1) & 1) != 0) {
          idx[x.size(1) - 1] = x.size(1);
        }

        b_i = 2;
        while (b_i < loop_ub - 1) {
          int32_T i2;
          int32_T j;
          i2 = b_i << 1;
          j = 1;
          for (int32_T pEnd{b_i + 1}; pEnd < loop_ub; pEnd = qEnd + b_i) {
            int32_T kEnd;
            int32_T p;
            int32_T q;
            p = j;
            q = pEnd;
            qEnd = j + i2;
            if (qEnd > loop_ub) {
              qEnd = loop_ub;
            }

            k = 0;
            kEnd = qEnd - j;
            while (k + 1 <= kEnd) {
              int32_T i1;
              i = idx[q - 1];
              i1 = idx[p - 1];
              if (sortLE(x, i1, i)) {
                iwork[k] = i1;
                p++;
                if (p == pEnd) {
                  while (q < qEnd) {
                    k++;
                    iwork[k] = idx[q - 1];
                    q++;
                  }
                }
              } else {
                iwork[k] = i;
                q++;
                if (q == qEnd) {
                  while (p < pEnd) {
                    k++;
                    iwork[k] = idx[p - 1];
                    p++;
                  }
                }
              }

              k++;
            }

            for (k = 0; k < kEnd; k++) {
              idx[(j + k) - 1] = iwork[k];
            }

            j = qEnd;
          }

          b_i = i2;
        }
      }

      void sortIdx(const ::coder::array<real_T, 2U> &x, const int32_T col_data[],
                   ::coder::array<int32_T, 1U> &idx)
      {
        int32_T k;
        int32_T n;
        n = x.size(0);
        idx.set_size(x.size(0));
        k = x.size(0);
        for (int32_T i{0}; i < k; i++) {
          idx[i] = 0;
        }

        if (x.size(0) == 0) {
          for (k = 0; k < n; k++) {
            idx[k] = k + 1;
          }
        } else {
          b_mergesort(idx, x, col_data, x.size(0));
        }
      }
    }
  }
}

// End of code generation (sortIdx.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// sprintf.cpp
//
// Code generation for function 'sprintf'
//

// Include files
#include "sprintf.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <algorithm>
#include <cstddef>
#include <stdio.h>

// Function Definitions
namespace RAT
{
  namespace coder
  {
    void b_sprintf(real_T varargin_1, real_T varargin_2, ::coder::array<char_T,
                   2U> &str)
    {
      int32_T nbytes;
      nbytes = snprintf(nullptr, 0,
                        "Exiting - X satisfies termination criteria: TolX %e, TolF %e",
                        varargin_1, varargin_2);
      str.set_size(1, nbytes + 1);
      snprintf(&str[0], (size_t)(nbytes + 1),
               "Exiting - X satisfies termination criteria: TolX %e, TolF %e",
               varargin_1, varargin_2);
      if (1 > nbytes) {
        nbytes = 0;
      }

      str.set_size(str.size(0), nbytes);
    }

    void snPrint(real_T varargin_1, real_T varargin_2, real_T varargin_3, const
                 char_T varargin_4_data[], const int32_T varargin_4_size[2], ::
                 coder::array<char_T, 2U> &str)
    {
      int32_T loop_ub;
      int32_T nbytes;
      char_T b_varargin_4_data[17];
      loop_ub = varargin_4_size[1];
      if (0 <= loop_ub - 1) {
        std::copy(&varargin_4_data[0], &varargin_4_data[loop_ub],
                  &b_varargin_4_data[0]);
      }

      nbytes = snprintf(nullptr, 0, " %5.0f        %5.0f     %12.6g         %s",
                        varargin_1, varargin_2, varargin_3, &b_varargin_4_data[0]);
      str.set_size(1, nbytes + 1);
      loop_ub = varargin_4_size[1];
      if (0 <= loop_ub - 1) {
        std::copy(&varargin_4_data[0], &varargin_4_data[loop_ub],
                  &b_varargin_4_data[0]);
      }

      snprintf(&str[0], (size_t)(nbytes + 1),
               " %5.0f        %5.0f     %12.6g         %s", varargin_1,
               varargin_2, varargin_3, &b_varargin_4_data[0]);
      if (1 > nbytes) {
        nbytes = 0;
      }

      str.set_size(str.size(0), nbytes);
    }

    void snPrint(real_T varargin_1, real_T varargin_2, real_T varargin_3, real_T
                 varargin_4, real_T varargin_5, ::coder::array<char_T, 2U> &str)
    {
      int32_T nbytes;
      nbytes = snprintf(nullptr, 0,
                        "Iteration: %g,  Best: %f,  F_weight: %f,  F_CR: %f,  I_NP: %g\n",
                        varargin_1, varargin_2, varargin_3, varargin_4,
                        varargin_5);
      str.set_size(1, nbytes + 1);
      snprintf(&str[0], (size_t)(nbytes + 1),
               "Iteration: %g,  Best: %f,  F_weight: %f,  F_CR: %f,  I_NP: %g\n",
               varargin_1, varargin_2, varargin_3, varargin_4, varargin_5);
      if (1 > nbytes) {
        nbytes = 0;
      }

      str.set_size(str.size(0), nbytes);
    }
  }
}

// End of code generation (sprintf.cpp)

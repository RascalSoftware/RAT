//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custXY_paraPoints.h
//
// Code generation for function 'standardTF_custXY_paraPoints'
//
#ifndef STANDARDTF_CUSTXY_PARAPOINTS_H
#define STANDARDTF_CUSTXY_PARAPOINTS_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct cell_10;
  struct struct2_T;
  struct cell_wrap_14;
  struct cell_wrap_8;
  struct cell_wrap_15;
}

// Function Declarations
namespace RAT
{
  void standardTF_custXY_paraPoints(const ::coder::array<real_T, 2U>
    &problemDef_contrastBacks, const ::coder::array<real_T, 2U>
    &problemDef_contrastBacksType, const ::coder::array<real_T, 2U>
    &problemDef_dataPresent, real_T problemDef_numberOfContrasts, const ::coder::
    array<real_T, 2U> &problemDef_contrastShifts, const ::coder::array<real_T,
    2U> &problemDef_contrastScales, const ::coder::array<real_T, 2U>
    &problemDef_contrastNbas, const ::coder::array<real_T, 2U>
    &problemDef_contrastNbss, const ::coder::array<real_T, 2U>
    &problemDef_contrastRes, const ::coder::array<real_T, 2U> &problemDef_backs,
    const ::coder::array<real_T, 2U> &problemDef_shifts, const ::coder::array<
    real_T, 2U> &problemDef_sf, const ::coder::array<real_T, 2U> &problemDef_nba,
    const ::coder::array<real_T, 2U> &problemDef_nbs, const ::coder::array<
    real_T, 2U> &problemDef_res, const ::coder::array<real_T, 2U>
    &problemDef_params, const cell_10 *problemDef_cells, const struct2_T
    *controls, ::coder::array<real_T, 1U> &outSsubs, ::coder::array<real_T, 1U>
    &backgs, ::coder::array<real_T, 1U> &qshifts, ::coder::array<real_T, 1U>
    &sfs, ::coder::array<real_T, 1U> &nbas, ::coder::array<real_T, 1U> &nbss, ::
    coder::array<real_T, 1U> &resols, ::coder::array<real_T, 1U> &chis, ::coder::
    array<cell_wrap_14, 1U> &reflectivity, ::coder::array<cell_wrap_14, 1U>
    &Simulation, ::coder::array<cell_wrap_8, 1U> &shifted_data, ::coder::array<
    cell_wrap_15, 1U> &layerSlds, ::coder::array<cell_wrap_8, 1U> &sldProfiles, ::
    coder::array<cell_wrap_8, 1U> &allLayers, ::coder::array<real_T, 1U>
    &allRoughs);
}

#endif

// End of code generation (standardTF_custXY_paraPoints.h)

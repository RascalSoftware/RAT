//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custlay_paraPoints.cpp
//
// Code generation for function 'standardTF_custlay_paraPoints'
//

// Include files
#include "standardTF_custlay_paraPoints.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_rtwutil.h"
#include "RAT_main_types.h"
#include "backSort.h"
#include "loopCppCustlayWrapper_CustLaysingle.h"
#include "loopMatalbCustlayWrapper_CustLaysingle.h"
#include "rt_nonfinite.h"
#include "standardTF_layers_core.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void standardTF_custlay_paraPoints(const struct0_T *problemDef, const cell_10 *
    problemDef_cells, const struct2_T *controls, ::coder::array<real_T, 1U>
    &outSsubs, ::coder::array<real_T, 1U> &backgs, ::coder::array<real_T, 1U>
    &qshifts, ::coder::array<real_T, 1U> &sfs, ::coder::array<real_T, 1U> &nbas,
    ::coder::array<real_T, 1U> &nbss, ::coder::array<real_T, 1U> &resols, ::
    coder::array<real_T, 1U> &chis, ::coder::array<cell_wrap_14, 1U>
    &reflectivity, ::coder::array<cell_wrap_14, 1U> &Simulation, ::coder::array<
    cell_wrap_8, 1U> &shifted_data, ::coder::array<cell_wrap_15, 1U> &layerSlds,
    ::coder::array<cell_wrap_8, 1U> &sldProfiles, ::coder::array<cell_wrap_8, 1U>
    &allLayers, ::coder::array<real_T, 1U> &allRoughs)
  {
    ::coder::array<cell_wrap_30, 1U> r;
    ::coder::array<real_T, 2U> resamLayers;
    ::coder::array<real_T, 2U> shifted_dat;
    ::coder::array<real_T, 2U> sldProfile;
    real_T thisBackground;
    real_T thisNba;
    real_T thisNbs;
    real_T thisQshift;
    real_T thisResol;
    real_T thisSf;
    int32_T b_index;
    int32_T i;
    int32_T loop_ub_tmp;

    //  Multi threaded version of the custom layers over reflectivity poimnts
    //  for standardTF reflectivity calculation.
    //  The function extracts the relevant parameters from the input
    //  arrays, allocates these on a pre-contrast basis, then calls the 'core'
    //  calculation (the core layers standardTf calc is shared between multiple
    //  calculation types).
    //  Extract individual cell arrays
    //  Splits up the master input list of all arrays into separate arrays
    //  The min input array 'problemDef_cells' is a master array where
    //  all the cell arrays are grouped together. There are
    //  repeatLayers      - controls repeating of the layers stack
    //  allData           - Array of all the data arrays
    //  dataLimits        - Min max limits in q for the data arrays
    //  simLimits         - Limits in Q for the reflkectivity simulations
    //  Layers details    - Master array of all available layers
    //  contrastLayers    - Which specific combination of arrays are needed for
    //                      each contrast.
    //  Custom files      - Filenames and path for any custom files used
    //  Extract individual parameters from problemDef struct
    // Extract individual parameters from problemDef
    //  Pre-Allocation of output arrays...
    //    --- Begin Memory Allocation ---
    loop_ub_tmp = static_cast<int32_T>(problemDef->numberOfContrasts);
    backgs.set_size(loop_ub_tmp);
    allRoughs.set_size(loop_ub_tmp);
    allLayers.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      allRoughs[i] = 0.0;
      allLayers[i].f1.set_size(2, 1);
      allLayers[i].f1[0] = 1.0;
      allLayers[i].f1[1] = 1.0;
    }

    //    --- End Memory Allocation ---
    //  Depending on custom layer language we change the functions used
    //  so if there are multiple language models we should have a variable that seeks what language model is being used
    if (coder::internal::m_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
      b_index = 0;
    } else if (coder::internal::n_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
      b_index = 1;
    } else {
      b_index = -1;
    }

    switch (b_index) {
     case 0:
      //  Call the Matlab parallel loop to process the custom models.....
      loopMatalbCustlayWrapper_CustLaysingle(problemDef->numberOfContrasts,
        allLayers, allRoughs);

      //
      break;

     case 1:
      loopCppCustlayWrapper_CustLaysingle(problemDef->numberOfContrasts, r,
        allRoughs);
      cast(r, allLayers);
      break;
    }

    //  Single cored over all contrasts
    outSsubs.set_size(loop_ub_tmp);
    sldProfiles.set_size(loop_ub_tmp);
    reflectivity.set_size(loop_ub_tmp);
    Simulation.set_size(loop_ub_tmp);
    shifted_data.set_size(loop_ub_tmp);
    layerSlds.set_size(loop_ub_tmp);
    chis.set_size(loop_ub_tmp);
    qshifts.set_size(loop_ub_tmp);
    sfs.set_size(loop_ub_tmp);
    nbas.set_size(loop_ub_tmp);
    nbss.set_size(loop_ub_tmp);
    resols.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      int32_T b_i;
      int32_T i1;

      //  Extract the relevant parameter values for this contrast
      //  from the input arrays.
      //  First need to decide which values of the backrounds, scalefactors
      //  data shifts and bulk contrasts are associated with this contrast
      backSort(problemDef->contrastBacks[i], problemDef->contrastShifts[i],
               problemDef->contrastScales[i], problemDef->contrastNbas[i],
               problemDef->contrastNbss[i], problemDef->contrastRes[i],
               problemDef->backs, problemDef->shifts, problemDef->sf,
               problemDef->nba, problemDef->nbs, problemDef->res,
               &thisBackground, &thisQshift, &thisSf, &thisNba, &thisNbs,
               &thisResol);

      //  Call the custom layers function to get the layers array...
      //  For the other parameters, we extract the correct ones from the input
      //  arrays
      //  Now call the core standardTF_stanlay reflectivity calculation
      //  In this case we are single cored, so we do not parallelise over
      //  points
      //  Call the reflectivity calculation
      d_standardTF_layers_core(allLayers[i].f1, allRoughs[i],
        problemDef->geometry, thisNba, thisNbs, problemDef->resample[i],
        controls->calcSld, thisSf, thisQshift, problemDef->dataPresent[i],
        problemDef_cells->f2[i].f1, problemDef_cells->f3[i].f1, (real_T *)((::
        coder::array<real_T, 2U> *)&problemDef_cells->f4[i].f1)->data(),
        problemDef_cells->f1[i].f1, thisBackground, thisResol,
        problemDef->contrastBacksType[i], static_cast<real_T>
        (problemDef->params.size(1)), controls->resamPars, sldProfile,
        reflectivity[i].f1, Simulation[i].f1, shifted_dat, layerSlds[i].f1,
        resamLayers, &chis[i], &outSsubs[i]);

      //  Store returned values for this contrast in the output arrays.
      //  As well as the calculated profiles, we also store a record of
      //  the other values (background, scalefactors etc) for each contrast
      //  for future use.
      b_index = sldProfile.size(0);
      sldProfiles[i].f1.set_size(sldProfile.size(0), 2);
      for (b_i = 0; b_i < 2; b_i++) {
        for (i1 = 0; i1 < b_index; i1++) {
          sldProfiles[i].f1[i1 + sldProfiles[i].f1.size(0) * b_i] =
            sldProfile[i1 + sldProfile.size(0) * b_i];
        }
      }

      b_index = shifted_dat.size(1);
      shifted_data[i].f1.set_size(shifted_dat.size(0), shifted_dat.size(1));
      for (b_i = 0; b_i < b_index; b_i++) {
        int32_T loop_ub;
        loop_ub = shifted_dat.size(0);
        for (i1 = 0; i1 < loop_ub; i1++) {
          shifted_data[i].f1[i1 + shifted_data[i].f1.size(0) * b_i] =
            shifted_dat[i1 + shifted_dat.size(0) * b_i];
        }
      }

      b_index = resamLayers.size(0);
      allLayers[i].f1.set_size(resamLayers.size(0), 3);
      for (b_i = 0; b_i < 3; b_i++) {
        for (i1 = 0; i1 < b_index; i1++) {
          allLayers[i].f1[i1 + allLayers[i].f1.size(0) * b_i] = resamLayers[i1 +
            resamLayers.size(0) * b_i];
        }
      }

      backgs[i] = thisBackground;
      qshifts[i] = thisQshift;
      sfs[i] = thisSf;
      nbas[i] = thisNba;
      nbss[i] = thisNbs;
      resols[i] = thisResol;
    }
  }
}

// End of code generation (standardTF_custlay_paraPoints.cpp)

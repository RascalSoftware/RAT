//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_layers_core.cpp
//
// Code generation for function 'standardTF_layers_core'
//

// Include files
#include "standardTF_layers_core.h"
#include "applyBackgroundCorrection.h"
#include "callReflectivity.h"
#include "chiSquared.h"
#include "groupLayers_Mod.h"
#include "makeSLDProfiles.h"
#include "resampleLayers.h"
#include "rt_nonfinite.h"
#include "shiftdata.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void b_standardTF_layers_core(const ::coder::array<real_T, 2U> &contrastLayers,
    real_T rough, const ::coder::array<char_T, 2U> &geometry, real_T nba, real_T
    nbs, real_T resample, real_T calcSld, real_T sf, real_T qshift, real_T
    dataPresent, const ::coder::array<real_T, 2U> &data, const real_T
    dataLimits[2], const real_T simLimits_data[], const real_T repeatLayers[2],
    real_T background, real_T resol, real_T backsType, real_T params, const
    real_T resamPars[2], ::coder::array<real_T, 2U> &sldProfile, ::coder::array<
    real_T, 2U> &reflect, ::coder::array<real_T, 2U> &Simul, ::coder::array<
    real_T, 2U> &shifted_dat, ::coder::array<real_T, 2U> &theseLayers, ::coder::
    array<real_T, 2U> &resamLayers, real_T *chiSq, real_T *ssubs)
  {
    ::coder::array<real_T, 2U> b_data;
    ::coder::array<real_T, 2U> layerSld;
    int32_T i;
    int32_T i1;
    int32_T loop_ub;

    //    This is the main reflectivity calculation for all Layers models in the
    //    standard target function.
    //
    //    The function first arranges the
    //    roughness' in the correct order according
    //    to geometry. Then, if required it calculates the SLD profile and if
    //    requested resamples this into a number of zero-roughness layers
    //    (roughness resampling). It the applies any scalefactors and qz shifts
    //    the data requires. This is done before calculating the reflectivity to
    //    ensure that the reflectivity is calculated over the same range in qz as
    //    the shifted datapoints. The main reflectivity calculation is then
    //    called, including the resolution function. The calculation outputs two
    //    profiles - 'reflect' which is the same range as the points, and
    //    'Simulation' which can be a different range to allow extrapolation.
    //    The background correction is the applied, and finally chi-squared is
    //    calculated.
    //
    //  Inputs:
    //    contrastLayers  :
    //    rough           :
    //    geometry        :
    //    nba             :
    //    nbs             :
    //    resample        :
    //    calcSld         :
    //    sf              :
    //    qshift          :
    //    dataPresent     :
    //    data            :
    //    dataLimits      :
    //    simLimits       :
    //    repeatLayers    :
    //    background      :
    //    resol           :
    //    backsType       :
    //    params          :
    //    paralellPoints  :
    //
    //  Outputs:
    //
    //
    //
    //  ------------------------------------------------------------------------
    //
    //        (c) Arwel Hughes  -   12/1/21
    //
    //        Last Modified: 12/1/21 by Arwel Hughes.
    //
    //  ------------------------------------------------------------------------
    //  Bulid up the layers matrix for this contrast
    groupLayers_Mod(contrastLayers, rough, geometry, nba, nbs, theseLayers,
                    ssubs);

    //  Make the SLD profiles.
    //  If resampling is needed, then enforce the calcSLD flag, so as to catch
    //  the error af trying to resample a non-existent profile.
    if ((resample == 1.0) && (calcSld == 0.0)) {
      calcSld = 1.0;
    }

    //  If calc SLD flag is set, then calculate the SLD profile
    if (calcSld == 1.0) {
      makeSLDProfiles(nba, nbs, theseLayers, *ssubs, repeatLayers, sldProfile);
    } else {
      sldProfile.set_size(1, 2);
      sldProfile[0] = 0.0;
      sldProfile[sldProfile.size(0)] = 0.0;
    }

    //  If required, then resample the SLD
    if (resample == 1.0) {
      resampleLayers(sldProfile, resamPars, layerSld);
      resamLayers.set_size(layerSld.size(0), 3);
      loop_ub = layerSld.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          resamLayers[i1 + resamLayers.size(0) * i] = layerSld[i1 +
            layerSld.size(0) * i];
        }
      }
    } else {
      layerSld.set_size(theseLayers.size(0), 3);
      resamLayers.set_size(1, 3);
      loop_ub = theseLayers.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          layerSld[i1 + layerSld.size(0) * i] = theseLayers[i1 +
            theseLayers.size(0) * i];
        }

        resamLayers[resamLayers.size(0) * i] = 0.0;
      }
    }

    //  Apply scale factors and q shifts to the data
    b_data.set_size(data.size(0), data.size(1));
    loop_ub = data.size(1) - 1;
    for (i = 0; i <= loop_ub; i++) {
      int32_T b_loop_ub;
      b_loop_ub = data.size(0) - 1;
      for (i1 = 0; i1 <= b_loop_ub; i1++) {
        b_data[i1 + b_data.size(0) * i] = data[i1 + data.size(0) * i];
      }
    }

    shiftdata(sf, qshift, dataPresent, b_data, dataLimits, simLimits_data,
              shifted_dat);

    //  Calculate the reflectivity
    b_callReflectivity(nba, nbs, simLimits_data, repeatLayers, shifted_dat,
                       layerSld, *ssubs, resol, reflect, Simul);

    //  Apply background correction, either to the simulation or the data
    applyBackgroundCorrection(reflect, Simul, shifted_dat, background, backsType);

    //  Calculate chi squared.
    *chiSq = chiSquared(shifted_dat, reflect, params);
  }

  void c_standardTF_layers_core(const ::coder::array<real_T, 2U> &contrastLayers,
    real_T rough, const ::coder::array<char_T, 2U> &geometry, real_T nba, real_T
    nbs, real_T resample, real_T calcSld, real_T sf, real_T qshift, real_T
    dataPresent, const ::coder::array<real_T, 2U> &data, const real_T
    dataLimits[2], const real_T simLimits_data[], const real_T repeatLayers[2],
    real_T background, real_T resol, real_T backsType, real_T params, const
    real_T resamPars[2], ::coder::array<real_T, 2U> &sldProfile, ::coder::array<
    real_T, 2U> &reflect, ::coder::array<real_T, 2U> &Simul, ::coder::array<
    real_T, 2U> &shifted_dat, ::coder::array<real_T, 2U> &theseLayers, ::coder::
    array<real_T, 2U> &resamLayers, real_T *chiSq, real_T *ssubs)
  {
    ::coder::array<real_T, 2U> b_data;
    ::coder::array<real_T, 2U> layerSld;
    int32_T i;
    int32_T i1;
    int32_T loop_ub;

    //    This is the main reflectivity calculation for all Layers models in the
    //    standard target function.
    //
    //    The function first arranges the
    //    roughness' in the correct order according
    //    to geometry. Then, if required it calculates the SLD profile and if
    //    requested resamples this into a number of zero-roughness layers
    //    (roughness resampling). It the applies any scalefactors and qz shifts
    //    the data requires. This is done before calculating the reflectivity to
    //    ensure that the reflectivity is calculated over the same range in qz as
    //    the shifted datapoints. The main reflectivity calculation is then
    //    called, including the resolution function. The calculation outputs two
    //    profiles - 'reflect' which is the same range as the points, and
    //    'Simulation' which can be a different range to allow extrapolation.
    //    The background correction is the applied, and finally chi-squared is
    //    calculated.
    //
    //  Inputs:
    //    contrastLayers  :
    //    rough           :
    //    geometry        :
    //    nba             :
    //    nbs             :
    //    resample        :
    //    calcSld         :
    //    sf              :
    //    qshift          :
    //    dataPresent     :
    //    data            :
    //    dataLimits      :
    //    simLimits       :
    //    repeatLayers    :
    //    background      :
    //    resol           :
    //    backsType       :
    //    params          :
    //    paralellPoints  :
    //
    //  Outputs:
    //
    //
    //
    //  ------------------------------------------------------------------------
    //
    //        (c) Arwel Hughes  -   12/1/21
    //
    //        Last Modified: 12/1/21 by Arwel Hughes.
    //
    //  ------------------------------------------------------------------------
    //  Bulid up the layers matrix for this contrast
    groupLayers_Mod(contrastLayers, rough, geometry, theseLayers, ssubs);

    //  Make the SLD profiles.
    //  If resampling is needed, then enforce the calcSLD flag, so as to catch
    //  the error af trying to resample a non-existent profile.
    if ((resample == 1.0) && (calcSld == 0.0)) {
      calcSld = 1.0;
    }

    //  If calc SLD flag is set, then calculate the SLD profile
    if (calcSld == 1.0) {
      makeSLDProfiles(nba, nbs, theseLayers, *ssubs, repeatLayers, sldProfile);
    } else {
      sldProfile.set_size(1, 2);
      sldProfile[0] = 0.0;
      sldProfile[sldProfile.size(0)] = 0.0;
    }

    //  If required, then resample the SLD
    if (resample == 1.0) {
      resampleLayers(sldProfile, resamPars, layerSld);
      resamLayers.set_size(layerSld.size(0), 3);
      loop_ub = layerSld.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          resamLayers[i1 + resamLayers.size(0) * i] = layerSld[i1 +
            layerSld.size(0) * i];
        }
      }
    } else {
      layerSld.set_size(theseLayers.size(0), 3);
      resamLayers.set_size(1, 3);
      loop_ub = theseLayers.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          layerSld[i1 + layerSld.size(0) * i] = theseLayers[i1 +
            theseLayers.size(0) * i];
        }

        resamLayers[resamLayers.size(0) * i] = 0.0;
      }
    }

    //  Apply scale factors and q shifts to the data
    b_data.set_size(data.size(0), data.size(1));
    loop_ub = data.size(1) - 1;
    for (i = 0; i <= loop_ub; i++) {
      int32_T b_loop_ub;
      b_loop_ub = data.size(0) - 1;
      for (i1 = 0; i1 <= b_loop_ub; i1++) {
        b_data[i1 + b_data.size(0) * i] = data[i1 + data.size(0) * i];
      }
    }

    shiftdata(sf, qshift, dataPresent, b_data, dataLimits, simLimits_data,
              shifted_dat);

    //  Calculate the reflectivity
    callReflectivity(nba, nbs, simLimits_data, repeatLayers, shifted_dat,
                     layerSld, *ssubs, resol, reflect, Simul);

    //  Apply background correction, either to the simulation or the data
    applyBackgroundCorrection(reflect, Simul, shifted_dat, background, backsType);

    //  Calculate chi squared.
    *chiSq = chiSquared(shifted_dat, reflect, params);
  }

  void d_standardTF_layers_core(const ::coder::array<real_T, 2U> &contrastLayers,
    real_T rough, const ::coder::array<char_T, 2U> &geometry, real_T nba, real_T
    nbs, real_T resample, real_T calcSld, real_T sf, real_T qshift, real_T
    dataPresent, const ::coder::array<real_T, 2U> &data, const real_T
    dataLimits[2], const real_T simLimits_data[], const real_T repeatLayers[2],
    real_T background, real_T resol, real_T backsType, real_T params, const
    real_T resamPars[2], ::coder::array<real_T, 2U> &sldProfile, ::coder::array<
    real_T, 2U> &reflect, ::coder::array<real_T, 2U> &Simul, ::coder::array<
    real_T, 2U> &shifted_dat, ::coder::array<real_T, 2U> &theseLayers, ::coder::
    array<real_T, 2U> &resamLayers, real_T *chiSq, real_T *ssubs)
  {
    ::coder::array<real_T, 2U> b_data;
    ::coder::array<real_T, 2U> layerSld;
    int32_T i;
    int32_T i1;
    int32_T loop_ub;

    //    This is the main reflectivity calculation for all Layers models in the
    //    standard target function.
    //
    //    The function first arranges the
    //    roughness' in the correct order according
    //    to geometry. Then, if required it calculates the SLD profile and if
    //    requested resamples this into a number of zero-roughness layers
    //    (roughness resampling). It the applies any scalefactors and qz shifts
    //    the data requires. This is done before calculating the reflectivity to
    //    ensure that the reflectivity is calculated over the same range in qz as
    //    the shifted datapoints. The main reflectivity calculation is then
    //    called, including the resolution function. The calculation outputs two
    //    profiles - 'reflect' which is the same range as the points, and
    //    'Simulation' which can be a different range to allow extrapolation.
    //    The background correction is the applied, and finally chi-squared is
    //    calculated.
    //
    //  Inputs:
    //    contrastLayers  :
    //    rough           :
    //    geometry        :
    //    nba             :
    //    nbs             :
    //    resample        :
    //    calcSld         :
    //    sf              :
    //    qshift          :
    //    dataPresent     :
    //    data            :
    //    dataLimits      :
    //    simLimits       :
    //    repeatLayers    :
    //    background      :
    //    resol           :
    //    backsType       :
    //    params          :
    //    paralellPoints  :
    //
    //  Outputs:
    //
    //
    //
    //  ------------------------------------------------------------------------
    //
    //        (c) Arwel Hughes  -   12/1/21
    //
    //        Last Modified: 12/1/21 by Arwel Hughes.
    //
    //  ------------------------------------------------------------------------
    //  Bulid up the layers matrix for this contrast
    groupLayers_Mod(contrastLayers, rough, geometry, theseLayers, ssubs);

    //  Make the SLD profiles.
    //  If resampling is needed, then enforce the calcSLD flag, so as to catch
    //  the error af trying to resample a non-existent profile.
    if ((resample == 1.0) && (calcSld == 0.0)) {
      calcSld = 1.0;
    }

    //  If calc SLD flag is set, then calculate the SLD profile
    if (calcSld == 1.0) {
      makeSLDProfiles(nba, nbs, theseLayers, *ssubs, repeatLayers, sldProfile);
    } else {
      sldProfile.set_size(1, 2);
      sldProfile[0] = 0.0;
      sldProfile[sldProfile.size(0)] = 0.0;
    }

    //  If required, then resample the SLD
    if (resample == 1.0) {
      resampleLayers(sldProfile, resamPars, layerSld);
      resamLayers.set_size(layerSld.size(0), 3);
      loop_ub = layerSld.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          resamLayers[i1 + resamLayers.size(0) * i] = layerSld[i1 +
            layerSld.size(0) * i];
        }
      }
    } else {
      layerSld.set_size(theseLayers.size(0), 3);
      resamLayers.set_size(1, 3);
      loop_ub = theseLayers.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          layerSld[i1 + layerSld.size(0) * i] = theseLayers[i1 +
            theseLayers.size(0) * i];
        }

        resamLayers[resamLayers.size(0) * i] = 0.0;
      }
    }

    //  Apply scale factors and q shifts to the data
    b_data.set_size(data.size(0), data.size(1));
    loop_ub = data.size(1) - 1;
    for (i = 0; i <= loop_ub; i++) {
      int32_T b_loop_ub;
      b_loop_ub = data.size(0) - 1;
      for (i1 = 0; i1 <= b_loop_ub; i1++) {
        b_data[i1 + b_data.size(0) * i] = data[i1 + data.size(0) * i];
      }
    }

    shiftdata(sf, qshift, dataPresent, b_data, dataLimits, simLimits_data,
              shifted_dat);

    //  Calculate the reflectivity
    b_callReflectivity(nba, nbs, simLimits_data, repeatLayers, shifted_dat,
                       layerSld, *ssubs, resol, reflect, Simul);

    //  Apply background correction, either to the simulation or the data
    applyBackgroundCorrection(reflect, Simul, shifted_dat, background, backsType);

    //  Calculate chi squared.
    *chiSq = chiSquared(shifted_dat, reflect, params);
  }

  void standardTF_layers_core(const ::coder::array<real_T, 2U> &contrastLayers,
    real_T rough, const ::coder::array<char_T, 2U> &geometry, real_T nba, real_T
    nbs, real_T resample, real_T calcSld, real_T sf, real_T qshift, real_T
    dataPresent, const ::coder::array<real_T, 2U> &data, const real_T
    dataLimits[2], const real_T simLimits_data[], const real_T repeatLayers[2],
    real_T background, real_T resol, real_T backsType, real_T params, const
    real_T resamPars[2], ::coder::array<real_T, 2U> &sldProfile, ::coder::array<
    real_T, 2U> &reflect, ::coder::array<real_T, 2U> &Simul, ::coder::array<
    real_T, 2U> &shifted_dat, ::coder::array<real_T, 2U> &theseLayers, ::coder::
    array<real_T, 2U> &resamLayers, real_T *chiSq, real_T *ssubs)
  {
    ::coder::array<real_T, 2U> b_data;
    ::coder::array<real_T, 2U> layerSld;
    int32_T i;
    int32_T i1;
    int32_T loop_ub;

    //    This is the main reflectivity calculation for all Layers models in the
    //    standard target function.
    //
    //    The function first arranges the
    //    roughness' in the correct order according
    //    to geometry. Then, if required it calculates the SLD profile and if
    //    requested resamples this into a number of zero-roughness layers
    //    (roughness resampling). It the applies any scalefactors and qz shifts
    //    the data requires. This is done before calculating the reflectivity to
    //    ensure that the reflectivity is calculated over the same range in qz as
    //    the shifted datapoints. The main reflectivity calculation is then
    //    called, including the resolution function. The calculation outputs two
    //    profiles - 'reflect' which is the same range as the points, and
    //    'Simulation' which can be a different range to allow extrapolation.
    //    The background correction is the applied, and finally chi-squared is
    //    calculated.
    //
    //  Inputs:
    //    contrastLayers  :
    //    rough           :
    //    geometry        :
    //    nba             :
    //    nbs             :
    //    resample        :
    //    calcSld         :
    //    sf              :
    //    qshift          :
    //    dataPresent     :
    //    data            :
    //    dataLimits      :
    //    simLimits       :
    //    repeatLayers    :
    //    background      :
    //    resol           :
    //    backsType       :
    //    params          :
    //    paralellPoints  :
    //
    //  Outputs:
    //
    //
    //
    //  ------------------------------------------------------------------------
    //
    //        (c) Arwel Hughes  -   12/1/21
    //
    //        Last Modified: 12/1/21 by Arwel Hughes.
    //
    //  ------------------------------------------------------------------------
    //  Bulid up the layers matrix for this contrast
    groupLayers_Mod(contrastLayers, rough, geometry, nba, nbs, theseLayers,
                    ssubs);

    //  Make the SLD profiles.
    //  If resampling is needed, then enforce the calcSLD flag, so as to catch
    //  the error af trying to resample a non-existent profile.
    if ((resample == 1.0) && (calcSld == 0.0)) {
      calcSld = 1.0;
    }

    //  If calc SLD flag is set, then calculate the SLD profile
    if (calcSld == 1.0) {
      makeSLDProfiles(nba, nbs, theseLayers, *ssubs, repeatLayers, sldProfile);
    } else {
      sldProfile.set_size(1, 2);
      sldProfile[0] = 0.0;
      sldProfile[sldProfile.size(0)] = 0.0;
    }

    //  If required, then resample the SLD
    if (resample == 1.0) {
      resampleLayers(sldProfile, resamPars, layerSld);
      resamLayers.set_size(layerSld.size(0), 3);
      loop_ub = layerSld.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          resamLayers[i1 + resamLayers.size(0) * i] = layerSld[i1 +
            layerSld.size(0) * i];
        }
      }
    } else {
      layerSld.set_size(theseLayers.size(0), 3);
      resamLayers.set_size(1, 3);
      loop_ub = theseLayers.size(0);
      for (i = 0; i < 3; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          layerSld[i1 + layerSld.size(0) * i] = theseLayers[i1 +
            theseLayers.size(0) * i];
        }

        resamLayers[resamLayers.size(0) * i] = 0.0;
      }
    }

    //  Apply scale factors and q shifts to the data
    b_data.set_size(data.size(0), data.size(1));
    loop_ub = data.size(1) - 1;
    for (i = 0; i <= loop_ub; i++) {
      int32_T b_loop_ub;
      b_loop_ub = data.size(0) - 1;
      for (i1 = 0; i1 <= b_loop_ub; i1++) {
        b_data[i1 + b_data.size(0) * i] = data[i1 + data.size(0) * i];
      }
    }

    shiftdata(sf, qshift, dataPresent, b_data, dataLimits, simLimits_data,
              shifted_dat);

    //  Calculate the reflectivity
    callReflectivity(nba, nbs, simLimits_data, repeatLayers, shifted_dat,
                     layerSld, *ssubs, resol, reflect, Simul);

    //  Apply background correction, either to the simulation or the data
    applyBackgroundCorrection(reflect, Simul, shifted_dat, background, backsType);

    //  Calculate chi squared.
    *chiSq = chiSquared(shifted_dat, reflect, params);
  }
}

// End of code generation (standardTF_layers_core.cpp)

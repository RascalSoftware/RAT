//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_stanLay_reflectivityCalculation.cpp
//
// Code generation for function 'standardTF_stanLay_reflectivityCalculation'
//

// Include files
#include "standardTF_stanLay_reflectivityCalculation.h"
#include "RAT_main_internal_types.h"
#include "RAT_main_types.h"
#include "blockedSummation.h"
#include "rt_nonfinite.h"
#include "standardTF_stanlay_paraContrasts.h"
#include "standardTF_stanlay_paraPoints.h"
#include "standardTF_stanlay_single.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void standardTF_stanLay_reflectivityCalculation(const struct0_T *problemDef,
    const cell_10 *problemDef_cells, const struct2_T *controls, b_struct_T
    *problem, ::coder::array<cell_wrap_14, 1U> &reflectivity, ::coder::array<
    cell_wrap_14, 1U> &Simulation, ::coder::array<cell_wrap_8, 1U> &shifted_data,
    ::coder::array<cell_wrap_15, 1U> &layerSlds, ::coder::array<cell_wrap_8, 1U>
    &sldProfiles, ::coder::array<cell_wrap_8, 1U> &allLayers)
  {
    real_T y;
    int32_T i;
    int32_T loop_ub_tmp;

    //  Standard layers reflectivity calculation for standardTF
    //  This function decides on parallelisation options before calling the
    //  relevant version ofthe main standard layers calculation. Parallelisation
    //  is either over the outer loop ('contrasts'), or the inner loop
    //  ('points'). The easiest way to do this is to have multiple versions of
    //  the same core calculation, rather than trying to make the paralell
    //  for loops conditional (although that would be much neater) There are:
    //  points    - parallelise over points in the reflectivity calculation
    //  contrasts - parallelise over contrasts (outer for loop)
    //  Pre-allocation - It's necessary to
    //  pre-define the types for all the arrays
    //  for compilation, so do this in this block.
    loop_ub_tmp = static_cast<int32_T>(problemDef->numberOfContrasts);
    problem->ssubs.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->ssubs[i] = 0.0;
    }

    problem->backgrounds.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->backgrounds[i] = 0.0;
    }

    problem->qshifts.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->qshifts[i] = 0.0;
    }

    problem->scalefactors.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->scalefactors[i] = 0.0;
    }

    problem->nbairs.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->nbairs[i] = 0.0;
    }

    problem->nbsubs.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->nbsubs[i] = 0.0;
    }

    problem->calculations.all_chis.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->calculations.all_chis[i] = 0.0;
    }

    problem->resolutions.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->resolutions[i] = 0.0;
    }

    problem->allSubRough.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->allSubRough[i] = 0.0;
    }

    reflectivity.set_size(loop_ub_tmp);
    Simulation.set_size(loop_ub_tmp);
    shifted_data.set_size(loop_ub_tmp);
    layerSlds.set_size(loop_ub_tmp);
    sldProfiles.set_size(loop_ub_tmp);
    allLayers.set_size(loop_ub_tmp);
    for (int32_T b_i{0}; b_i < loop_ub_tmp; b_i++) {
      reflectivity[b_i].f1.set_size(2, 2);
      reflectivity[b_i].f1[0] = 1.0;
      reflectivity[b_i].f1[1] = 1.0;
      reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
      reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
      Simulation[b_i].f1.set_size(2, 2);
      Simulation[b_i].f1[0] = 1.0;
      Simulation[b_i].f1[1] = 1.0;
      Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
      Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
      shifted_data[b_i].f1.set_size(2, 3);
      layerSlds[b_i].f1.set_size(2, 3);
      sldProfiles[b_i].f1.set_size(2, 2);
      sldProfiles[b_i].f1[0] = 1.0;
      sldProfiles[b_i].f1[1] = 1.0;
      sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
      sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
      allLayers[b_i].f1.set_size(2, 3);
      for (i = 0; i < 3; i++) {
        shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i] = 1.0;
        shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i + 1] = 1.0;
        layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i] = 1.0;
        layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i + 1] = 1.0;
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i] = 1.0;
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i + 1] = 1.0;
      }
    }

    //  ------- End type definitions -------------
    if (coder::internal::i_strcmp(controls->para)) {
      loop_ub_tmp = 0;
    } else if (coder::internal::j_strcmp(controls->para)) {
      loop_ub_tmp = 1;
    } else if (coder::internal::k_strcmp(controls->para)) {
      loop_ub_tmp = 2;
    } else {
      loop_ub_tmp = -1;
    }

    switch (loop_ub_tmp) {
     case 0:
      standardTF_stanlay_single(problemDef, problemDef_cells, controls,
        problem->ssubs, problem->backgrounds, problem->qshifts,
        problem->scalefactors, problem->nbairs, problem->nbsubs,
        problem->resolutions, problem->calculations.all_chis, reflectivity,
        Simulation, shifted_data, layerSlds, sldProfiles, allLayers,
        problem->allSubRough);
      break;

     case 1:
      standardTF_stanlay_paraPoints(problemDef, problemDef_cells, controls,
        problem->ssubs, problem->backgrounds, problem->qshifts,
        problem->scalefactors, problem->nbairs, problem->nbsubs,
        problem->resolutions, problem->calculations.all_chis, reflectivity,
        Simulation, shifted_data, layerSlds, sldProfiles, allLayers,
        problem->allSubRough);
      break;

     case 2:
      standardTF_stanlay_paraContrasts(problemDef, problemDef_cells, controls,
        problem->ssubs, problem->backgrounds, problem->qshifts,
        problem->scalefactors, problem->nbairs, problem->nbsubs,
        problem->resolutions, problem->calculations.all_chis, reflectivity,
        Simulation, shifted_data, layerSlds, sldProfiles, allLayers,
        problem->allSubRough);
      break;
    }

    //  Package everything into one array for tidy output
    if (problem->calculations.all_chis.size(0) == 0) {
      y = 0.0;
    } else {
      y = coder::nestedIter(problem->calculations.all_chis,
                            problem->calculations.all_chis.size(0));
    }

    problem->calculations.sum_chi = y;
    problem->resample.set_size(1, problemDef->resample.size(1));
    loop_ub_tmp = problemDef->resample.size(1);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->resample[i] = problemDef->resample[i];
    }
  }
}

// End of code generation (standardTF_stanLay_reflectivityCalculation.cpp)

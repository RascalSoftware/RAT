//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_stanlay_paraPoints.h
//
// Code generation for function 'standardTF_stanlay_paraPoints'
//
#ifndef STANDARDTF_STANLAY_PARAPOINTS_H
#define STANDARDTF_STANLAY_PARAPOINTS_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_10;
  struct struct2_T;
  struct cell_wrap_14;
  struct cell_wrap_8;
  struct cell_wrap_15;
}

// Function Declarations
namespace RAT
{
  void standardTF_stanlay_paraPoints(const struct0_T *problemDef, const cell_10 *
    problemDef_cells, const struct2_T *controls, ::coder::array<real_T, 1U>
    &outSsubs, ::coder::array<real_T, 1U> &backgs, ::coder::array<real_T, 1U>
    &qshifts, ::coder::array<real_T, 1U> &sfs, ::coder::array<real_T, 1U> &nbas,
    ::coder::array<real_T, 1U> &nbss, ::coder::array<real_T, 1U> &resols, ::
    coder::array<real_T, 1U> &chis, ::coder::array<cell_wrap_14, 1U>
    &reflectivity, ::coder::array<cell_wrap_14, 1U> &Simulation, ::coder::array<
    cell_wrap_8, 1U> &shifted_data, ::coder::array<cell_wrap_15, 1U> &layerSlds,
    ::coder::array<cell_wrap_8, 1U> &sldProfiles, ::coder::array<cell_wrap_8, 1U>
    &allLayers, ::coder::array<real_T, 1U> &allRoughs);
}

#endif

// End of code generation (standardTF_stanlay_paraPoints.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// unpackparams.cpp
//
// Code generation for function 'unpackparams'
//

// Include files
#include "unpackparams.h"
#include "RAT_main_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void unpackparams(struct0_T *problemDef, const ::coder::array<real_T, 2U>
                    &controls_checks_params_fitYesNo, const ::coder::array<
                    real_T, 2U> &controls_checks_backs_fitYesNo, const ::coder::
                    array<real_T, 2U> &controls_checks_shifts_fitYesNo, const ::
                    coder::array<real_T, 2U> &controls_checks_scales_fitYesNo,
                    const ::coder::array<real_T, 2U>
                    &controls_checks_nbairs_fitYesNo, const ::coder::array<
                    real_T, 2U> &controls_checks_nbsubs_fitYesNo, const ::coder::
                    array<real_T, 2U> &controls_checks_resol_fitYesNo)
  {
    ::coder::array<real_T, 2U> uppars;
    int32_T b_i;
    int32_T i;
    int32_T unnamed_idx_1;
    uint32_T packed_counter;
    uint32_T unpacked_counter;
    uint32_T uppars_counter;

    // Unpack the params out of the fitparsma and otherparams arrays
    // back into problem.params
    // problem = getappdata(0,'problem');
    unpacked_counter = 1U;
    packed_counter = 1U;
    uppars_counter = 1U;
    unnamed_idx_1 = problemDef->params.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    i = controls_checks_params_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_params_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->params.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->params[i] = uppars[i];
    }

    // Also the backgrounds
    unnamed_idx_1 = problemDef->backs.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    uppars_counter = 1U;
    i = controls_checks_backs_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_backs_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->backs.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->backs[i] = uppars[i];
    }

    // Scalefactors
    unnamed_idx_1 = problemDef->sf.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    uppars_counter = 1U;
    i = controls_checks_scales_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_scales_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->sf.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->sf[i] = uppars[i];
    }

    // qshifts
    unnamed_idx_1 = problemDef->shifts.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    uppars_counter = 1U;
    i = controls_checks_shifts_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_shifts_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->shifts.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->shifts[i] = uppars[i];
    }

    // Nbairs
    unnamed_idx_1 = problemDef->nba.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    uppars_counter = 1U;
    i = controls_checks_nbairs_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_nbairs_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->nba.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->nba[i] = uppars[i];
    }

    // Nbsubs
    unnamed_idx_1 = problemDef->nbs.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    uppars_counter = 1U;
    i = controls_checks_nbsubs_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_nbsubs_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->nbs.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->nbs[i] = uppars[i];
    }

    // Finally resolutions
    unnamed_idx_1 = problemDef->res.size(1);
    uppars.set_size(1, unnamed_idx_1);
    for (i = 0; i < unnamed_idx_1; i++) {
      uppars[i] = 0.0;
    }

    uppars_counter = 1U;
    i = controls_checks_resol_fitYesNo.size(1);
    for (b_i = 0; b_i < i; b_i++) {
      if (controls_checks_resol_fitYesNo[b_i] == 1.0) {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->fitpars[
          static_cast<int32_T>(unpacked_counter) - 1];
        unpacked_counter++;
        uppars_counter++;
      } else {
        uppars[static_cast<int32_T>(uppars_counter) - 1] = problemDef->
          otherpars[static_cast<int32_T>(packed_counter) - 1];
        packed_counter++;
        uppars_counter++;
      }
    }

    problemDef->res.set_size(1, uppars.size(1));
    unnamed_idx_1 = uppars.size(1);
    for (i = 0; i < unnamed_idx_1; i++) {
      problemDef->res[i] = uppars[i];
    }

    // setappdata(0,'problem',problem);
  }
}

// End of code generation (unpackparams.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// unpackparams.h
//
// Code generation for function 'unpackparams'
//
#ifndef UNPACKPARAMS_H
#define UNPACKPARAMS_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
}

// Function Declarations
namespace RAT
{
  void unpackparams(struct0_T *problemDef, const ::coder::array<real_T, 2U>
                    &controls_checks_params_fitYesNo, const ::coder::array<
                    real_T, 2U> &controls_checks_backs_fitYesNo, const ::coder::
                    array<real_T, 2U> &controls_checks_shifts_fitYesNo, const ::
                    coder::array<real_T, 2U> &controls_checks_scales_fitYesNo,
                    const ::coder::array<real_T, 2U>
                    &controls_checks_nbairs_fitYesNo, const ::coder::array<
                    real_T, 2U> &controls_checks_nbsubs_fitYesNo, const ::coder::
                    array<real_T, 2U> &controls_checks_resol_fitYesNo);
}

#endif

// End of code generation (unpackparams.h)

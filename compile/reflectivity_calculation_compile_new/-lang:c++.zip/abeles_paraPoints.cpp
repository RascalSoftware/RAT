//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abeles_paraPoints.cpp
//
// Code generation for function 'abeles_paraPoints'
//

// Include files
#include "abeles_paraPoints.h"
#include "exp.h"
#include "reflectivity_calculation_data.h"
#include "reflectivity_calculation_rtwutil.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function out =
// abeles_paraPoints(x,sld,nbair,nbsub,nrepeats,rsub,layers,points)
namespace RAT {
void abeles_paraPoints(const ::coder::array<double, 1U> &x,
                       const ::coder::array<double, 2U> &sld, double nbair,
                       double nbsub, double nrepeats, double rsub,
                       double layers, double points,
                       ::coder::array<double, 1U> &out)
{
  creal_T MI[2][2];
  creal_T b_MI[2][2];
  creal_T N_tmp;
  creal_T b_N_tmp;
  creal_T beta;
  creal_T blast;
  creal_T den;
  creal_T num;
  creal_T pair;
  creal_T pimag;
  creal_T plast;
  creal_T psub;
  creal_T quo;
  creal_T rij;
  double a_tmp;
  double ai;
  double ar;
  double bi;
  double brm;
  double im;
  double plast_re;
  double preal;
  double preal_tmp;
  double re;
  double rho;
  double rough;
  double snair;
  double snlay;
  double snsub;
  double theta;
  double thick;
  int i;
  int i1;
  int i2;
  int loop;
  int nl;
  int reploop;
  int ub_loop;
  //  nbair = nbairs(thisCont);
  //  nbsub = nbsubs(thisCont);
  //  ssub = ssubs(thisCont);
  //  nrepeats = nrepeatss(thisCont);
  //  resol = resols(thisCont);
  // 'abeles_paraPoints:9' out = zeros(points,1);
  out.set_size(static_cast<int>(points));
  // 'abeles_paraPoints:12' c0 = complex(0,0);
  // 'abeles_paraPoints:13' c1 = complex(1,0);
  // 'abeles_paraPoints:14' ci = complex(0,1);
  // 'abeles_paraPoints:15' plast = complex(0);
  // 'abeles_paraPoints:16' blast = complex(0);
  // 'abeles_paraPoints:18' M = [c0 c0; c0 c0];
  // pi = 3.141592653589;
  // 'abeles_paraPoints:20' lam = 1.54;
  // 'abeles_paraPoints:21' rfac = ((4*pi)*(4*pi))/2;
  // 'abeles_paraPoints:22' twopi = 2*pi;
  // 'abeles_paraPoints:23' snair = (1.0 - (nbair*((lam*lam) / twopi)));
  snair = 1.0 - nbair * 0.377451863036739;
  // 'abeles_paraPoints:24' snsub = (1.0 - (nbsub*((lam*lam) / twopi)));
  snsub = 1.0 - nbsub * 0.377451863036739;
  // 'abeles_paraPoints:25' parfor loop = 1:points
  ub_loop = static_cast<int>(points) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
    quo, den, num, MI, rij, beta, pimag, preal, snlay, rough, rho, thick,      \
    blast, plast, pair, psub, theta, loop, a_tmp, preal_tmp, i, i1, reploop,   \
    nl, re, im, ar, ai, N_tmp, bi, plast_re, b_N_tmp, i2, brm, b_MI)

  for (loop = 0; loop <= ub_loop; loop++) {
    // 'abeles_paraPoints:27' N = [c0 c0; c0 c0];
    // 'abeles_paraPoints:28' MI = [c0 c0; c0 c0];
    // 'abeles_paraPoints:30' q = x(loop);
    // 'abeles_paraPoints:31' theta = asin(q*lam / (4*pi));
    theta = std::asin(x[loop] * 1.54 / 12.566370614359172);
    // 'abeles_paraPoints:32' preal = ((snsub)*(snsub)) -
    // ((snair)*(snair))*(cos(theta)^2);
    a_tmp = std::cos(theta);
    preal_tmp = snair * snair * (a_tmp * a_tmp);
    preal = snsub * snsub - preal_tmp;
    // 'abeles_paraPoints:33' psub = sqrt(preal*c1);
    psub.re = preal;
    psub.im = preal * 0.0;
    coder::internal::scalar::b_sqrt(&psub);
    // 'abeles_paraPoints:34' pair = snair*sin(theta)*c1;
    a_tmp = snair * std::sin(theta);
    pair.re = a_tmp;
    pair.im = a_tmp * 0.0;
    // 'abeles_paraPoints:35' plast = pair;
    plast = pair;
    // 'abeles_paraPoints:36' blast = 0.0;
    blast.re = 0.0;
    blast.im = 0.0;
    // 'abeles_paraPoints:37' rlast = sld(1,3);
    // 'abeles_paraPoints:38' MI(1,1) = c1;
    MI[0][0].re = 1.0;
    MI[0][0].im = 0.0;
    // 'abeles_paraPoints:39' MI(2,2) = c1;
    MI[1][1].re = 1.0;
    MI[1][1].im = 0.0;
    // 'abeles_paraPoints:40' MI(1,2) = c0;
    MI[1][0].re = 0.0;
    MI[1][0].im = 0.0;
    // 'abeles_paraPoints:41' MI(2,1) = c0;
    MI[0][1].re = 0.0;
    MI[0][1].im = 0.0;
    // 'abeles_paraPoints:42' for reploop = 1:nrepeats
    i = static_cast<int>(nrepeats);
    if (0 <= i - 1) {
      i1 = static_cast<int>(layers);
    }
    for (reploop = 0; reploop < i; reploop++) {
      // 'abeles_paraPoints:43' for nl = 1:layers
      for (nl = 0; nl < i1; nl++) {
        // 'abeles_paraPoints:44' thick = sld(nl,1);
        thick = sld[nl];
        // 'abeles_paraPoints:45' rho = sld(nl,2);
        rho = sld[nl + sld.size(0)];
        // 'abeles_paraPoints:46' rough = sld(nl,3);
        rough = sld[nl + sld.size(0) * 2];
        // 'abeles_paraPoints:47' snlay = (1 - (rho*((lam*lam) / twopi)));
        snlay = 1.0 - rho * 0.377451863036739;
        // 'abeles_paraPoints:48' preal = (snlay*snlay) - (snair*snair)
        // *cos(theta)^2;
        preal = snlay * snlay - preal_tmp;
        // 'abeles_paraPoints:49' pimag = sqrt(preal*c1);
        pimag.re = preal;
        pimag.im = preal * 0.0;
        coder::internal::scalar::b_sqrt(&pimag);
        // 'abeles_paraPoints:50' beta = (twopi / lam)*thick*pimag;
        beta.re = 4.0799904592075231 * thick * pimag.re;
        beta.im = 4.0799904592075231 * thick * pimag.im;
        // 'abeles_paraPoints:51' rij = complex(plast - pimag) / complex(plast +
        // pimag); 'abeles_paraPoints:52' rij = rij *
        // exp(-rfac*plast*pimag*(rough*rough)/(lam*lam));
        re = -78.956835208714864 * plast.re;
        im = -78.956835208714864 * plast.im;
        a_tmp = rough * rough;
        ar = (re * pimag.re - im * pimag.im) * a_tmp;
        ai = (re * pimag.im + im * pimag.re) * a_tmp;
        if (ai == 0.0) {
          N_tmp.re = ar / 2.3716;
          N_tmp.im = 0.0;
        } else if (ar == 0.0) {
          N_tmp.re = 0.0;
          N_tmp.im = ai / 2.3716;
        } else {
          N_tmp.re = ar / 2.3716;
          N_tmp.im = ai / 2.3716;
        }
        coder::b_exp(&N_tmp);
        ar = plast.re - pimag.re;
        ai = plast.im - pimag.im;
        im = plast.re + pimag.re;
        bi = plast.im + pimag.im;
        if (bi == 0.0) {
          if (ai == 0.0) {
            plast_re = ar / im;
            a_tmp = 0.0;
          } else if (ar == 0.0) {
            plast_re = 0.0;
            a_tmp = ai / im;
          } else {
            plast_re = ar / im;
            a_tmp = ai / im;
          }
        } else if (im == 0.0) {
          if (ar == 0.0) {
            plast_re = ai / bi;
            a_tmp = 0.0;
          } else if (ai == 0.0) {
            plast_re = 0.0;
            a_tmp = -(ar / bi);
          } else {
            plast_re = ai / bi;
            a_tmp = -(ar / bi);
          }
        } else {
          brm = std::abs(im);
          a_tmp = std::abs(bi);
          if (brm > a_tmp) {
            re = bi / im;
            a_tmp = im + re * bi;
            plast_re = (ar + re * ai) / a_tmp;
            a_tmp = (ai - re * ar) / a_tmp;
          } else if (a_tmp == brm) {
            if (im > 0.0) {
              re = 0.5;
            } else {
              re = -0.5;
            }
            if (bi > 0.0) {
              a_tmp = 0.5;
            } else {
              a_tmp = -0.5;
            }
            plast_re = (ar * re + ai * a_tmp) / brm;
            a_tmp = (ai * re - ar * a_tmp) / brm;
          } else {
            re = im / bi;
            a_tmp = bi + re * im;
            plast_re = (re * ar + ai) / a_tmp;
            a_tmp = (re * ai - ar) / a_tmp;
          }
        }
        rij.re = plast_re * N_tmp.re - a_tmp * N_tmp.im;
        rij.im = plast_re * N_tmp.im + a_tmp * N_tmp.re;
        // 'abeles_paraPoints:53' N(1 , 1) = exp(blast*ci);
        b_N_tmp.re = blast.re * 0.0 - blast.im;
        b_N_tmp.im = blast.re + blast.im * 0.0;
        coder::b_exp(&b_N_tmp);
        // 'abeles_paraPoints:54' N(2 , 1) = rij * exp( - blast*ci);
        N_tmp.re = -blast.re * 0.0 - (-blast.im);
        N_tmp.im = -blast.re + -blast.im * 0.0;
        coder::b_exp(&N_tmp);
        a_tmp = rij.re * N_tmp.re - rij.im * N_tmp.im;
        re = rij.re * N_tmp.im + rij.im * N_tmp.re;
        // 'abeles_paraPoints:55' N(2 , 2) = exp( - blast*ci);
        // 'abeles_paraPoints:56' N(1 , 2) = rij * exp(blast*ci);
        im = rij.re * b_N_tmp.re - rij.im * b_N_tmp.im;
        bi = rij.re * b_N_tmp.im + rij.im * b_N_tmp.re;
        // 'abeles_paraPoints:57' plast = pimag;
        plast = pimag;
        // 'abeles_paraPoints:58' blast = beta;
        blast = beta;
        // 'abeles_paraPoints:59' rlast = rough;
        // 'abeles_paraPoints:60' M = MI;
        // 'abeles_paraPoints:61' MI = M * N;
        for (i2 = 0; i2 < 2; i2++) {
          brm = MI[0][i2].re;
          ai = MI[0][i2].im;
          plast_re = MI[1][i2].re;
          ar = MI[1][i2].im;
          b_MI[0][i2].re = (brm * b_N_tmp.re - ai * b_N_tmp.im) +
                           (plast_re * a_tmp - ar * re);
          b_MI[0][i2].im = (brm * b_N_tmp.im + ai * b_N_tmp.re) +
                           (plast_re * re + ar * a_tmp);
          b_MI[1][i2].re =
              (brm * im - ai * bi) + (plast_re * N_tmp.re - ar * N_tmp.im);
          b_MI[1][i2].im =
              (brm * bi + ai * im) + (plast_re * N_tmp.im + ar * N_tmp.re);
        }
        MI[0][0] = b_MI[0][0];
        MI[0][1] = b_MI[0][1];
        MI[1][0] = b_MI[1][0];
        MI[1][1] = b_MI[1][1];
      }
    }
    // 'abeles_paraPoints:64' rij = (complex(plast - psub)) / (complex(plast +
    // psub)); 'abeles_paraPoints:65' rij = rij *
    // exp(-rfac*plast*psub*(rsub*rsub)/(lam*lam));
    re = -78.956835208714864 * plast.re;
    im = -78.956835208714864 * plast.im;
    a_tmp = rsub * rsub;
    ar = (re * psub.re - im * psub.im) * a_tmp;
    ai = (re * psub.im + im * psub.re) * a_tmp;
    if (ai == 0.0) {
      N_tmp.re = ar / 2.3716;
      N_tmp.im = 0.0;
    } else if (ar == 0.0) {
      N_tmp.re = 0.0;
      N_tmp.im = ai / 2.3716;
    } else {
      N_tmp.re = ar / 2.3716;
      N_tmp.im = ai / 2.3716;
    }
    coder::b_exp(&N_tmp);
    ar = plast.re - psub.re;
    ai = plast.im - psub.im;
    im = plast.re + psub.re;
    bi = plast.im + psub.im;
    if (bi == 0.0) {
      if (ai == 0.0) {
        plast_re = ar / im;
        a_tmp = 0.0;
      } else if (ar == 0.0) {
        plast_re = 0.0;
        a_tmp = ai / im;
      } else {
        plast_re = ar / im;
        a_tmp = ai / im;
      }
    } else if (im == 0.0) {
      if (ar == 0.0) {
        plast_re = ai / bi;
        a_tmp = 0.0;
      } else if (ai == 0.0) {
        plast_re = 0.0;
        a_tmp = -(ar / bi);
      } else {
        plast_re = ai / bi;
        a_tmp = -(ar / bi);
      }
    } else {
      brm = std::abs(im);
      a_tmp = std::abs(bi);
      if (brm > a_tmp) {
        re = bi / im;
        a_tmp = im + re * bi;
        plast_re = (ar + re * ai) / a_tmp;
        a_tmp = (ai - re * ar) / a_tmp;
      } else if (a_tmp == brm) {
        if (im > 0.0) {
          re = 0.5;
        } else {
          re = -0.5;
        }
        if (bi > 0.0) {
          a_tmp = 0.5;
        } else {
          a_tmp = -0.5;
        }
        plast_re = (ar * re + ai * a_tmp) / brm;
        a_tmp = (ai * re - ar * a_tmp) / brm;
      } else {
        re = im / bi;
        a_tmp = bi + re * im;
        plast_re = (re * ar + ai) / a_tmp;
        a_tmp = (re * ai - ar) / a_tmp;
      }
    }
    rij.re = plast_re * N_tmp.re - a_tmp * N_tmp.im;
    rij.im = plast_re * N_tmp.im + a_tmp * N_tmp.re;
    // 'abeles_paraPoints:66' N(1,1) = exp(blast*ci);
    b_N_tmp.re = blast.re * 0.0 - blast.im;
    b_N_tmp.im = blast.re + blast.im * 0.0;
    coder::b_exp(&b_N_tmp);
    // 'abeles_paraPoints:67' N(2,1) = rij*exp( - blast*ci);
    N_tmp.re = -blast.re * 0.0 - (-blast.im);
    N_tmp.im = -blast.re + -blast.im * 0.0;
    coder::b_exp(&N_tmp);
    a_tmp = rij.re * N_tmp.re - rij.im * N_tmp.im;
    re = rij.re * N_tmp.im + rij.im * N_tmp.re;
    // 'abeles_paraPoints:68' N(2,2) = exp( - blast*ci);
    // 'abeles_paraPoints:69' N(1,2) = rij*exp(blast*ci);
    im = rij.re * b_N_tmp.re - rij.im * b_N_tmp.im;
    bi = rij.re * b_N_tmp.im + rij.im * b_N_tmp.re;
    // 'abeles_paraPoints:70' M = MI;
    // 'abeles_paraPoints:71' MI = M * N;
    for (i = 0; i < 2; i++) {
      brm = MI[0][i].re;
      ai = MI[0][i].im;
      plast_re = MI[1][i].re;
      ar = MI[1][i].im;
      b_MI[0][i].re =
          (brm * b_N_tmp.re - ai * b_N_tmp.im) + (plast_re * a_tmp - ar * re);
      b_MI[0][i].im =
          (brm * b_N_tmp.im + ai * b_N_tmp.re) + (plast_re * re + ar * a_tmp);
      b_MI[1][i].re =
          (brm * im - ai * bi) + (plast_re * N_tmp.re - ar * N_tmp.im);
      b_MI[1][i].im =
          (brm * bi + ai * im) + (plast_re * N_tmp.im + ar * N_tmp.re);
    }
    // 'abeles_paraPoints:72' num = MI(2 , 1)*conj(MI(2 , 1));
    num.re = b_MI[0][1].re * b_MI[0][1].re - b_MI[0][1].im * -b_MI[0][1].im;
    num.im = b_MI[0][1].re * -b_MI[0][1].im + b_MI[0][1].im * b_MI[0][1].re;
    // 'abeles_paraPoints:73' den = MI(1 , 1)*conj(MI(1 , 1));
    den.re = b_MI[0][0].re * b_MI[0][0].re - b_MI[0][0].im * -b_MI[0][0].im;
    den.im = b_MI[0][0].re * -b_MI[0][0].im + b_MI[0][0].im * b_MI[0][0].re;
    // 'abeles_paraPoints:74' quo = num/den;
    if (den.im == 0.0) {
      if (num.im == 0.0) {
        quo.re = num.re / den.re;
        quo.im = 0.0;
      } else if (num.re == 0.0) {
        quo.re = 0.0;
        quo.im = num.im / den.re;
      } else {
        quo.re = num.re / den.re;
        quo.im = num.im / den.re;
      }
    } else if (den.re == 0.0) {
      if (num.re == 0.0) {
        quo.re = num.im / den.im;
        quo.im = 0.0;
      } else if (num.im == 0.0) {
        quo.re = 0.0;
        quo.im = -(num.re / den.im);
      } else {
        quo.re = num.im / den.im;
        quo.im = -(num.re / den.im);
      }
    } else {
      brm = std::abs(den.re);
      a_tmp = std::abs(den.im);
      if (brm > a_tmp) {
        re = den.im / den.re;
        a_tmp = den.re + re * den.im;
        quo.re = (num.re + re * num.im) / a_tmp;
        quo.im = (num.im - re * num.re) / a_tmp;
      } else if (a_tmp == brm) {
        if (den.re > 0.0) {
          re = 0.5;
        } else {
          re = -0.5;
        }
        if (den.im > 0.0) {
          a_tmp = 0.5;
        } else {
          a_tmp = -0.5;
        }
        quo.re = (num.re * re + num.im * a_tmp) / brm;
        quo.im = (num.im * re - num.re * a_tmp) / brm;
      } else {
        re = den.re / den.im;
        a_tmp = den.im + re * den.re;
        quo.re = (re * num.re + num.im) / a_tmp;
        quo.im = (re * num.im - num.re) / a_tmp;
      }
    }
    // 'abeles_paraPoints:75' out(loop) = abs(quo);
    out[loop] = rt_hypotd_snf(quo.re, quo.im);
  }
}

} // namespace RAT

// End of code generation (abeles_paraPoints.cpp)

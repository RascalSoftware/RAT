//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abeles_single.cpp
//
// Code generation for function 'abeles_single'
//

// Include files
#include "abeles_single.h"
#include "exp.h"
#include "reflectivity_calculation_data.h"
#include "reflectivity_calculation_rtwutil.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function out = abeles_single(x,sld,nbair,nbsub,nrepeats,rsub,layers,points)
namespace RAT {
void abeles_single(const ::coder::array<double, 1U> &x,
                   const ::coder::array<double, 2U> &sld, double nbair,
                   double nbsub, double nrepeats, double rsub, double layers,
                   double points, ::coder::array<double, 1U> &out)
{
  creal_T MI[2][2];
  creal_T b_MI[2][2];
  creal_T N_tmp;
  creal_T b_N_tmp;
  creal_T pimag;
  creal_T psub;
  double ar_tmp;
  double snair;
  double snsub;
  int i;
  int i1;
  int i2;
  //  nbair = nbairs(thisCont);
  //  nbsub = nbsubs(thisCont);
  //  ssub = ssubs(thisCont);
  //  nrepeats = nrepeatss(thisCont);
  //  resol = resols(thisCont);
  // 'abeles_single:9' out = zeros(points,1);
  i = static_cast<int>(points);
  out.set_size(i);
  // 'abeles_single:12' c0 = complex(0,0);
  // 'abeles_single:13' c1 = complex(1,0);
  // 'abeles_single:14' ci = complex(0,1);
  // 'abeles_single:15' plast = complex(0);
  // 'abeles_single:16' blast = complex(0);
  // 'abeles_single:17' N = [c0 c0; c0 c0];
  // 'abeles_single:18' MI = [c0 c0; c0 c0];
  // 'abeles_single:19' M = [c0 c0; c0 c0];
  // pi = 3.141592653589;
  // 'abeles_single:21' lam = 1.54;
  // 'abeles_single:22' rfac = ((4*pi)*(4*pi))/2;
  // 'abeles_single:23' twopi = 2*pi;
  // 'abeles_single:24' snair = (1.0 - (nbair*((lam*lam) / twopi)));
  snair = 1.0 - nbair * 0.377451863036739;
  // 'abeles_single:25' snsub = (1.0 - (nbsub*((lam*lam) / twopi)));
  snsub = 1.0 - nbsub * 0.377451863036739;
  // 'abeles_single:26' for loop = 1:points
  if (0 <= i - 1) {
    i1 = static_cast<int>(nrepeats);
    if (0 <= i1 - 1) {
      i2 = static_cast<int>(layers);
    }
    ar_tmp = rsub * rsub;
  }
  for (int loop{0}; loop < i; loop++) {
    double MI_im;
    double MI_re;
    double bim;
    double blast_im;
    double blast_re;
    double brm;
    double d;
    double d1;
    double im;
    double plast_im;
    double plast_re;
    double psub_tmp_tmp;
    double re;
    double rij_im;
    double rij_re;
    double theta;
    int i3;
    // 'abeles_single:27' q = x(loop);
    // 'abeles_single:28' theta = asin(q*lam / (4*pi));
    theta = std::asin(x[loop] * 1.54 / 12.566370614359172);
    // 'abeles_single:29' preal = ((snsub)*(snsub)) -
    // ((snair)*(snair))*(cos(theta)^2);
    MI_re = std::cos(theta);
    // 'abeles_single:30' psub = sqrt(preal*c1);
    psub_tmp_tmp = snair * snair * (MI_re * MI_re);
    MI_re = snsub * snsub - psub_tmp_tmp;
    psub.re = MI_re;
    psub.im = MI_re * 0.0;
    coder::internal::scalar::b_sqrt(&psub);
    // 'abeles_single:31' pair = snair*sin(theta)*c1;
    MI_re = snair * std::sin(theta);
    plast_re = MI_re;
    plast_im = MI_re * 0.0;
    // 'abeles_single:32' plast = pair;
    // 'abeles_single:33' blast = 0.0;
    blast_re = 0.0;
    blast_im = 0.0;
    // 'abeles_single:34' rlast = sld(1,3);
    // 'abeles_single:35' MI(1,1) = c1;
    MI[0][0].re = 1.0;
    MI[0][0].im = 0.0;
    // 'abeles_single:36' MI(2,2) = c1;
    MI[1][1].re = 1.0;
    MI[1][1].im = 0.0;
    // 'abeles_single:37' MI(1,2) = c0;
    MI[1][0].re = 0.0;
    MI[1][0].im = 0.0;
    // 'abeles_single:38' MI(2,1) = c0;
    MI[0][1].re = 0.0;
    MI[0][1].im = 0.0;
    // 'abeles_single:39' for reploop = 1:nrepeats
    for (int reploop{0}; reploop < i1; reploop++) {
      // 'abeles_single:40' for nl = 1:layers
      for (int nl{0}; nl < i2; nl++) {
        double rough;
        double snlay;
        // 'abeles_single:41' thick = sld(nl,1);
        // 'abeles_single:42' rho = sld(nl,2);
        // 'abeles_single:43' rough = sld(nl,3);
        rough = sld[nl + sld.size(0) * 2];
        // 'abeles_single:44' snlay = (1 - (rho*((lam*lam) / twopi)));
        snlay = 1.0 - sld[nl + sld.size(0)] * 0.377451863036739;
        // 'abeles_single:45' preal = (snlay*snlay) - (snair*snair)
        // *cos(theta)^2; 'abeles_single:46' pimag = sqrt(preal*c1);
        MI_re = snlay * snlay - psub_tmp_tmp;
        pimag.re = MI_re;
        pimag.im = MI_re * 0.0;
        coder::internal::scalar::b_sqrt(&pimag);
        // 'abeles_single:47' beta = (twopi / lam)*thick*pimag;
        // 'abeles_single:48' rij = complex(plast - pimag) / complex(plast +
        // pimag); 'abeles_single:49' rij = rij *
        // exp(-rfac*plast*pimag*(rough*rough)/(lam*lam));
        re = -78.956835208714864 * plast_re;
        im = -78.956835208714864 * plast_im;
        MI_re = rough * rough;
        MI_im = (re * pimag.re - im * pimag.im) * MI_re;
        im = (re * pimag.im + im * pimag.re) * MI_re;
        if (im == 0.0) {
          N_tmp.re = MI_im / 2.3716;
          N_tmp.im = 0.0;
        } else if (MI_im == 0.0) {
          N_tmp.re = 0.0;
          N_tmp.im = im / 2.3716;
        } else {
          N_tmp.re = MI_im / 2.3716;
          N_tmp.im = im / 2.3716;
        }
        coder::b_exp(&N_tmp);
        MI_im = plast_re - pimag.re;
        im = plast_im - pimag.im;
        MI_re = plast_re + pimag.re;
        re = plast_im + pimag.im;
        if (re == 0.0) {
          if (im == 0.0) {
            plast_re = MI_im / MI_re;
            plast_im = 0.0;
          } else if (MI_im == 0.0) {
            plast_re = 0.0;
            plast_im = im / MI_re;
          } else {
            plast_re = MI_im / MI_re;
            plast_im = im / MI_re;
          }
        } else if (MI_re == 0.0) {
          if (MI_im == 0.0) {
            plast_re = im / re;
            plast_im = 0.0;
          } else if (im == 0.0) {
            plast_re = 0.0;
            plast_im = -(MI_im / re);
          } else {
            plast_re = im / re;
            plast_im = -(MI_im / re);
          }
        } else {
          brm = std::abs(MI_re);
          bim = std::abs(re);
          if (brm > bim) {
            bim = re / MI_re;
            MI_re += bim * re;
            plast_re = (MI_im + bim * im) / MI_re;
            plast_im = (im - bim * MI_im) / MI_re;
          } else if (bim == brm) {
            if (MI_re > 0.0) {
              bim = 0.5;
            } else {
              bim = -0.5;
            }
            if (re > 0.0) {
              MI_re = 0.5;
            } else {
              MI_re = -0.5;
            }
            plast_re = (MI_im * bim + im * MI_re) / brm;
            plast_im = (im * bim - MI_im * MI_re) / brm;
          } else {
            bim = MI_re / re;
            MI_re = re + bim * MI_re;
            plast_re = (bim * MI_im + im) / MI_re;
            plast_im = (bim * im - MI_im) / MI_re;
          }
        }
        rij_re = plast_re * N_tmp.re - plast_im * N_tmp.im;
        rij_im = plast_re * N_tmp.im + plast_im * N_tmp.re;
        // 'abeles_single:50' N(1 , 1) = exp(blast*ci);
        b_N_tmp.re = blast_re * 0.0 - blast_im;
        b_N_tmp.im = blast_re + blast_im * 0.0;
        coder::b_exp(&b_N_tmp);
        // 'abeles_single:51' N(2 , 1) = rij * exp( - blast*ci);
        N_tmp.re = -blast_re * 0.0 - (-blast_im);
        N_tmp.im = -blast_re + -blast_im * 0.0;
        coder::b_exp(&N_tmp);
        brm = rij_re * N_tmp.re - rij_im * N_tmp.im;
        d = rij_re * N_tmp.im + rij_im * N_tmp.re;
        // 'abeles_single:52' N(2 , 2) = exp( - blast*ci);
        // 'abeles_single:53' N(1 , 2) = rij * exp(blast*ci);
        d1 = rij_re * b_N_tmp.re - rij_im * b_N_tmp.im;
        MI_re = rij_re * b_N_tmp.im + rij_im * b_N_tmp.re;
        // 'abeles_single:54' plast = pimag;
        plast_re = pimag.re;
        plast_im = pimag.im;
        // 'abeles_single:55' blast = beta;
        blast_re = 4.0799904592075231 * sld[nl] * pimag.re;
        blast_im = 4.0799904592075231 * sld[nl] * pimag.im;
        // 'abeles_single:56' rlast = rough;
        // 'abeles_single:57' M = MI;
        // 'abeles_single:58' MI = M * N;
        for (i3 = 0; i3 < 2; i3++) {
          re = MI[0][i3].re;
          im = MI[0][i3].im;
          MI_im = MI[1][i3].re;
          bim = MI[1][i3].im;
          b_MI[0][i3].re =
              (re * b_N_tmp.re - im * b_N_tmp.im) + (MI_im * brm - bim * d);
          b_MI[0][i3].im =
              (re * b_N_tmp.im + im * b_N_tmp.re) + (MI_im * d + bim * brm);
          b_MI[1][i3].re =
              (re * d1 - im * MI_re) + (MI_im * N_tmp.re - bim * N_tmp.im);
          b_MI[1][i3].im =
              (re * MI_re + im * d1) + (MI_im * N_tmp.im + bim * N_tmp.re);
        }
        MI[0][0] = b_MI[0][0];
        MI[0][1] = b_MI[0][1];
        MI[1][0] = b_MI[1][0];
        MI[1][1] = b_MI[1][1];
      }
    }
    // 'abeles_single:61' rij = (complex(plast - psub)) / (complex(plast +
    // psub)); 'abeles_single:62' rij = rij *
    // exp(-rfac*plast*psub*(rsub*rsub)/(lam*lam));
    re = -78.956835208714864 * plast_re;
    im = -78.956835208714864 * plast_im;
    MI_im = (re * psub.re - im * psub.im) * ar_tmp;
    im = (re * psub.im + im * psub.re) * ar_tmp;
    if (im == 0.0) {
      N_tmp.re = MI_im / 2.3716;
      N_tmp.im = 0.0;
    } else if (MI_im == 0.0) {
      N_tmp.re = 0.0;
      N_tmp.im = im / 2.3716;
    } else {
      N_tmp.re = MI_im / 2.3716;
      N_tmp.im = im / 2.3716;
    }
    coder::b_exp(&N_tmp);
    MI_im = plast_re - psub.re;
    im = plast_im - psub.im;
    MI_re = plast_re + psub.re;
    re = plast_im + psub.im;
    if (re == 0.0) {
      if (im == 0.0) {
        plast_re = MI_im / MI_re;
        plast_im = 0.0;
      } else if (MI_im == 0.0) {
        plast_re = 0.0;
        plast_im = im / MI_re;
      } else {
        plast_re = MI_im / MI_re;
        plast_im = im / MI_re;
      }
    } else if (MI_re == 0.0) {
      if (MI_im == 0.0) {
        plast_re = im / re;
        plast_im = 0.0;
      } else if (im == 0.0) {
        plast_re = 0.0;
        plast_im = -(MI_im / re);
      } else {
        plast_re = im / re;
        plast_im = -(MI_im / re);
      }
    } else {
      brm = std::abs(MI_re);
      bim = std::abs(re);
      if (brm > bim) {
        bim = re / MI_re;
        MI_re += bim * re;
        plast_re = (MI_im + bim * im) / MI_re;
        plast_im = (im - bim * MI_im) / MI_re;
      } else if (bim == brm) {
        if (MI_re > 0.0) {
          bim = 0.5;
        } else {
          bim = -0.5;
        }
        if (re > 0.0) {
          MI_re = 0.5;
        } else {
          MI_re = -0.5;
        }
        plast_re = (MI_im * bim + im * MI_re) / brm;
        plast_im = (im * bim - MI_im * MI_re) / brm;
      } else {
        bim = MI_re / re;
        MI_re = re + bim * MI_re;
        plast_re = (bim * MI_im + im) / MI_re;
        plast_im = (bim * im - MI_im) / MI_re;
      }
    }
    rij_re = plast_re * N_tmp.re - plast_im * N_tmp.im;
    rij_im = plast_re * N_tmp.im + plast_im * N_tmp.re;
    // 'abeles_single:63' N(1,1) = exp(blast*ci);
    b_N_tmp.re = blast_re * 0.0 - blast_im;
    b_N_tmp.im = blast_re + blast_im * 0.0;
    coder::b_exp(&b_N_tmp);
    // 'abeles_single:64' N(2,1) = rij*exp( - blast*ci);
    N_tmp.re = -blast_re * 0.0 - (-blast_im);
    N_tmp.im = -blast_re + -blast_im * 0.0;
    coder::b_exp(&N_tmp);
    brm = rij_re * N_tmp.re - rij_im * N_tmp.im;
    d = rij_re * N_tmp.im + rij_im * N_tmp.re;
    // 'abeles_single:65' N(2,2) = exp( - blast*ci);
    // 'abeles_single:66' N(1,2) = rij*exp(blast*ci);
    d1 = rij_re * b_N_tmp.re - rij_im * b_N_tmp.im;
    MI_re = rij_re * b_N_tmp.im + rij_im * b_N_tmp.re;
    // 'abeles_single:67' M = MI;
    // 'abeles_single:68' MI = M * N;
    for (i3 = 0; i3 < 2; i3++) {
      re = MI[0][i3].re;
      im = MI[0][i3].im;
      MI_im = MI[1][i3].re;
      bim = MI[1][i3].im;
      b_MI[0][i3].re =
          (re * b_N_tmp.re - im * b_N_tmp.im) + (MI_im * brm - bim * d);
      b_MI[0][i3].im =
          (re * b_N_tmp.im + im * b_N_tmp.re) + (MI_im * d + bim * brm);
      b_MI[1][i3].re =
          (re * d1 - im * MI_re) + (MI_im * N_tmp.re - bim * N_tmp.im);
      b_MI[1][i3].im =
          (re * MI_re + im * d1) + (MI_im * N_tmp.im + bim * N_tmp.re);
    }
    // 'abeles_single:69' num = MI(2 , 1)*conj(MI(2 , 1));
    // 'abeles_single:70' den = MI(1 , 1)*conj(MI(1 , 1));
    // 'abeles_single:71' quo = num/den;
    im = b_MI[0][1].re * b_MI[0][1].re - b_MI[0][1].im * -b_MI[0][1].im;
    MI_im = b_MI[0][1].re * -b_MI[0][1].im + b_MI[0][1].im * b_MI[0][1].re;
    MI_re = b_MI[0][0].re * b_MI[0][0].re - b_MI[0][0].im * -b_MI[0][0].im;
    re = b_MI[0][0].re * -b_MI[0][0].im + b_MI[0][0].im * b_MI[0][0].re;
    if (re == 0.0) {
      if (MI_im == 0.0) {
        N_tmp.re = im / MI_re;
        N_tmp.im = 0.0;
      } else if (im == 0.0) {
        N_tmp.re = 0.0;
        N_tmp.im = MI_im / MI_re;
      } else {
        N_tmp.re = im / MI_re;
        N_tmp.im = MI_im / MI_re;
      }
    } else if (MI_re == 0.0) {
      if (im == 0.0) {
        N_tmp.re = MI_im / re;
        N_tmp.im = 0.0;
      } else if (MI_im == 0.0) {
        N_tmp.re = 0.0;
        N_tmp.im = -(im / re);
      } else {
        N_tmp.re = MI_im / re;
        N_tmp.im = -(im / re);
      }
    } else {
      brm = std::abs(MI_re);
      bim = std::abs(re);
      if (brm > bim) {
        bim = re / MI_re;
        MI_re += bim * re;
        N_tmp.re = (im + bim * MI_im) / MI_re;
        N_tmp.im = (MI_im - bim * im) / MI_re;
      } else if (bim == brm) {
        if (MI_re > 0.0) {
          bim = 0.5;
        } else {
          bim = -0.5;
        }
        if (re > 0.0) {
          MI_re = 0.5;
        } else {
          MI_re = -0.5;
        }
        N_tmp.re = (im * bim + MI_im * MI_re) / brm;
        N_tmp.im = (MI_im * bim - im * MI_re) / brm;
      } else {
        bim = MI_re / re;
        MI_re = re + bim * MI_re;
        N_tmp.re = (bim * im + MI_im) / MI_re;
        N_tmp.im = (bim * MI_im - im) / MI_re;
      }
    }
    // 'abeles_single:72' out(loop) = abs(quo);
    out[loop] = rt_hypotd_snf(N_tmp.re, N_tmp.im);
  }
}

} // namespace RAT

// End of code generation (abeles_single.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// acos.cpp
//
// Code generation for function 'acos'
//

// Include files
#include "acos.h"
#include "asinh.h"
#include "complexTimes.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "rt_defines.h"
#include <cmath>

// Function Declarations
namespace RAT
{
  static real_T rt_atan2d_snf(real_T u0, real_T u1);
}

// Function Definitions
namespace RAT
{
  static real_T rt_atan2d_snf(real_T u0, real_T u1)
  {
    real_T y;
    if (std::isnan(u0) || std::isnan(u1)) {
      y = rtNaN;
    } else if (std::isinf(u0) && std::isinf(u1)) {
      int32_T b_u0;
      int32_T b_u1;
      if (u0 > 0.0) {
        b_u0 = 1;
      } else {
        b_u0 = -1;
      }

      if (u1 > 0.0) {
        b_u1 = 1;
      } else {
        b_u1 = -1;
      }

      y = std::atan2(static_cast<real_T>(b_u0), static_cast<real_T>(b_u1));
    } else if (u1 == 0.0) {
      if (u0 > 0.0) {
        y = RT_PI / 2.0;
      } else if (u0 < 0.0) {
        y = -(RT_PI / 2.0);
      } else {
        y = 0.0;
      }
    } else {
      y = std::atan2(u0, u1);
    }

    return y;
  }

  namespace coder
  {
    namespace internal
    {
      namespace scalar
      {
        void b_acos(creal_T *x)
        {
          creal_T u;
          creal_T v;
          real_T d;
          if ((x->im == 0.0) && (!(std::abs(x->re) > 1.0))) {
            x->re = std::acos(x->re);
            x->im = 0.0;
          } else {
            v.re = x->re + 1.0;
            v.im = x->im;
            b_sqrt(&v);
            u.re = 1.0 - x->re;
            u.im = 0.0 - x->im;
            b_sqrt(&u);
            d = complexTimes(v.re, -v.im, u.re, u.im);
            b_asinh(&d);
            x->re = 2.0 * rt_atan2d_snf(u.re, v.re);
            x->im = d;
          }
        }
      }
    }
  }
}

// End of code generation (acos.cpp)

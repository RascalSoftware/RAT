//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// adaptive_new.h
//
// Code generation for function 'adaptive_new'
//

#ifndef ADAPTIVE_NEW_H
#define ADAPTIVE_NEW_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT {
struct cell_21;

}

// Function Declarations
namespace RAT {
void adaptive_new(const ::coder::array<double, 2U> &sldProfile,
                  const double startDomain[2], double minAngle, double nPoints,
                  cell_21 *out);

void adaptive_new(const double sldProfile_data[], const int sldProfile_size[2],
                  const double startDomain[2], double minAngle, double nPoints,
                  cell_21 *out);

} // namespace RAT

#endif
// End of code generation (adaptive_new.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// adaptive_new.h
//
// Code generation for function 'adaptive_new'
//
#ifndef ADAPTIVE_NEW_H
#define ADAPTIVE_NEW_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct cell_23;
}

// Function Declarations
namespace RAT
{
  void adaptive_new(const ::coder::array<real_T, 2U> &sldProfile, const real_T
                    startDomain[2], real_T minAngle, real_T nPoints, cell_23
                    *out);
  void adaptive_new(const real_T sldProfile_data[], const int32_T
                    sldProfile_size[2], const real_T startDomain[2], real_T
                    minAngle, real_T nPoints, cell_23 *out);
}

#endif

// End of code generation (adaptive_new.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// allocateLayersForContrast.cpp
//
// Code generation for function 'allocateLayersForContrast'
//

// Include files
#include "allocateLayersForContrast.h"
#include "length.h"
#include "nullAssignment.h"
#include "reflectivity_calculation_internal_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function     thisContrastLayers =
// allocateLayersForContrast(contrastLayers,outParameterisedLayers)
namespace RAT {
void allocateLayersForContrast(
    const ::coder::array<double, 2U> &contrastLayers,
    const ::coder::array<cell_wrap_17, 2U> &outParameterisedLayers,
    ::coder::array<double, 2U> &thisContrastLayers)
{
  int i;
  int i1;
  int n;
  //  Decide which layers are needed for a particular contrast.
  //  This function takes the master array of all layers
  //  and extracts which parameters are required for
  //  a particular contrast.
  //
  //  INPUTS:
  //      outParameterisedLayers - List of all the available layers
  //      thisContrastLayers     - Array detailing which layers are required for
  //      this contrast
  // 'allocateLayersForContrast:12' thisContrastLayers =
  // zeros(length(contrastLayers),5);
  n = coder::internal::intlength(contrastLayers.size(0),
                                 contrastLayers.size(1));
  thisContrastLayers.set_size(n, 5);
  for (i = 0; i < 5; i++) {
    for (i1 = 0; i1 < n; i1++) {
      thisContrastLayers[i1 + thisContrastLayers.size(0) * i] = 0.0;
    }
  }
  // 'allocateLayersForContrast:14' for i = 1:length(contrastLayers)
  i = coder::internal::intlength(contrastLayers.size(0),
                                 contrastLayers.size(1));
  for (int b_i{0}; b_i < i; b_i++) {
    // 'allocateLayersForContrast:15' if (contrastLayers(i) ~= 0)
    if (contrastLayers[b_i] != 0.0) {
      // 'allocateLayersForContrast:16' thisLayer =
      // outParameterisedLayers{contrastLayers(i)};
      for (i1 = 0; i1 < 5; i1++) {
        thisContrastLayers[b_i + thisContrastLayers.size(0) * i1] =
            outParameterisedLayers[static_cast<int>(contrastLayers[b_i]) - 1]
                .f1[i1];
      }
      // 'allocateLayersForContrast:17' thisContrastLayers(i,:) = thisLayer;
    } else {
      // 'allocateLayersForContrast:18' else
      // 'allocateLayersForContrast:19' thisContrastLayers(1,:) = [];
      coder::internal::nullAssignment(thisContrastLayers);
    }
  }
}

} // namespace RAT

// End of code generation (allocateLayersForContrast.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// allocateParamsToLayers.cpp
//
// Code generation for function 'allocateParamsToLayers'
//

// Include files
#include "allocateParamsToLayers.h"
#include "length.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function outLayers = allocateParamsToLayers(params, layersDetails)
namespace RAT {
void allocateParamsToLayers(
    const ::coder::array<double, 2U> &params,
    const ::coder::array<cell_wrap_14, 1U> &layersDetails,
    ::coder::array<cell_wrap_17, 2U> &outLayers)
{
  double thisOutLayer[5];
  int i;
  //  Allocates parameters from the parameter array to the correct layers
  //
  //  This function takes the list of all layers in 'layersDetails',
  //  then loops over all the layers, putting in the correct
  //  parameter value from the parameters array into each layer in
  //  the 'outLayers' cell array
  // 'allocateParamsToLayers:9' numberOfLayers = length(layersDetails);
  // 'allocateParamsToLayers:10' thisOutLayer = zeros(1,5);
  for (i = 0; i < 5; i++) {
    thisOutLayer[i] = 0.0;
  }
  // 'allocateParamsToLayers:11' outLayers = cell(1,numberOfLayers);
  outLayers.set_size(1, layersDetails.size(0));
  // 'allocateParamsToLayers:13' for i = 1:numberOfLayers
  i = layersDetails.size(0);
  for (int b_i{0}; b_i < i; b_i++) {
    int i1;
    // 'allocateParamsToLayers:14' thisLayer = layersDetails{i};
    // 'allocateParamsToLayers:15' for n = 1:(length(thisLayer)-1)
    i1 = coder::internal::intlength(layersDetails[b_i].f1.size(0),
                                    layersDetails[b_i].f1.size(1));
    for (int n{0}; n <= i1 - 2; n++) {
      // 'allocateParamsToLayers:16' thisVal = thisLayer(n);
      // 'allocateParamsToLayers:17' if ~isnan(thisVal)
      if (!std::isnan(layersDetails[b_i].f1[n])) {
        // 'allocateParamsToLayers:18' thisOutLayer(n) = params(thisVal);
        thisOutLayer[n] =
            params[static_cast<int>(layersDetails[b_i].f1[n]) - 1];
      } else {
        // 'allocateParamsToLayers:19' else
        // 'allocateParamsToLayers:20' thisOutLayer(n) = NaN;
        thisOutLayer[n] = rtNaN;
      }
    }
    // 'allocateParamsToLayers:23' thisOutLayer(length(thisLayer)) =
    // thisLayer(end);
    thisOutLayer[coder::internal::intlength(layersDetails[b_i].f1.size(0),
                                            layersDetails[b_i].f1.size(1)) -
                 1] =
        layersDetails[b_i]
            .f1[layersDetails[b_i].f1.size(0) * layersDetails[b_i].f1.size(1) -
                1];
    // 'allocateParamsToLayers:24' outLayers{i} = thisOutLayer;
    for (i1 = 0; i1 < 5; i1++) {
      outLayers[b_i].f1[i1] = thisOutLayer[i1];
    }
  }
}

} // namespace RAT

// End of code generation (allocateParamsToLayers.cpp)

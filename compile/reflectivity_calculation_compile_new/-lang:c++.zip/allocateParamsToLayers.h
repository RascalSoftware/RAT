//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// allocateParamsToLayers.h
//
// Code generation for function 'allocateParamsToLayers'
//

#ifndef ALLOCATEPARAMSTOLAYERS_H
#define ALLOCATEPARAMSTOLAYERS_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT {
struct cell_wrap_14;

struct cell_wrap_17;

} // namespace RAT

// Function Declarations
namespace RAT {
void allocateParamsToLayers(
    const ::coder::array<double, 2U> &params,
    const ::coder::array<cell_wrap_14, 1U> &layersDetails,
    ::coder::array<cell_wrap_17, 2U> &outLayers);

}

#endif
// End of code generation (allocateParamsToLayers.h)

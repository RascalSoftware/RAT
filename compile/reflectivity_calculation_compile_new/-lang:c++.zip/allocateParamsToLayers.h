//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// allocateParamsToLayers.h
//
// Code generation for function 'allocateParamsToLayers'
//
#ifndef ALLOCATEPARAMSTOLAYERS_H
#define ALLOCATEPARAMSTOLAYERS_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct cell_wrap_14;
  struct cell_wrap_19;
}

// Function Declarations
namespace RAT
{
  void allocateParamsToLayers(const real_T params_data[], const cell_wrap_14
    layersDetails_data[], const int32_T *layersDetails_size, cell_wrap_19
    outLayers_data[], int32_T outLayers_size[2]);
}

#endif

// End of code generation (allocateParamsToLayers.h)

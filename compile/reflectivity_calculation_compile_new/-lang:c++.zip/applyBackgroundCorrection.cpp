//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// applyBackgroundCorrection.cpp
//
// Code generation for function 'applyBackgroundCorrection'
//

// Include files
#include "applyBackgroundCorrection.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  void applyBackgroundCorrection(::coder::array<real_T, 2U> &reflect, ::coder::
    array<real_T, 2U> &Simul, real_T shifted_dat_data[], const int32_T
    shifted_dat_size[2], real_T backg, real_T backsType)
  {
    ::coder::array<real_T, 1U> c_reflect;
    real_T b_shifted_dat_data[1000];
    switch (static_cast<int32_T>(backsType)) {
     case 1:
      {
        int32_T b_reflect;
        int32_T i;

        // Add background to the simulation
        b_reflect = reflect.size(0) - 1;
        c_reflect.set_size(b_reflect + 1);
        for (i = 0; i <= b_reflect; i++) {
          c_reflect[i] = reflect[i + reflect.size(0)] + backg;
        }

        b_reflect = c_reflect.size(0);
        for (i = 0; i < b_reflect; i++) {
          reflect[i + reflect.size(0)] = c_reflect[i];
        }

        b_reflect = Simul.size(0) - 1;
        c_reflect.set_size(b_reflect + 1);
        for (i = 0; i <= b_reflect; i++) {
          c_reflect[i] = Simul[i + Simul.size(0)] + backg;
        }

        b_reflect = c_reflect.size(0);
        for (i = 0; i < b_reflect; i++) {
          Simul[i + Simul.size(0)] = c_reflect[i];
        }
      }
      break;

     case 2:
      {
        int32_T b_reflect;
        int32_T b_shifted_dat_size;
        int32_T i;

        //          %Subtract the background from the data..
        b_reflect = shifted_dat_size[0] - 1;
        b_shifted_dat_size = b_reflect + 1;
        for (i = 0; i <= b_reflect; i++) {
          b_shifted_dat_data[i] = shifted_dat_data[i + shifted_dat_size[0]] -
            backg;
        }

        for (i = 0; i < b_shifted_dat_size; i++) {
          shifted_dat_data[i + shifted_dat_size[0]] = b_shifted_dat_data[i];
        }

        // shifted_dat(:,3) = shifted_dat(:,3) - backg;
      }
      break;
    }
  }
}

// End of code generation (applyBackgroundCorrection.cpp)

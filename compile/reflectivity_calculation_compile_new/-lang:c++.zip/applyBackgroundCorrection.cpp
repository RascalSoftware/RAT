//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// applyBackgroundCorrection.cpp
//
// Code generation for function 'applyBackgroundCorrection'
//

// Include files
#include "applyBackgroundCorrection.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function    [reflect,Simul,shifted_dat] =
// applyBackgroundCorrection(reflect,Simul,shifted_dat,backg,backsType)
namespace RAT {
void applyBackgroundCorrection(::coder::array<double, 2U> &reflect,
                               ::coder::array<double, 2U> &Simul,
                               ::coder::array<double, 2U> &shifted_dat,
                               double backg, double backsType)
{
  ::coder::array<double, 1U> c_reflect;
  // 'applyBackgroundCorrection:3' switch backsType
  switch (static_cast<int>(backsType)) {
  case 1: {
    int b_reflect;
    int i;
    // 'applyBackgroundCorrection:4' case 1
    // Add background to the simulation
    // 'applyBackgroundCorrection:6' reflect(:,2) = reflect(:,2) + backg;
    b_reflect = reflect.size(0) - 1;
    c_reflect.set_size(b_reflect + 1);
    for (i = 0; i <= b_reflect; i++) {
      c_reflect[i] = reflect[i + reflect.size(0)] + backg;
    }
    b_reflect = c_reflect.size(0);
    for (i = 0; i < b_reflect; i++) {
      reflect[i + reflect.size(0)] = c_reflect[i];
    }
    // 'applyBackgroundCorrection:7' Simul(:,2) = Simul(:,2) + backg;
    b_reflect = Simul.size(0) - 1;
    c_reflect.set_size(b_reflect + 1);
    for (i = 0; i <= b_reflect; i++) {
      c_reflect[i] = Simul[i + Simul.size(0)] + backg;
    }
    b_reflect = c_reflect.size(0);
    for (i = 0; i < b_reflect; i++) {
      Simul[i + Simul.size(0)] = c_reflect[i];
    }
  } break;
  case 2: {
    int b_reflect;
    int i;
    // 'applyBackgroundCorrection:8' case 2
    //          %Subtract the background from the data..
    // 'applyBackgroundCorrection:10' shifted_dat(:,2) = shifted_dat(:,2) -
    // backg;
    b_reflect = shifted_dat.size(0) - 1;
    c_reflect.set_size(b_reflect + 1);
    for (i = 0; i <= b_reflect; i++) {
      c_reflect[i] = shifted_dat[i + shifted_dat.size(0)] - backg;
    }
    b_reflect = c_reflect.size(0);
    for (i = 0; i < b_reflect; i++) {
      shifted_dat[i + shifted_dat.size(0)] = c_reflect[i];
    }
    // shifted_dat(:,3) = shifted_dat(:,3) - backg;
  } break;
  }
}

} // namespace RAT

// End of code generation (applyBackgroundCorrection.cpp)

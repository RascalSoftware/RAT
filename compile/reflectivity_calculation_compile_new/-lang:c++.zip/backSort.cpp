//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// backSort.cpp
//
// Code generation for function 'backSort'
//

// Include files
#include "backSort.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function [backg,qshift,sf,nba,nbs,resol] =
// backSort(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,shifts,sf,nba,nbs,res)
namespace RAT {
void backSort(double cBacks, double cShifts, double cScales, double cNbas,
              double cNbss, double cRes,
              const ::coder::array<double, 2U> &backs,
              const ::coder::array<double, 2U> &shifts,
              const ::coder::array<double, 2U> &sf,
              const ::coder::array<double, 2U> &nba,
              const ::coder::array<double, 2U> &nbs,
              const ::coder::array<double, 2U> &res, double *backg,
              double *qshift, double *b_sf, double *b_nba, double *b_nbs,
              double *resol)
{
  //      Distributes the background and shift values among the different
  //      contrasts
  //
  //      USAGE::
  //
  //          [backg,qshift,sf,nba,nbs,resol] =
  //          backsort(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,shifts,sf,nba,nbs,res)
  //
  //      INPUTS:
  //         * cBacks  :         Which backround value is associated with each
  //         contrast
  //         * cShifts  :        Which qz_shift value is associated with each
  //         contrast
  //         * cScales  :        Which scalefactor value is associated with each
  //         contrast
  //         * cNbas  :          Which NBa value is associated with each
  //         contrast
  //         * cNbss  :          Which Nbs value is associated with each
  //         contrast
  //         * cRes  :           Which resolution value is associated with each
  //         contrast
  //         * backs  :          List of all background values.
  //         * shifts  :         List of all qz-shift values
  //         * sf :              List of all scalefactor values
  //         * nba :             List of all nba values
  //         * nbs :             List of all nbs values
  //         * res :             List of all resolution values
  //
  //      OUTPUTS:
  //         * backgs : list of actual background values for each contrast
  //         * qshifts : list of actual shift values for each contrast
  //         * sfs : list of actual shift values for each contrast
  //         * nbas : list of actual shift values for each contrast
  //         * nbss : list of actual shift values for each contrast
  //         * nbss : list of actual shift values for each contrast
  //
  //
  // for i = 1:nc
  // thisBack = cBacks(i);
  // 'backSort:40' backg = backs(cBacks);
  *backg = backs[static_cast<int>(cBacks) - 1];
  // thisShift = cShifts(i);
  // 'backSort:43' qshift = shifts(cShifts);
  *qshift = shifts[static_cast<int>(cShifts) - 1];
  // thisScale = cScales(i);
  // 'backSort:46' sf = sf(cScales);
  *b_sf = sf[static_cast<int>(cScales) - 1];
  // thisNbair = cNbas(i);
  // 'backSort:49' nba = nba(cNbas);
  *b_nba = nba[static_cast<int>(cNbas) - 1];
  // thisNbsub = cNbss(i);
  // 'backSort:52' nbs = nbs(cNbss);
  *b_nbs = nbs[static_cast<int>(cNbss) - 1];
  // thisResol = cRes(i);
  // 'backSort:55' if cRes ~= -1
  if (cRes != -1.0) {
    // 'backSort:56' resol = res(cRes);
    *resol = res[static_cast<int>(cRes) - 1];
  } else {
    // 'backSort:57' else
    // 'backSort:58' resol = -1;
    *resol = -1.0;
    //  Negative value means we have a data resolution..
  }
  // end
}

} // namespace RAT

// End of code generation (backSort.cpp)

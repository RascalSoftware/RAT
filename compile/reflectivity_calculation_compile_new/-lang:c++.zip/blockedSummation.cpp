//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// blockedSummation.cpp
//
// Code generation for function 'blockedSummation'
//

// Include files
#include "blockedSummation.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Declarations
namespace RAT {
namespace coder {
static void nestedIter(const ::coder::array<double, 2U> &x, int vlen,
                       ::coder::array<double, 1U> &y);

}
} // namespace RAT

// Function Definitions
//
//
namespace RAT {
namespace coder {
static void nestedIter(const ::coder::array<double, 2U> &x, int vlen,
                       ::coder::array<double, 1U> &y)
{
  ::coder::array<double, 1U> bsum;
  int b_k;
  int bsubs_idx_1;
  int firstBlockLength;
  int i;
  int k;
  int lastBlockLength;
  int nblocks;
  y.set_size(x.size(0));
  bsum.set_size(x.size(0));
  if (vlen <= 1024) {
    firstBlockLength = vlen;
    lastBlockLength = 0;
    nblocks = 1;
  } else {
    firstBlockLength = 1024;
    nblocks = vlen / 1024;
    lastBlockLength = vlen - (nblocks << 10);
    if (lastBlockLength > 0) {
      nblocks++;
    } else {
      lastBlockLength = 1024;
    }
  }
  i = x.size(0);
  for (k = 0; k < i; k++) {
    y[k] = x[k];
  }
  for (k = 2; k <= firstBlockLength; k++) {
    i = x.size(0);
    for (b_k = 0; b_k < i; b_k++) {
      if (vlen >= 2) {
        y[b_k] = y[b_k] + x[b_k + x.size(0) * (k - 1)];
      }
    }
  }
  for (int ib{2}; ib <= nblocks; ib++) {
    int hi;
    firstBlockLength = (ib - 1) << 10;
    i = x.size(0);
    if (0 <= x.size(0) - 1) {
      bsubs_idx_1 = firstBlockLength + 1;
    }
    for (k = 0; k < i; k++) {
      bsum[k] = x[k + x.size(0) * (bsubs_idx_1 - 1)];
    }
    if (ib == nblocks) {
      hi = lastBlockLength;
    } else {
      hi = 1024;
    }
    for (k = 2; k <= hi; k++) {
      int varargin_1;
      varargin_1 = firstBlockLength + k;
      i = x.size(0);
      for (b_k = 0; b_k < i; b_k++) {
        if (vlen >= 2) {
          bsum[b_k] = bsum[b_k] + x[b_k + x.size(0) * (varargin_1 - 1)];
        }
      }
    }
    i = y.size(0);
    for (k = 0; k < i; k++) {
      y[k] = y[k] + bsum[k];
    }
  }
}

//
//
void blockedSummation(const ::coder::array<double, 2U> &x, int vlen,
                      ::coder::array<double, 1U> &y)
{
  if ((x.size(0) == 0) || (x.size(1) == 0) || (vlen == 0)) {
    int loop_ub;
    y.set_size(x.size(0));
    loop_ub = x.size(0);
    for (int i{0}; i < loop_ub; i++) {
      y[i] = 0.0;
    }
  } else {
    nestedIter(x, vlen, y);
  }
}

//
//
double nestedIter(const ::coder::array<double, 1U> &x, int vlen)
{
  double y;
  int firstBlockLength;
  int k;
  int lastBlockLength;
  int nblocks;
  if (vlen <= 1024) {
    firstBlockLength = vlen;
    lastBlockLength = 0;
    nblocks = 1;
  } else {
    firstBlockLength = 1024;
    nblocks = vlen / 1024;
    lastBlockLength = vlen - (nblocks << 10);
    if (lastBlockLength > 0) {
      nblocks++;
    } else {
      lastBlockLength = 1024;
    }
  }
  y = x[0];
  for (k = 2; k <= firstBlockLength; k++) {
    if (vlen >= 2) {
      y += x[k - 1];
    }
  }
  for (int ib{2}; ib <= nblocks; ib++) {
    double bsum;
    int hi;
    firstBlockLength = (ib - 1) << 10;
    bsum = x[firstBlockLength];
    if (ib == nblocks) {
      hi = lastBlockLength;
    } else {
      hi = 1024;
    }
    for (k = 2; k <= hi; k++) {
      if (vlen >= 2) {
        bsum += x[(firstBlockLength + k) - 1];
      }
    }
    y += bsum;
  }
  return y;
}

} // namespace coder
} // namespace RAT

// End of code generation (blockedSummation.cpp)

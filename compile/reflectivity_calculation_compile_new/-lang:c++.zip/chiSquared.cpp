//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// chiSquared.cpp
//
// Code generation for function 'chiSquared'
//

// Include files
#include "chiSquared.h"
#include "blockedSummation.h"
#include "find.h"
#include "minOrMax.h"
#include "power.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace RAT
{
  real_T chiSquared(const real_T thisData_data[], const int32_T thisData_size[2],
                    const ::coder::array<real_T, 2U> &thisFit, real_T P)
  {
    ::coder::array<real_T, 1U> b_i;
    ::coder::array<real_T, 1U> d_terms_data;
    ::coder::array<real_T, 1U> thisData;
    ::coder::array<int32_T, 1U> r;
    ::coder::array<boolean_T, 1U> b_terms_data;
    real_T terms_data[1000];
    real_T dv[2];
    real_T N;
    real_T y;
    int32_T i;
    int32_T loop_ub;
    int32_T terms_size;
    int16_T tmp_data[1000];
    boolean_T c_terms_data[1000];

    //  Chi-squared function is used to evaluate the goodness of fit.
    //  It is a measure of the difference between the observed and expected.
    // allChis = zeros(1,numberOfContrasts);
    //      thisData = allData{i};
    //      thisFit = allFits{i};
    dv[0] = thisData_size[0];
    dv[1] = 1.0;
    N = coder::internal::b_maximum(dv);
    if (N <= P) {
      N = P + 1.0;
    }

    loop_ub = thisData_size[0];
    thisData.set_size(thisData_size[0]);
    for (i = 0; i < loop_ub; i++) {
      thisData[i] = (thisData_data[i + thisData_size[0]] - thisFit[i +
                     thisFit.size(0)]) / thisData_data[i + thisData_size[0] * 2];
    }

    coder::power(thisData, b_i);
    terms_size = b_i.size(0);
    loop_ub = b_i.size(0);
    for (i = 0; i < loop_ub; i++) {
      terms_data[i] = b_i[i];
    }

    for (i = 0; i < terms_size; i++) {
      c_terms_data[i] = (terms_data[i] == rtInf);
    }

    b_terms_data.set(&c_terms_data[0], terms_size);
    coder::eml_find(b_terms_data, r);
    b_i.set_size(r.size(0));
    loop_ub = r.size(0);
    for (i = 0; i < loop_ub; i++) {
      b_i[i] = r[i];
    }

    if (b_i.size(0) != 0) {
      int32_T tmp_size;
      tmp_size = b_i.size(0);
      loop_ub = b_i.size(0);
      for (i = 0; i < loop_ub; i++) {
        tmp_data[i] = static_cast<int16_T>(static_cast<int32_T>(b_i[i]));
      }

      for (i = 0; i < tmp_size; i++) {
        terms_data[tmp_data[i] - 1] = 0.0;
      }
    }

    d_terms_data.set(&terms_data[0], terms_size);
    if (d_terms_data.size(0) == 0) {
      y = 0.0;
    } else {
      y = coder::nestedIter(d_terms_data, d_terms_data.size(0));
    }

    return 1.0 / (N - P) * y;

    // allChis(i) = chi2;
  }
}

// End of code generation (chiSquared.cpp)

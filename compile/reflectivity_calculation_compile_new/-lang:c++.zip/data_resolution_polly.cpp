//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// data_resolution_polly.cpp
//
// Code generation for function 'data_resolution_polly'
//

// Include files
#include "data_resolution_polly.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function out = data_resolution_polly(xdata,ydata,resData,points)
namespace RAT {
void data_resolution_polly(const ::coder::array<double, 1U> &xdata,
                           const ::coder::array<double, 1U> &ydata,
                           const ::coder::array<double, 1U> &resData,
                           double points, ::coder::array<double, 1U> &out)
{
  int i;
  int loop_ub_tmp;
  //  Apply resolution correction
  // 'data_resolution_polly:5' dummydata = zeros(points,1);
  loop_ub_tmp = static_cast<int>(points);
  out.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    out[i] = 0.0;
  }
  // 'data_resolution_polly:6' dummyref = ydata;
  // 'data_resolution_polly:8' for j = 1:points
  for (int j{0}; j < loop_ub_tmp; j++) {
    double ihi;
    double sumg;
    int ilow;
    // 'data_resolution_polly:9' res = resData(j);
    // 'data_resolution_polly:11' sumg = 0;
    sumg = 0.0;
    // 'data_resolution_polly:12' dummydata(j) = 0;
    out[j] = 0.0;
    // 'data_resolution_polly:14' if (j>10)
    if (j + 1U > 10U) {
      // 'data_resolution_polly:15' ilow = -10;
      ilow = -10;
    } else {
      // 'data_resolution_polly:16' else
      // 'data_resolution_polly:17' ilow = -j + 1;
      ilow = static_cast<int>(-(static_cast<double>(j) + 1.0)) + 1;
    }
    // 'data_resolution_polly:20' if (j < (points - 10))
    if (static_cast<double>(j) + 1.0 < points - 10.0) {
      // 'data_resolution_polly:21' ihi = 10;
      ihi = 10.0;
    } else {
      // 'data_resolution_polly:22' else
      // 'data_resolution_polly:23' ihi = points - j;
      ihi = points - (static_cast<double>(j) + 1.0);
    }
    // 'data_resolution_polly:26' for i = ilow:ihi
    i = static_cast<int>(ihi + (1.0 - static_cast<double>(ilow)));
    for (int b_i{0}; b_i < i; b_i++) {
      double a;
      double g;
      int a_tmp;
      // 'data_resolution_polly:27' g =
      // exp(-1*((xdata(j+i)-xdata(j))/(res*xdata(j)))^2);
      a_tmp = static_cast<int>((static_cast<double>(j) + 1.0) +
                               static_cast<double>(ilow + b_i)) -
              1;
      a = (xdata[a_tmp] - xdata[j]) / (resData[j] * xdata[j]);
      g = std::exp(-(a * a));
      // 'data_resolution_polly:28' sumg = sumg + g;
      sumg += g;
      // 'data_resolution_polly:29' dummydata(j) = dummydata(j) + dummyref(i+j)
      // * g;
      out[j] = out[j] + ydata[a_tmp] * g;
    }
    // 'data_resolution_polly:31' if (sumg ~= 0)
    if (sumg != 0.0) {
      // 'data_resolution_polly:32' dummydata(j) = dummydata(j) / sumg;
      out[j] = out[j] / sumg;
    }
  }
  // 'data_resolution_polly:36' out = dummydata;
}

} // namespace RAT

// End of code generation (data_resolution_polly.cpp)

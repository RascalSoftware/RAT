//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// groupLayers_Mod.cpp
//
// Code generation for function 'groupLayers_Mod'
//

// Include files
#include "groupLayers_Mod.h"
#include "rt_nonfinite.h"
#include "strcmp.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function [outLayers, outSsubs] =
// groupLayers_Mod(allLayers,allRoughs,geometry,nbair,nbsubs)
namespace RAT {
void groupLayers_Mod(const ::coder::array<double, 2U> &allLayers,
                     double allRoughs, const ::coder::array<char, 2U> &geometry,
                     double nbair, double nbsubs,
                     ::coder::array<double, 2U> &outLayers, double *outSsubs)
{
  ::coder::array<double, 2U> layers;
  ::coder::array<double, 1U> roughs;
  int b_loop_ub;
  int i;
  int loop_ub;
  // Arrange layers according to geometry and apply any coverage correction.
  //
  //  USAGE::
  //
  //      [outLayers, outSsubs] =
  //      groupLayers_Mod(allLayers,allRoughs,numberOfContrasts,geometry,nbairs,nbsubs)
  //
  //  INPUTS:
  //
  //      * allLayers =         cell array, one for each contrast. Each cell is
  //      the list of layer values for each contrast.
  //      * allRoughs =         Double of substrate roughness for each contrast.
  //      * numberOfContrasts = double.
  //      * geometry =          'Air / Liquid (or solid)' or 'Solid / Liquid'
  //      * nbairs =            vector of nbair values.
  //      * nbsubs =            vector of nbsub values.
  //
  //      The paratt calculation procedds through the
  //      z,rho,rough stack, and the parameter 'ssub' in
  //      callParatt is the final roughness encountered.
  //
  //      * For air liquid 'ssub' is therefore the substrate roughness.
  //
  //      * For solid liquid, the substrate roughness is the first roughness
  //      encountered, and 'ssub' is then the roughness of the outermost layer
  //
  //  Outputs:
  //
  //      * outLayers = cell array of layers param values for each contrast.
  //
  //      * outSsubs =  vector of substrate roughness values.
  //
  // outLayers = cell(1,numberOfContrasts);
  // outSsubs = zeros(1,numberOfContrasts);
  // 'groupLayers_Mod:37' coder.varsize('layers',[Inf,5],[1 1]);
  // for i = 1:numberOfContrasts
  // 'groupLayers_Mod:40' output = allLayers;
  // 'groupLayers_Mod:41' s_sub = allRoughs;
  *outSsubs = allRoughs;
  // 'groupLayers_Mod:42' layers = zeros(size(output));
  layers.set_size(allLayers.size(0), 5);
  loop_ub = allLayers.size(0);
  for (i = 0; i < 5; i++) {
    for (b_loop_ub = 0; b_loop_ub < loop_ub; b_loop_ub++) {
      layers[b_loop_ub + layers.size(0) * i] = 0.0;
    }
  }
  // 'groupLayers_Mod:43' if ~isempty(output)
  if (allLayers.size(0) != 0) {
    // 'groupLayers_Mod:44' if strcmpi(geometry,'air/substrate')
    if (coder::internal::i_strcmp(geometry)) {
      // 'groupLayers_Mod:45' layers = output;
      layers.set_size(allLayers.size(0), 5);
      loop_ub = allLayers.size(0);
      for (i = 0; i < 5; i++) {
        for (b_loop_ub = 0; b_loop_ub < loop_ub; b_loop_ub++) {
          layers[b_loop_ub + layers.size(0) * i] =
              allLayers[b_loop_ub + allLayers.size(0) * i];
        }
      }
      // s_sub = rsub;
    } else {
      int c_loop_ub;
      // 'groupLayers_Mod:47' else
      // 'groupLayers_Mod:48' roughs = output(:,3);
      // 'groupLayers_Mod:49' sldss = output(:,2);
      // 'groupLayers_Mod:50' thicks = output(:,1);
      // 'groupLayers_Mod:51' rsub = roughs(end);
      *outSsubs = allLayers[(allLayers.size(0) + allLayers.size(0) * 2) - 1];
      // 'groupLayers_Mod:52' if length(roughs) > 1
      if (allLayers.size(0) > 1) {
        // 'groupLayers_Mod:53' roughs = [s_sub ; roughs(1:end-1)];
        loop_ub = allLayers.size(0);
        roughs.set_size(allLayers.size(0));
        roughs[0] = allRoughs;
        for (i = 0; i <= loop_ub - 2; i++) {
          roughs[i + 1] = allLayers[i + allLayers.size(0) * 2];
        }
      } else {
        // 'groupLayers_Mod:54' else
        // 'groupLayers_Mod:55' roughs = s_sub;
        roughs.set_size(1);
        roughs[0] = allRoughs;
      }
      // 'groupLayers_Mod:57' n = size(output,2);
      // 'groupLayers_Mod:58' if n == 5
      // 'groupLayers_Mod:59' cov = output(:,4);
      // 'groupLayers_Mod:60' layers = [thicks(:) sldss(:) roughs(:) cov(:)];
      loop_ub = allLayers.size(0);
      b_loop_ub = allLayers.size(0);
      c_loop_ub = allLayers.size(0);
      layers.set_size(allLayers.size(0), 4);
      for (i = 0; i < loop_ub; i++) {
        layers[i] = allLayers[i];
      }
      for (i = 0; i < b_loop_ub; i++) {
        layers[i + layers.size(0)] = allLayers[i + allLayers.size(0)];
      }
      loop_ub = roughs.size(0);
      for (i = 0; i < loop_ub; i++) {
        layers[i + layers.size(0) * 2] = roughs[i];
      }
      for (i = 0; i < c_loop_ub; i++) {
        layers[i + layers.size(0) * 3] = allLayers[i + allLayers.size(0) * 3];
      }
      // 'groupLayers_Mod:64' s_sub = rsub;
    }
    // Deal with the %coverage if present
    // 'groupLayers_Mod:68' n = size(output,2);
    // 'groupLayers_Mod:69' l = size(output,1);
    // 'groupLayers_Mod:70' if n == 5
    // 'groupLayers_Mod:71' for j = 1:l
    i = allLayers.size(0);
    for (int j{0}; j < i; j++) {
      double pc_add;
      double this_pcw;
      // 'groupLayers_Mod:72' this_pcw = output(j,4);
      this_pcw = allLayers[j + allLayers.size(0) * 3];
      // 'groupLayers_Mod:73' if output(j,5) == 1
      if (allLayers[j + allLayers.size(0) * 4] == 1.0) {
        // 'groupLayers_Mod:74' pc_add = nbair;
        pc_add = nbair;
      } else {
        // 'groupLayers_Mod:75' else
        // 'groupLayers_Mod:76' pc_add = nbsubs;
        pc_add = nbsubs;
      }
      // 'groupLayers_Mod:78' if ~isnan(this_pcw)
      if (!std::isnan(this_pcw)) {
        // 'groupLayers_Mod:79' layers(j,2) = pc_add*(this_pcw/100) +
        // (1-(this_pcw/100))*layers(j,2);
        layers[j + layers.size(0)] =
            pc_add * (this_pcw / 100.0) +
            (1.0 - this_pcw / 100.0) * layers[j + layers.size(0)];
      }
    }
  }
  //      problem.layers{i} = layers;
  //      problem.ssubs(i) = s_sub;
  // 'groupLayers_Mod:86' if ~isempty(layers)
  if (layers.size(0) != 0) {
    // 'groupLayers_Mod:87' outLayers = layers(:,1:3);
    loop_ub = layers.size(0);
    outLayers.set_size(layers.size(0), 3);
    for (i = 0; i < 3; i++) {
      for (b_loop_ub = 0; b_loop_ub < loop_ub; b_loop_ub++) {
        outLayers[b_loop_ub + outLayers.size(0) * i] =
            layers[b_loop_ub + layers.size(0) * i];
      }
    }
  } else {
    // 'groupLayers_Mod:88' else
    // 'groupLayers_Mod:89' outLayers = zeros(1,3);
    outLayers.set_size(1, 3);
    outLayers[0] = 0.0;
    outLayers[outLayers.size(0)] = 0.0;
    outLayers[outLayers.size(0) * 2] = 0.0;
  }
  // 'groupLayers_Mod:91' outSsubs = s_sub;
}

//
// function [outLayers, outSsubs] =
// groupLayers_Mod(allLayers,allRoughs,geometry,nbair,nbsubs)
void groupLayers_Mod(const ::coder::array<double, 2U> &allLayers,
                     double allRoughs, const ::coder::array<char, 2U> &geometry,
                     ::coder::array<double, 2U> &outLayers, double *outSsubs)
{
  ::coder::array<double, 2U> layers;
  ::coder::array<double, 1U> roughs;
  int b_loop_ub;
  int i;
  int i1;
  int loop_ub;
  unsigned int unnamed_idx_0;
  // Arrange layers according to geometry and apply any coverage correction.
  //
  //  USAGE::
  //
  //      [outLayers, outSsubs] =
  //      groupLayers_Mod(allLayers,allRoughs,numberOfContrasts,geometry,nbairs,nbsubs)
  //
  //  INPUTS:
  //
  //      * allLayers =         cell array, one for each contrast. Each cell is
  //      the list of layer values for each contrast.
  //      * allRoughs =         Double of substrate roughness for each contrast.
  //      * numberOfContrasts = double.
  //      * geometry =          'Air / Liquid (or solid)' or 'Solid / Liquid'
  //      * nbairs =            vector of nbair values.
  //      * nbsubs =            vector of nbsub values.
  //
  //      The paratt calculation procedds through the
  //      z,rho,rough stack, and the parameter 'ssub' in
  //      callParatt is the final roughness encountered.
  //
  //      * For air liquid 'ssub' is therefore the substrate roughness.
  //
  //      * For solid liquid, the substrate roughness is the first roughness
  //      encountered, and 'ssub' is then the roughness of the outermost layer
  //
  //  Outputs:
  //
  //      * outLayers = cell array of layers param values for each contrast.
  //
  //      * outSsubs =  vector of substrate roughness values.
  //
  // outLayers = cell(1,numberOfContrasts);
  // outSsubs = zeros(1,numberOfContrasts);
  // 'groupLayers_Mod:37' coder.varsize('layers',[Inf,5],[1 1]);
  // for i = 1:numberOfContrasts
  // 'groupLayers_Mod:40' output = allLayers;
  // 'groupLayers_Mod:41' s_sub = allRoughs;
  *outSsubs = allRoughs;
  // 'groupLayers_Mod:42' layers = zeros(size(output));
  unnamed_idx_0 = static_cast<unsigned int>(allLayers.size(0));
  layers.set_size(allLayers.size(0), allLayers.size(1));
  loop_ub = allLayers.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_loop_ub = static_cast<int>(unnamed_idx_0);
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      layers[i1 + layers.size(0) * i] = 0.0;
    }
  }
  // 'groupLayers_Mod:43' if ~isempty(output)
  if (allLayers.size(0) != 0) {
    // 'groupLayers_Mod:44' if strcmpi(geometry,'air/substrate')
    if (coder::internal::i_strcmp(geometry)) {
      // 'groupLayers_Mod:45' layers = output;
      layers.set_size(allLayers.size(0), allLayers.size(1));
      loop_ub = allLayers.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub = allLayers.size(0);
        for (i1 = 0; i1 < b_loop_ub; i1++) {
          layers[i1 + layers.size(0) * i] =
              allLayers[i1 + allLayers.size(0) * i];
        }
      }
      // s_sub = rsub;
    } else {
      // 'groupLayers_Mod:47' else
      // 'groupLayers_Mod:48' roughs = output(:,3);
      // 'groupLayers_Mod:49' sldss = output(:,2);
      // 'groupLayers_Mod:50' thicks = output(:,1);
      // 'groupLayers_Mod:51' rsub = roughs(end);
      *outSsubs = allLayers[(allLayers.size(0) + allLayers.size(0) * 2) - 1];
      // 'groupLayers_Mod:52' if length(roughs) > 1
      if (allLayers.size(0) > 1) {
        // 'groupLayers_Mod:53' roughs = [s_sub ; roughs(1:end-1)];
        loop_ub = allLayers.size(0);
        roughs.set_size(allLayers.size(0));
        roughs[0] = allRoughs;
        for (i = 0; i <= loop_ub - 2; i++) {
          roughs[i + 1] = allLayers[i + allLayers.size(0) * 2];
        }
      } else {
        // 'groupLayers_Mod:54' else
        // 'groupLayers_Mod:55' roughs = s_sub;
        roughs.set_size(1);
        roughs[0] = allRoughs;
      }
      // 'groupLayers_Mod:57' n = size(output,2);
      // 'groupLayers_Mod:58' if n == 5
      // 'groupLayers_Mod:61' else
      // 'groupLayers_Mod:62' layers = [thicks(:) sldss(:) roughs(:)];
      loop_ub = allLayers.size(0);
      b_loop_ub = allLayers.size(0);
      layers.set_size(allLayers.size(0), 3);
      for (i = 0; i < loop_ub; i++) {
        layers[i] = allLayers[i];
      }
      for (i = 0; i < b_loop_ub; i++) {
        layers[i + layers.size(0)] = allLayers[i + allLayers.size(0)];
      }
      loop_ub = roughs.size(0);
      for (i = 0; i < loop_ub; i++) {
        layers[i + layers.size(0) * 2] = roughs[i];
      }
      // 'groupLayers_Mod:64' s_sub = rsub;
    }
    // Deal with the %coverage if present
    // 'groupLayers_Mod:68' n = size(output,2);
    // 'groupLayers_Mod:69' l = size(output,1);
    // 'groupLayers_Mod:70' if n == 5
  }
  //      problem.layers{i} = layers;
  //      problem.ssubs(i) = s_sub;
  // 'groupLayers_Mod:86' if ~isempty(layers)
  if (layers.size(0) != 0) {
    // 'groupLayers_Mod:87' outLayers = layers(:,1:3);
    loop_ub = layers.size(0);
    outLayers.set_size(layers.size(0), 3);
    for (i = 0; i < 3; i++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        outLayers[i1 + outLayers.size(0) * i] = layers[i1 + layers.size(0) * i];
      }
    }
  } else {
    // 'groupLayers_Mod:88' else
    // 'groupLayers_Mod:89' outLayers = zeros(1,3);
    outLayers.set_size(1, 3);
    outLayers[0] = 0.0;
    outLayers[outLayers.size(0)] = 0.0;
    outLayers[outLayers.size(0) * 2] = 0.0;
  }
  // 'groupLayers_Mod:91' outSsubs = s_sub;
}

} // namespace RAT

// End of code generation (groupLayers_Mod.cpp)

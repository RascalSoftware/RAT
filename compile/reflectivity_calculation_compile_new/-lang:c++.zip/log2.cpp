//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// log2.cpp
//
// Code generation for function 'log2'
//

// Include files
#include "log2.h"
#include "rt_nonfinite.h"
#include <cmath>
#include <math.h>

// Function Definitions
//
//
namespace RAT {
namespace coder {
void b_log2(double x, double *f, double *e)
{
  int eint;
  if ((!std::isinf(x)) && (!std::isnan(x))) {
    *f = frexp(x, &eint);
    *e = eint;
  } else {
    *f = x;
    *e = 0.0;
  }
}

} // namespace coder
} // namespace RAT

// End of code generation (log2.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// loopCppCustlayWrapper_CustLaycontrast.cpp
//
// Code generation for function 'loopCppCustlayWrapper_CustLaycontrast'
//

// Include files
#include "loopCppCustlayWrapper_CustLaycontrast.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Function Definitions
//
// function [allLayers,allRoughs] =  loopCppCustlayWrapper_CustLaycontrast
// (cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
// shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params)
namespace RAT {
void loopCppCustlayWrapper_CustLaycontrast(
    double numberOfContrasts, ::coder::array<cell_wrap_31, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs)
{
  int loop_ub_tmp;
  //  This is the function that deals with the *C++ Custom User Scripts*.
  //  This calls a mex called **testDLL_mex** which is a wrapper for the C++
  //  class Library in **libManager.h**. Library Class uses **dylib.hpp** to
  //  load the dynamic library at runtime. The dynamic library would be the
  //  user's custom c++ script compiled into a **DLL/dylib/.so** file.
  //
  //      INPUTS:
  //
  //         * cBacks  :         Which background value is associated with each
  //         contrast
  //         * cShifts  :        Which qz_shift value is associated with each
  //         contrast
  //         * cScales  :        Which scalefactor value is associated with each
  //         contrast
  //         * cNbas  :          Which NBa value is associated with each
  //         contrast
  //         * cNbss  :          Which Nbs value is associated with each
  //         contrast
  //         * cRes  :           Which resolution value is associated with each
  //         contrast
  //         * backs  :          List of all background values.
  //         * shifts  :         List of all qz-shift values
  //         * sf :              List of all scalefactor values
  //         * nba :             List of all nba values
  //         * nbs :             List of all nbs values
  //         * res :             List of all resolution values
  //         * cCustFiles :
  //         * numberOfContrasts : Number of contrasts
  //         * customFiles :      Cell of all custom user script files
  //         * params :           Structure of all parameters
  //
  //
  //      OUTPUTS:
  //
  //         * allLayers :        Cell of all layers
  //         * allRoughs :        Cell of all roughnesses
  //
  // 'loopCppCustlayWrapper_CustLaycontrast:36' coder.extrinsic('testDLL_mex');
  // 'loopCppCustlayWrapper_CustLaycontrast:37' allLayers =
  // cell(numberOfContrasts,1); 'loopCppCustlayWrapper_CustLaycontrast:38' for i
  // = 1:numberOfContrasts
  loop_ub_tmp = static_cast<int>(numberOfContrasts);
  allLayers.set_size(loop_ub_tmp);
  // 'loopCppCustlayWrapper_CustLaycontrast:41'
  // coder.varsize('allLayers{:}',[1000,5],[1,1]);
  // 'loopCppCustlayWrapper_CustLaycontrast:44' allRoughs =
  // zeros(numberOfContrasts,1);
  allRoughs.set_size(loop_ub_tmp);
  for (int i{0}; i < loop_ub_tmp; i++) {
    // 'loopCppCustlayWrapper_CustLaycontrast:39' allLayers{i} = [1 ; 1];
    allLayers[i].f1.size[0] = 2;
    allLayers[i].f1.size[1] = 1;
    allLayers[i].f1.data[0] = 1.0;
    allLayers[i].f1.data[1] = 1.0;
    allRoughs[i] = 0.0;
  }
  // 'loopCppCustlayWrapper_CustLaycontrast:45' cfunctionName
  // =[customFiles{1}{1},0]; ; % dll name must be same as function name
  // 'loopCppCustlayWrapper_CustLaycontrast:46' cLibName =
  // [customFiles{1}{3},0]; customFiles{1}{3};
  // 'loopCppCustlayWrapper_CustLaycontrast:48' numberOfContrasts =
  // int32(numberOfContrasts);
  //      strLibName = string(LibName);
  //      strfunctionName = string(functionName);
  // 'loopCppCustlayWrapper_CustLaycontrast:51' if coder.target('MEX')
  // 'loopCppCustlayWrapper_CustLaycontrast:77' if coder.target('MATLAB')
}

} // namespace RAT

// End of code generation (loopCppCustlayWrapper_CustLaycontrast.cpp)

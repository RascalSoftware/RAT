//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// loopCppCustlayWrapper_CustLaycontrast.h
//
// Code generation for function 'loopCppCustlayWrapper_CustLaycontrast'
//
#ifndef LOOPCPPCUSTLAYWRAPPER_CUSTLAYCONTRAST_H
#define LOOPCPPCUSTLAYWRAPPER_CUSTLAYCONTRAST_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct cell_wrap_1;
}

// Function Declarations
namespace RAT
{
  void loopCppCustlayWrapper_CustLaycontrast(real_T numberOfContrasts, ::coder::
    array<cell_wrap_1, 1U> &allLayers, ::coder::array<real_T, 1U> &allRoughs);
}

#endif

// End of code generation (loopCppCustlayWrapper_CustLaycontrast.h)

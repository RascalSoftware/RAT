//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// loopMatalbCustlayWrapper_CustLaycontrast.cpp
//
// Code generation for function 'loopMatalbCustlayWrapper_CustLaycontrast'
//

// Include files
#include "loopMatalbCustlayWrapper_CustLaycontrast.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function [allLayers, allRoughs] =
// loopMatalbCustlayWrapper_CustLaycontrast(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
//      shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params)
namespace RAT {
void loopMatalbCustlayWrapper_CustLaycontrast(
    double numberOfContrasts, ::coder::array<cell_wrap_14, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs)
{
  ::coder::array<cell_wrap_32, 1U> tempAllLayers;
  ::coder::array<signed char, 1U> tempAllRoughs;
  int b_i;
  int i;
  int loop_ub;
  //  Wrapper function for calling 'loopMatlabCustomLayers'. This wrapper is
  //  necessary to deal with typedef problems for the coder if feval is used
  //  directly from the main function
  // 'loopMatalbCustlayWrapper_CustLaycontrast:9' tempAllLayers =
  // cell(numberOfContrasts,1); 'loopMatalbCustlayWrapper_CustLaycontrast:10'
  // tempAllRoughs = zeros(numberOfContrasts,1);
  i = static_cast<int>(numberOfContrasts);
  tempAllRoughs.set_size(i);
  // 'loopMatalbCustlayWrapper_CustLaycontrast:11' allLayers =
  // cell(numberOfContrasts,1); 'loopMatalbCustlayWrapper_CustLaycontrast:12'
  // allRoughs = zeros(numberOfContrasts,1);
  // 'loopMatalbCustlayWrapper_CustLaycontrast:14' for i = 1:numberOfContrasts
  // 'loopMatalbCustlayWrapper_CustLaycontrast:18'
  // coder.varsize('tempAllLayers{:}',[10000 5],[1 1]);
  //  Dummy values to allow code generation to proceed....
  // 'loopMatalbCustlayWrapper_CustLaycontrast:21' for i = 1:numberOfContrasts
  tempAllLayers.set_size(i);
  for (b_i = 0; b_i < i; b_i++) {
    // 'loopMatalbCustlayWrapper_CustLaycontrast:22' tempAllLayers{i} = [0 0 0];
    tempAllLayers[b_i].f1.set_size(1, 3);
    tempAllLayers[b_i].f1[0] = 0.0;
    tempAllLayers[b_i].f1[tempAllLayers[b_i].f1.size(0)] = 0.0;
    tempAllLayers[b_i].f1[tempAllLayers[b_i].f1.size(0) * 2] = 0.0;
    // 'loopMatalbCustlayWrapper_CustLaycontrast:23' tempAllRoughs(i) = 1;
    tempAllRoughs[b_i] = 1;
  }
  //  All the following is intended to be casting from mxArray's to doubles.
  //  I'm not sure if all of this is necessary, but it compiles...
  // 'loopMatalbCustlayWrapper_CustLaycontrast:28' for i = 1:numberOfContrasts
  allLayers.set_size(i);
  for (b_i = 0; b_i < i; b_i++) {
    // 'loopMatalbCustlayWrapper_CustLaycontrast:29' tempOut = tempAllLayers{i};
    // 'loopMatalbCustlayWrapper_CustLaycontrast:30' n = [0 0];
    // 'loopMatalbCustlayWrapper_CustLaycontrast:31' n = size(tempOut);
    // 'loopMatalbCustlayWrapper_CustLaycontrast:32' newOut = zeros(n);
    // 'loopMatalbCustlayWrapper_CustLaycontrast:33' newOut = tempOut;
    // 'loopMatalbCustlayWrapper_CustLaycontrast:34' allLayers{i} = newOut;
    allLayers[b_i].f1.set_size(1, 3);
    for (loop_ub = 0; loop_ub < 3; loop_ub++) {
      for (int i1{0}; i1 < 1; i1++) {
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * loop_ub] =
            tempAllLayers[b_i].f1[tempAllLayers[b_i].f1.size(0) * loop_ub];
      }
    }
  }
  // allLayers = tempAllLayers;
  // 'loopMatalbCustlayWrapper_CustLaycontrast:38' allRoughs = tempAllRoughs;
  allRoughs.set_size(tempAllRoughs.size(0));
  loop_ub = tempAllRoughs.size(0);
  for (i = 0; i < loop_ub; i++) {
    allRoughs[i] = 1.0;
  }
}

} // namespace RAT

// End of code generation (loopMatalbCustlayWrapper_CustLaycontrast.cpp)

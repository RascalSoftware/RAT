//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// loopMatalbCustlayWrapper_CustLaysingle.h
//
// Code generation for function 'loopMatalbCustlayWrapper_CustLaysingle'
//

#ifndef LOOPMATALBCUSTLAYWRAPPER_CUSTLAYSINGLE_H
#define LOOPMATALBCUSTLAYWRAPPER_CUSTLAYSINGLE_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT {
struct cell_wrap_14;

}

// Function Declarations
namespace RAT {
void loopMatalbCustlayWrapper_CustLaysingle(
    double numberOfContrasts, ::coder::array<cell_wrap_14, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs);

}

#endif
// End of code generation (loopMatalbCustlayWrapper_CustLaysingle.h)

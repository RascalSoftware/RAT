//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// lower.cpp
//
// Code generation for function 'lower'
//

// Include files
#include "lower.h"
#include "reflectivity_calculation_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
//
namespace RAT {
namespace coder {
void lower(const ::coder::array<char, 2U> &x, ::coder::array<char, 2U> &y)
{
  int i;
  y.set_size(1, x.size(1));
  i = x.size(1);
  for (int k{0}; k < i; k++) {
    y[k] = cv[static_cast<unsigned char>(x[k]) & 127];
  }
}

} // namespace coder
} // namespace RAT

// End of code generation (lower.cpp)

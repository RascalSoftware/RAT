//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// makeSLDProfileXY.cpp
//
// Code generation for function 'makeSLDProfileXY'
//

// Include files
#include "makeSLDProfileXY.h"
#include "asymconvstep.h"
#include "blockedSummation.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function out =
// makeSLDProfileXY(nbair,nbsub,ssub,layers,numberOfLayers,nrepeats)
namespace RAT {
void makeSLDProfileXY(double nbair, double nbsub, double ssub,
                      const ::coder::array<double, 2U> &layers,
                      double numberOfLayers, double nrepeats,
                      ::coder::array<double, 2U> &out)
{
  ::coder::array<double, 2U> Lays;
  ::coder::array<double, 2U> SLD;
  ::coder::array<double, 2U> airBox;
  ::coder::array<double, 2U> r;
  ::coder::array<double, 2U> r1;
  ::coder::array<double, 2U> thisBox;
  ::coder::array<double, 2U> x;
  ::coder::array<double, 1U> b_layers;
  double subBox_data[101];
  double tmp_data[101];
  int b_loop_ub;
  int i;
  int loop_ub;
  // 'makeSLDProfileXY:3' if numberOfLayers>0
  if (numberOfLayers > 0.0) {
    double lastBoxEdge;
    double nextLayRough;
    double y;
    int i1;
    // 'makeSLDProfileXY:4' layerThicks = sum(layers(:,1));
    // 'makeSLDProfileXY:5' totalRange = (layerThicks*nrepeats) + 150;
    loop_ub = layers.size(0);
    b_layers.set_size(layers.size(0));
    for (i = 0; i < loop_ub; i++) {
      b_layers[i] = layers[i];
    }
    if (b_layers.size(0) == 0) {
      y = 0.0;
    } else {
      y = coder::nestedIter(b_layers, b_layers.size(0));
    }
    y = y * nrepeats + 150.0;
    // 'makeSLDProfileXY:6' x = 0:totalRange;
    if (std::isnan(y)) {
      x.set_size(1, 1);
      x[0] = rtNaN;
    } else if (y < 0.0) {
      x.set_size(1, 0);
    } else if (std::isinf(y) && (0.0 == y)) {
      x.set_size(1, 1);
      x[0] = rtNaN;
    } else {
      loop_ub = static_cast<int>(std::floor(y));
      x.set_size(1, loop_ub + 1);
      for (i = 0; i <= loop_ub; i++) {
        x[i] = i;
      }
    }
    // 'makeSLDProfileXY:7' Lays = zeros(length(x),(numberOfLayers*nrepeats)+2);
    y = numberOfLayers * nrepeats;
    Lays.set_size(x.size(1), static_cast<int>(y + 2.0));
    loop_ub = static_cast<int>(y + 2.0);
    for (i = 0; i < loop_ub; i++) {
      b_loop_ub = x.size(1);
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        Lays[i1 + Lays.size(0) * i] = 0.0;
      }
    }
    // 'makeSLDProfileXY:8' boxCen = 0;
    // 'makeSLDProfileXY:9' boxWidth = 100;
    // 'makeSLDProfileXY:10' nextLayRough = layers(1,3);
    nextLayRough = layers[layers.size(0) * 2];
    // 'makeSLDProfileXY:11' airBox =
    // asymconvstep(x,boxWidth,boxCen,nextLayRough,nextLayRough,nbair);
    asymconvstep(x, 100.0, 0.0, nextLayRough, nextLayRough, nbair, airBox);
    // 'makeSLDProfileXY:12' lastBoxEdge = boxCen + (boxWidth/2);
    lastBoxEdge = 50.0;
    // 'makeSLDProfileXY:13' for n = 1:nrepeats
    i = static_cast<int>(nrepeats);
    for (int n{0}; n < i; n++) {
      // 'makeSLDProfileXY:14' for i = 1:numberOfLayers
      i1 = static_cast<int>(numberOfLayers);
      for (int b_i{0}; b_i < i1; b_i++) {
        double thisBoxCentre;
        double thisLayThick;
        // 'makeSLDProfileXY:15' thisLayThick = layers(i,1);
        thisLayThick = layers[b_i];
        // 'makeSLDProfileXY:16' thisLaySLD = layers(i,2);
        // 'makeSLDProfileXY:17' thisLayRough = layers(i,3);
        // 'makeSLDProfileXY:18' if i<numberOfLayers
        if (static_cast<double>(b_i) + 1.0 < numberOfLayers) {
          // 'makeSLDProfileXY:19' nextLayRough = layers(i+1,3);
          nextLayRough = layers[(b_i + layers.size(0) * 2) + 1];
          //              elseif (i == numberOfLayers) && (n < nrepeats)
          //                  nextLayRough = layers(1,3);
        } else {
          // 'makeSLDProfileXY:22' else
          // 'makeSLDProfileXY:23' nextLayRough = ssub;
          nextLayRough = ssub;
        }
        // 'makeSLDProfileXY:25' thisBoxCentre = lastBoxEdge + (thisLayThick/2);
        thisBoxCentre = lastBoxEdge + thisLayThick / 2.0;
        // 'makeSLDProfileXY:26' thisBox =
        // asymconvstep(x,thisLayThick,thisBoxCentre,thisLayRough,nextLayRough,thisLaySLD);
        asymconvstep(x, thisLayThick, thisBoxCentre,
                     layers[b_i + layers.size(0) * 2], nextLayRough,
                     layers[b_i + layers.size(0)], thisBox);
        // 'makeSLDProfileXY:27' Lays(:,i+(numberOfLayers*(n-1))) = thisBox;
        b_loop_ub =
            static_cast<int>((static_cast<double>(b_i) + 1.0) +
                             numberOfLayers *
                                 ((static_cast<double>(n) + 1.0) - 1.0)) -
            1;
        loop_ub = Lays.size(0);
        for (int i2{0}; i2 < loop_ub; i2++) {
          Lays[i2 + Lays.size(0) * b_loop_ub] = thisBox[i2];
        }
        // 'makeSLDProfileXY:28' lastBoxEdge = thisBoxCentre + (thisLayThick/2);
        lastBoxEdge = thisBoxCentre + thisLayThick / 2.0;
        // plot(x,Lays(:,i));
      }
    }
    // 'makeSLDProfileXY:32' thisLayRough = nextLayRough;
    // layers(end,3);
    // 'makeSLDProfileXY:33' thisLayThick = (x(end)-lastBoxEdge)*2;
    // 'makeSLDProfileXY:34' thisLaySLD = nbsub;
    // 'makeSLDProfileXY:35' nextLayRough = ssub;
    // 'makeSLDProfileXY:36' thisBoxCentre = x(end);
    // 'makeSLDProfileXY:37' Lays(:,(numberOfLayers*nrepeats)+1) =
    // asymconvstep(x,thisLayThick,thisBoxCentre,thisLayRough,nextLayRough,thisLaySLD);
    asymconvstep(x, (x[x.size(1) - 1] - lastBoxEdge) * 2.0, x[x.size(1) - 1],
                 nextLayRough, ssub, nbsub, r1);
    loop_ub = Lays.size(0);
    for (i = 0; i < loop_ub; i++) {
      Lays[i + Lays.size(0) * (static_cast<int>(y + 1.0) - 1)] = r1[i];
    }
    // plot(x,Lays(:,(numberOfLayers*nrepeats)+1))
    // 'makeSLDProfileXY:40' Lays(:,(numberOfLayers*nrepeats)+2) = airBox;
    loop_ub = Lays.size(0);
    for (i = 0; i < loop_ub; i++) {
      Lays[i + Lays.size(0) * (static_cast<int>(y + 2.0) - 1)] = airBox[i];
    }
    // plot(x,Lays(:,(numberOfLayers*nrepeats)+2))
    // 'makeSLDProfileXY:42' SLD = sum(Lays,2);
    coder::blockedSummation(Lays, Lays.size(1), b_layers);
    b_loop_ub = b_layers.size(0);
    SLD.set_size(b_layers.size(0), 1);
    for (i = 0; i < 1; i++) {
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        SLD[i1] = b_layers[i1];
      }
    }
  } else {
    double widths;
    // 'makeSLDProfileXY:43' else
    // 'makeSLDProfileXY:44' x = 0:100;
    x.set_size(1, 101);
    // 'makeSLDProfileXY:45' subsBoxCen = max(x);
    // 'makeSLDProfileXY:46' airBoxCen = 0;
    // 'makeSLDProfileXY:47' widths = max(x);
    // 'makeSLDProfileXY:48' airBox =
    // asymconvstep(x,widths,airBoxCen,ssub,ssub,nbair);
    r.set_size(1, 101);
    for (i = 0; i < 101; i++) {
      x[i] = i;
      tmp_data[i] = i;
      r[i] = i;
    }
    widths = coder::internal::maximum(tmp_data);
    asymconvstep(r, widths, 0.0, ssub, ssub, nbair, airBox);
    // 'makeSLDProfileXY:49' subBox =
    // asymconvstep(x,widths,subsBoxCen,ssub,ssub,nbsub);
    r.set_size(1, 101);
    for (i = 0; i < 101; i++) {
      tmp_data[i] = i;
      r[i] = i;
    }
    asymconvstep(r, widths, coder::internal::maximum(tmp_data), ssub, ssub,
                 nbsub, r1);
    loop_ub = r1.size(1);
    for (i = 0; i < loop_ub; i++) {
      subBox_data[i] = r1[i];
    }
    // 'makeSLDProfileXY:50' SLD = airBox + subBox;
    SLD.set_size(1, airBox.size(1));
    loop_ub = airBox.size(1);
    for (i = 0; i < loop_ub; i++) {
      SLD[SLD.size(0) * i] = airBox[i] + subBox_data[i];
    }
  }
  // plot(x,SLD)
  // 'makeSLDProfileXY:54' out = [x(:),SLD(:)];
  b_loop_ub = SLD.size(0) * SLD.size(1);
  out.set_size(x.size(1), 2);
  loop_ub = x.size(1);
  for (i = 0; i < loop_ub; i++) {
    out[i] = x[i];
  }
  for (i = 0; i < b_loop_ub; i++) {
    out[i + out.size(0)] = SLD[i];
  }
}

} // namespace RAT

// End of code generation (makeSLDProfileXY.cpp)

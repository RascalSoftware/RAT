//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// makeSLDProfiles.cpp
//
// Code generation for function 'makeSLDProfiles'
//

// Include files
#include "makeSLDProfiles.h"
#include "makeSLDProfileXY.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function sldProfile= makeSLDProfiles(nbair,nbsub,sld,ssub,repeats)
namespace RAT {
void makeSLDProfiles(double nbair, double nbsub,
                     const ::coder::array<double, 2U> &sld, double ssub,
                     const double repeats[2],
                     ::coder::array<double, 2U> &sldProfile)
{
  double reps;
  // 'makeSLDProfiles:4' lays = size(sld,1);
  // 'makeSLDProfiles:5' if repeats(1) == 0
  if (repeats[0] == 0.0) {
    // 'makeSLDProfiles:6' reps = 1;
    reps = 1.0;
  } else {
    // 'makeSLDProfiles:7' else
    // 'makeSLDProfiles:8' reps = repeats(2);
    reps = repeats[1];
  }
  // 'makeSLDProfiles:12' sldProfile =
  // makeSLDProfileXY(nbair,nbsub,ssub,sld,lays,reps);
  makeSLDProfileXY(nbair, nbsub, ssub, sld, static_cast<double>(sld.size(0)),
                   reps, sldProfile);
}

} // namespace RAT

// End of code generation (makeSLDProfiles.cpp)

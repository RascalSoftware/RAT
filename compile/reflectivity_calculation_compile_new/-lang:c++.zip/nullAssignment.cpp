//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// nullAssignment.cpp
//
// Code generation for function 'nullAssignment'
//

// Include files
#include "nullAssignment.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
//
namespace RAT {
namespace coder {
namespace internal {
void nullAssignment(::coder::array<double, 2U> &x)
{
  int j;
  int nrows;
  int nrowx;
  nrowx = x.size(0) - 2;
  nrows = x.size(0) - 1;
  for (j = 0; j < 5; j++) {
    for (int i{0}; i < nrows; i++) {
      x[i + x.size(0) * j] = x[(i + x.size(0) * j) + 1];
    }
  }
  if (1 > nrows) {
    nrowx = 0;
  } else {
    nrowx++;
  }
  for (nrows = 0; nrows < 5; nrows++) {
    for (j = 0; j < nrowx; j++) {
      x[j + nrowx * nrows] = x[j + x.size(0) * nrows];
    }
  }
  x.set_size(nrowx, 5);
}

} // namespace internal
} // namespace coder
} // namespace RAT

// End of code generation (nullAssignment.cpp)

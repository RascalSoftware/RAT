//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// nullAssignment.cpp
//
// Code generation for function 'nullAssignment'
//

// Include files
#include "nullAssignment.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace RAT
{
  namespace coder
  {
    namespace internal
    {
      void nullAssignment(real_T x_data[], int32_T x_size[2])
      {
        int32_T b_i;
        int32_T j;
        int32_T nrows;
        nrows = x_size[0] - 1;
        for (j = 0; j < 5; j++) {
          for (int32_T i{0}; i < nrows; i++) {
            b_i = i + x_size[0] * j;
            x_data[b_i] = x_data[b_i + 1];
          }
        }

        if (1 > nrows) {
          nrows = 0;
        } else {
          nrows = x_size[0] - 1;
        }

        for (b_i = 0; b_i < 5; b_i++) {
          for (j = 0; j < nrows; j++) {
            x_data[j + nrows * b_i] = x_data[j + x_size[0] * b_i];
          }
        }

        x_size[0] = nrows;
        x_size[1] = 5;
      }
    }
  }
}

// End of code generation (nullAssignment.cpp)

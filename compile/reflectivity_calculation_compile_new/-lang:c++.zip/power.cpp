//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// power.cpp
//
// Code generation for function 'power'
//

// Include files
#include "power.h"
#include "reflectivity_calculation_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
//
namespace RAT {
namespace coder {
void power(const ::coder::array<double, 1U> &a, ::coder::array<double, 1U> &y)
{
  int N;
  y.set_size(a.size(0));
  N = a.size(0);
  for (int k{0}; k < N; k++) {
    y[k] = rt_powd_snf(a[k], 2.0);
  }
}

} // namespace coder
} // namespace RAT

// End of code generation (power.cpp)

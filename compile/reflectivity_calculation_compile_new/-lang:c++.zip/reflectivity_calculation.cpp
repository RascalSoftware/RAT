//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// reflectivity_calculation.cpp
//
// Code generation for function 'reflectivity_calculation'
//

// Include files
#include "reflectivity_calculation.h"
#include "reflectivity_calculation_data.h"
#include "reflectivity_calculation_initialize.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_reflectivityCalculation.h"
#include "strcmp.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Type Definitions
namespace RAT {
struct cell_wrap_13 {
  ::coder::array<double, 2U> f1;
};

} // namespace RAT

// Function Declarations
namespace RAT {
static void cast(const ::coder::array<cell_wrap_0, 2U> &t0_f1,
                 const ::coder::array<cell_wrap_1, 2U> &t0_f2,
                 const ::coder::array<cell_wrap_0, 2U> &t0_f3,
                 const ::coder::array<cell_wrap_2, 2U> &t0_f4,
                 const ::coder::array<cell_wrap_3, 2U> &t0_f5,
                 const ::coder::array<cell_wrap_4, 1U> &t0_f6,
                 const ::coder::array<cell_wrap_5, 2U> &t0_f7,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f8,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f9,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f10,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f11,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f12,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f13,
                 const ::coder::array<cell_wrap_7, 2U> &t0_f14, cell_16 *b);

static void cast(const ::coder::array<cell_wrap_1, 2U> &b,
                 ::coder::array<cell_wrap_14, 2U> &c);

static void cast(const ::coder::array<cell_wrap_2, 2U> &b,
                 ::coder::array<cell_wrap_14, 2U> &c);

static void cast(const ::coder::array<cell_wrap_3, 2U> &b,
                 ::coder::array<cell_wrap_14, 2U> &c);

static void cast(const ::coder::array<cell_wrap_4, 1U> &b,
                 ::coder::array<cell_wrap_14, 1U> &c);

static void cast(const ::coder::array<cell_wrap_9, 1U> &b,
                 ::coder::array<cell_wrap_12, 1U> &c);

static void cast(const ::coder::array<cell_wrap_10, 1U> &b,
                 ::coder::array<cell_wrap_13, 1U> &c);

static void cast(const ::coder::array<cell_wrap_14, 1U> &b,
                 ::coder::array<cell_wrap_12, 1U> &c);

static void cast(const ::coder::array<cell_wrap_14, 1U> &b,
                 ::coder::array<cell_wrap_13, 1U> &c);

} // namespace RAT

// Function Definitions
namespace RAT {
static void cast(const ::coder::array<cell_wrap_0, 2U> &t0_f1,
                 const ::coder::array<cell_wrap_1, 2U> &t0_f2,
                 const ::coder::array<cell_wrap_0, 2U> &t0_f3,
                 const ::coder::array<cell_wrap_2, 2U> &t0_f4,
                 const ::coder::array<cell_wrap_3, 2U> &t0_f5,
                 const ::coder::array<cell_wrap_4, 1U> &t0_f6,
                 const ::coder::array<cell_wrap_5, 2U> &t0_f7,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f8,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f9,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f10,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f11,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f12,
                 const ::coder::array<cell_wrap_6, 2U> &t0_f13,
                 const ::coder::array<cell_wrap_7, 2U> &t0_f14, cell_16 *b)
{
  int i;
  int loop_ub;
  b->f1.set_size(1, t0_f1.size(1));
  loop_ub = t0_f1.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f1[i] = t0_f1[i];
  }
  cast(t0_f2, b->f2);
  b->f3.set_size(1, t0_f3.size(1));
  loop_ub = t0_f3.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f3[i] = t0_f3[i];
  }
  cast(t0_f4, b->f4);
  cast(t0_f5, b->f5);
  cast(t0_f6, b->f6);
  b->f7.set_size(1, t0_f7.size(1));
  loop_ub = t0_f7.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f7[i] = t0_f7[i];
  }
  b->f8.set_size(1, t0_f8.size(1));
  loop_ub = t0_f8.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f8[i] = t0_f8[i];
  }
  b->f9.set_size(1, t0_f9.size(1));
  loop_ub = t0_f9.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f9[i] = t0_f9[i];
  }
  b->f10.set_size(1, t0_f10.size(1));
  loop_ub = t0_f10.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f10[i] = t0_f10[i];
  }
  b->f11.set_size(1, t0_f11.size(1));
  loop_ub = t0_f11.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f11[i] = t0_f11[i];
  }
  b->f12.set_size(1, t0_f12.size(1));
  loop_ub = t0_f12.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f12[i] = t0_f12[i];
  }
  b->f13.set_size(1, t0_f13.size(1));
  loop_ub = t0_f13.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f13[i] = t0_f13[i];
  }
  b->f14.set_size(1, t0_f14.size(1));
  loop_ub = t0_f14.size(1);
  for (i = 0; i < loop_ub; i++) {
    b->f14[i] = t0_f14[i];
  }
}

static void cast(const ::coder::array<cell_wrap_1, 2U> &b,
                 ::coder::array<cell_wrap_14, 2U> &c)
{
  int i;
  c.set_size(1, b.size(1));
  i = b.size(1) - 1;
  for (int i1{0}; i1 <= i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(1);
    c[c.size(0) * i1].f1.set_size(b[b.size(0) * i1].f1.size(0),
                                  b[b.size(0) * i1].f1.size(1));
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size(0);
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_2, 2U> &b,
                 ::coder::array<cell_wrap_14, 2U> &c)
{
  int i;
  c.set_size(1, b.size(1));
  i = b.size(1) - 1;
  for (int i1{0}; i1 <= i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size[1];
    c[c.size(0) * i1].f1.set_size(b[b.size(0) * i1].f1.size[0],
                                  b[b.size(0) * i1].f1.size[1]);
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size[0];
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[c[i1].f1.size(0) * i2] = b[i1].f1.data[b[i1].f1.size[0] * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_3, 2U> &b,
                 ::coder::array<cell_wrap_14, 2U> &c)
{
  int i;
  c.set_size(1, b.size(1));
  i = b.size(1) - 1;
  for (int i1{0}; i1 <= i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(1);
    c[c.size(0) * i1].f1.set_size(b[b.size(0) * i1].f1.size(0),
                                  b[b.size(0) * i1].f1.size(1));
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size(0);
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[c[i1].f1.size(0) * i2] = b[i1].f1[b[i1].f1.size(0) * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_4, 1U> &b,
                 ::coder::array<cell_wrap_14, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size[1];
    c[i1].f1.set_size(b[i1].f1.size[0], b[i1].f1.size[1]);
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size[0];
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[c[i1].f1.size(0) * i2] = b[i1].f1.data[b[i1].f1.size[0] * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_9, 1U> &b,
                 ::coder::array<cell_wrap_12, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(0);
    c[i1].f1.set_size(b[i1].f1.size(0), 2);
    for (int i2{0}; i2 < 2; i2++) {
      for (int i3{0}; i3 < loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_10, 1U> &b,
                 ::coder::array<cell_wrap_13, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(0);
    c[i1].f1.set_size(b[i1].f1.size(0), 3);
    for (int i2{0}; i2 < 3; i2++) {
      for (int i3{0}; i3 < loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_14, 1U> &b,
                 ::coder::array<cell_wrap_12, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(1);
    c[i1].f1.set_size(b[i1].f1.size(0), b[i1].f1.size(1));
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size(0);
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_14, 1U> &b,
                 ::coder::array<cell_wrap_13, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(1);
    c[i1].f1.set_size(b[i1].f1.size(0), b[i1].f1.size(1));
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size(0);
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

//
// function [problem,result] =
// reflectivity_calculation(problemDef,problemDef_cells,problemDef_limits,controls)
void reflectivity_calculation(const struct0_T *problemDef,
                              const cell_8 *problemDef_cells, const struct1_T *,
                              const struct2_T *controls, struct4_T *problem,
                              cell_11 *result)
{
  ::coder::array<cell_wrap_10, 1U> b_layerSlds;
  ::coder::array<cell_wrap_12, 1U> Simulation;
  ::coder::array<cell_wrap_12, 1U> reflectivity;
  ::coder::array<cell_wrap_12, 1U> sldProfiles;
  ::coder::array<cell_wrap_13, 1U> allLayers;
  ::coder::array<cell_wrap_13, 1U> layerSlds;
  ::coder::array<cell_wrap_13, 1U> shifted_data;
  ::coder::array<cell_wrap_14, 1U> b_allLayers;
  ::coder::array<cell_wrap_14, 1U> b_shifted_data;
  ::coder::array<cell_wrap_14, 1U> b_sldProfiles;
  ::coder::array<cell_wrap_9, 1U> b_Simulation;
  ::coder::array<cell_wrap_9, 1U> b_reflectivity;
  cell_16 r;
  int b_i;
  int i;
  int i1;
  if (!isInitialized_reflectivity_calculation) {
    reflectivity_calculation_initialize();
  }
  //  Main entry point into the reflectivity calculation for the toolbox.
  //  This is the main function that is called by any of the minimisers or
  //  analysis tools from the rest of the toolbox.
  //
  //  *The main job of this function is to decide which type of calculation
  //  (i.e. 'Target function' is required, and call the relevant routines. The
  //  types of available target functions are:*
  //
  //  * standardTF     - The main basic target function type, for non polarised
  //  neutrons (or x-rays) with non-absorbing samples. Different model types are
  //  specified in sub functions from here.
  //
  //  * standardTFAbs  - Identical to standardTF, but includes imaginary
  //  refractive index terms.
  //
  //  * oilWaterTF     - Target function for oil-water samples
  //
  //  * domainsTF      - Target function for samples consisting of domains which
  //  are larger than the beam lateral coherence length.
  //
  //  * polarisedTF    - Target function for cases for polarised neutrons with
  //  polarisation analysis.
  //
  //  for compilation, we have to preallocate memory for the output arrays
  //  Setting these parameters in the struct defines them as doubles
  // 'reflectivity_calculation:23' problem.ssubs = 0;
  problem->ssubs.set_size(1);
  problem->ssubs[0] = 0.0;
  // 'reflectivity_calculation:24' problem.backgrounds = 0;
  problem->backgrounds.set_size(1);
  problem->backgrounds[0] = 0.0;
  // 'reflectivity_calculation:25' problem.qshifts = 0;
  problem->qshifts.set_size(1);
  problem->qshifts[0] = 0.0;
  // 'reflectivity_calculation:26' problem.scalefactors = 0;
  problem->scalefactors.set_size(1);
  problem->scalefactors[0] = 0.0;
  // 'reflectivity_calculation:27' problem.nbairs = 0;
  problem->nbairs.set_size(1);
  problem->nbairs[0] = 0.0;
  // 'reflectivity_calculation:28' problem.nbsubs = 0;
  problem->nbsubs.set_size(1);
  problem->nbsubs[0] = 0.0;
  // 'reflectivity_calculation:29' problem.resolutions = 0;
  problem->resolutions.set_size(1);
  problem->resolutions[0] = 0.0;
  // 'reflectivity_calculation:30' problem.calculations.all_chis = 0;
  problem->calculations.all_chis.set_size(1);
  problem->calculations.all_chis[0] = 0.0;
  // 'reflectivity_calculation:31' problem.calculations.sum_chi = 0;
  problem->calculations.sum_chi = 0.0;
  // 'reflectivity_calculation:32' problem.allSubRough = 0;
  problem->allSubRough.set_size(1);
  problem->allSubRough[0] = 0.0;
  // 'reflectivity_calculation:33' problem.resample = 0;
  problem->resample.set_size(1, 1);
  problem->resample[0] = 0.0;
  //  We also foll the results arrays to define their
  //  type and size. (NOTE: at the moment we have a 'coder.varsize'
  //  pre-processor directives for the compiler here and at the
  //  end for the results block. We are unlikely to need both
  //  TODO: Find out which is necessary and tidy this up.
  // 'reflectivity_calculation:41' numberOfContrasts =
  // problemDef.numberOfContrasts; 'reflectivity_calculation:42' reflectivity =
  // cell(numberOfContrasts,1); 'reflectivity_calculation:43' for i =
  // 1:numberOfContrasts
  i = static_cast<int>(problemDef->numberOfContrasts);
  reflectivity.set_size(i);
  // 'reflectivity_calculation:46' coder.varsize('reflectivity{:}',[10000 2],[1
  // 0]); 'reflectivity_calculation:48' Simulation = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:49' for i = 1:numberOfContrasts
  Simulation.set_size(i);
  // 'reflectivity_calculation:52' coder.varsize('Simulation{:}',[10000 2],[1
  // 0]); 'reflectivity_calculation:54' shifted_data =
  // cell(numberOfContrasts,1); 'reflectivity_calculation:55' for i =
  // 1:numberOfContrasts
  shifted_data.set_size(i);
  // 'reflectivity_calculation:58' coder.varsize('shifted_data{:}',[10000 3],[1
  // 0]); 'reflectivity_calculation:60' layerSlds = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:61' for i = 1:numberOfContrasts
  layerSlds.set_size(i);
  // 'reflectivity_calculation:64' coder.varsize('layerSlds{:}',[10000 3],[1
  // 0]); 'reflectivity_calculation:66' sldProfiles = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:67' for i = 1:numberOfContrasts
  sldProfiles.set_size(i);
  // 'reflectivity_calculation:70' coder.varsize('sldProfiles{:}',[10000 2],[1
  // 0]); 'reflectivity_calculation:72' allLayers = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:73' for i = 1:numberOfContrasts
  allLayers.set_size(i);
  for (b_i = 0; b_i < i; b_i++) {
    // 'reflectivity_calculation:44' reflectivity{i} = [1 1 ; 1 1];
    reflectivity[b_i].f1.set_size(2, 2);
    reflectivity[b_i].f1[0] = 1.0;
    reflectivity[b_i].f1[1] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
    // 'reflectivity_calculation:50' Simulation{i} = [1 1 ; 1 1];
    Simulation[b_i].f1.set_size(2, 2);
    Simulation[b_i].f1[0] = 1.0;
    Simulation[b_i].f1[1] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
    // 'reflectivity_calculation:56' shifted_data{i} = [1 1 1 ; 1 1 1];
    shifted_data[b_i].f1.set_size(2, 3);
    // 'reflectivity_calculation:62' layerSlds{i} = [1 1 1 ; 1 1 1];
    layerSlds[b_i].f1.set_size(2, 3);
    // 'reflectivity_calculation:68' sldProfiles{i} = [1 1 ; 1 1];
    sldProfiles[b_i].f1.set_size(2, 2);
    sldProfiles[b_i].f1[0] = 1.0;
    sldProfiles[b_i].f1[1] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
    // 'reflectivity_calculation:74' allLayers{i} = [1 1 1; 1 1 1];
    allLayers[b_i].f1.set_size(2, 3);
    for (i1 = 0; i1 < 3; i1++) {
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i1] = 1.0;
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i1 + 1] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i1] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i1 + 1] = 1.0;
      allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i1] = 1.0;
      allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i1 + 1] = 1.0;
    }
  }
  // 'reflectivity_calculation:76' coder.varsize('allLayers{:}',[10000 3],[1
  // 0]); Decide which target function we are calling ans call the relevant
  // routines 'reflectivity_calculation:80' whichTF = problemDef.TF;
  // 'reflectivity_calculation:81' switch whichTF
  if (coder::internal::b_strcmp(problemDef->TF)) {
    i1 = 0;
  } else {
    i1 = -1;
  }
  switch (i1) {
  case 0:
    // 'reflectivity_calculation:82' case 'standardTF'
    // 'reflectivity_calculation:83'
    // [problem,reflectivity,Simulation,shifted_data,layerSlds,sldProfiles,allLayers]
    // =
    // standardTF_reflectivityCalculation(problemDef,problemDef_cells,problemDef_limits,controls);
    cast(problemDef_cells->f1, problemDef_cells->f2, problemDef_cells->f3,
         problemDef_cells->f4, problemDef_cells->f5, problemDef_cells->f6,
         problemDef_cells->f7, problemDef_cells->f8, problemDef_cells->f9,
         problemDef_cells->f10, problemDef_cells->f11, problemDef_cells->f12,
         problemDef_cells->f13, problemDef_cells->f14, &r);
    standardTF_reflectivityCalculation(
        problemDef, &r, controls, problem, b_reflectivity, b_Simulation,
        b_shifted_data, b_layerSlds, b_sldProfiles, b_allLayers);
    cast(b_reflectivity, reflectivity);
    cast(b_Simulation, Simulation);
    cast(b_shifted_data, shifted_data);
    cast(b_layerSlds, layerSlds);
    cast(b_sldProfiles, sldProfiles);
    cast(b_allLayers, allLayers);
    // case 'standardTFAbs'
    // [problem,reflectivity,Simulation,shifted_data,layerSlds,sldProfiles,allLayers]
    // =
    // standardTFAbs_reflectivityCalculation(problemDef,problemDef_cells,problemDef_limits,controls);
    // case 'oilWaterTF'
    // problem =
    // oilWaterTF_reflectivityCalculation(problemDef,problemDef_cells,controls);
    // case 'polarisedTF'
    // problem =
    // polarisedTF_reflectivityCalculation(problemDef,problemDef_cells,controls);
    // case 'domainsTF'
    // [problem,reflectivity,Simulation,shifted_data,layerSlds,sldProfiles,allLayers]
    // =
    // domainsTF_reflectivityCalculation(problemDef,problemDef_cells,problemDef_limits,controls);
    break;
  }
  // 'reflectivity_calculation:95' result = cell(1,6);
  // 'reflectivity_calculation:97' cell1 = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:98' for i = 1:numberOfContrasts
  result->f1.set_size(i);
  // 'reflectivity_calculation:101' result{1} = cell1;
  // 'reflectivity_calculation:103' cell2 = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:104' for i = 1:numberOfContrasts
  result->f2.set_size(i);
  // 'reflectivity_calculation:107' result{2} = cell2;
  // 'reflectivity_calculation:109' cell3 = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:110' for i = 1:numberOfContrasts
  result->f3.set_size(i);
  // 'reflectivity_calculation:113' result{3} = cell3;
  // 'reflectivity_calculation:115' cell4 = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:116' for i = 1:numberOfContrasts
  result->f4.set_size(i);
  // 'reflectivity_calculation:119' result{4} = cell4;
  // 'reflectivity_calculation:121' cell5 = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:122' for i = 1:numberOfContrasts
  result->f5.set_size(i);
  // 'reflectivity_calculation:125' result{5} = cell5;
  // 'reflectivity_calculation:127' cell6 = cell(numberOfContrasts,1);
  // 'reflectivity_calculation:128' for i = 1:numberOfContrasts
  result->f6.set_size(i);
  for (b_i = 0; b_i < i; b_i++) {
    int b_loop_ub;
    int i2;
    int loop_ub;
    // 'reflectivity_calculation:99' cell1{i} = reflectivity{i};
    loop_ub = reflectivity[b_i].f1.size(0);
    result->f1[b_i].f1.set_size(reflectivity[b_i].f1.size(0), 2);
    // 'reflectivity_calculation:105' cell2{i} = Simulation{i};
    b_loop_ub = Simulation[b_i].f1.size(0);
    result->f2[b_i].f1.set_size(Simulation[b_i].f1.size(0), 2);
    for (i1 = 0; i1 < 2; i1++) {
      for (i2 = 0; i2 < loop_ub; i2++) {
        result->f1[b_i].f1[i2 + result->f1[b_i].f1.size(0) * i1] =
            reflectivity[b_i].f1[i2 + reflectivity[b_i].f1.size(0) * i1];
      }
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        result->f2[b_i].f1[i2 + result->f2[b_i].f1.size(0) * i1] =
            Simulation[b_i].f1[i2 + Simulation[b_i].f1.size(0) * i1];
      }
    }
    // 'reflectivity_calculation:111' cell3{i} = shifted_data{i};
    loop_ub = shifted_data[b_i].f1.size(0);
    result->f3[b_i].f1.set_size(shifted_data[b_i].f1.size(0), 3);
    // 'reflectivity_calculation:117' cell4{i} = layerSlds{i};
    b_loop_ub = layerSlds[b_i].f1.size(0);
    result->f4[b_i].f1.set_size(layerSlds[b_i].f1.size(0), 3);
    for (i1 = 0; i1 < 3; i1++) {
      for (i2 = 0; i2 < loop_ub; i2++) {
        result->f3[b_i].f1[i2 + result->f3[b_i].f1.size(0) * i1] =
            shifted_data[b_i].f1[i2 + shifted_data[b_i].f1.size(0) * i1];
      }
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        result->f4[b_i].f1[i2 + result->f4[b_i].f1.size(0) * i1] =
            layerSlds[b_i].f1[i2 + layerSlds[b_i].f1.size(0) * i1];
      }
    }
    // 'reflectivity_calculation:123' cell5{i} = sldProfiles{i};
    loop_ub = sldProfiles[b_i].f1.size(0);
    result->f5[b_i].f1.set_size(sldProfiles[b_i].f1.size(0), 2);
    for (i1 = 0; i1 < 2; i1++) {
      for (i2 = 0; i2 < loop_ub; i2++) {
        result->f5[b_i].f1[i2 + result->f5[b_i].f1.size(0) * i1] =
            sldProfiles[b_i].f1[i2 + sldProfiles[b_i].f1.size(0) * i1];
      }
    }
    // 'reflectivity_calculation:129' cell6{i} = allLayers{i};
    loop_ub = allLayers[b_i].f1.size(0);
    result->f6[b_i].f1.set_size(allLayers[b_i].f1.size(0), 3);
    for (i1 = 0; i1 < 3; i1++) {
      for (i2 = 0; i2 < loop_ub; i2++) {
        result->f6[b_i].f1[i2 + result->f6[b_i].f1.size(0) * i1] =
            allLayers[b_i].f1[i2 + allLayers[b_i].f1.size(0) * i1];
      }
    }
  }
  // 'reflectivity_calculation:131' result{6} = cell6;
  //  Pre-processor directives for Matlab Coder
  //  to define the size of the output array
  // 'reflectivity_calculation:135' coder.varsize('problem.ssubs',[Inf 1],[1
  // 0]); 'reflectivity_calculation:136'
  // coder.varsize('problem.backgrounds',[Inf 1],[1 0]);
  // 'reflectivity_calculation:137' coder.varsize('problem.qshifts',[Inf 1],[1
  // 0]); 'reflectivity_calculation:138'
  // coder.varsize('problem.scalefactors',[Inf 1],[1 0]);
  // 'reflectivity_calculation:139' coder.varsize('problem.nbairs',[Inf 1],[1
  // 0]); 'reflectivity_calculation:140' coder.varsize('problem.nbsubs',[Inf
  // 1],[1 0]); 'reflectivity_calculation:141'
  // coder.varsize('problem.resolutions',[Inf 1],[1 0]);
  // 'reflectivity_calculation:142' coder.varsize('problem.ssubs',[Inf 1],[1
  // 0]); 'reflectivity_calculation:143'
  // coder.varsize('problem.calculations.all_chis',[Inf 1],[1 0]);
  // 'reflectivity_calculation:144'
  // coder.varsize('problem.calculations.sum_chi',[1 1],[0 0]);
  // 'reflectivity_calculation:145' coder.varsize('problem.allSubRough',[Inf
  // 1],[1 0]); Result coder definitions.... 'reflectivity_calculation:148'
  // coder.varsize('result{1}',[Inf 1],[1 0]); Reflectivity
  // 'reflectivity_calculation:149' coder.varsize('result{1}{:}',[Inf 2],[1 0]);
  // 'reflectivity_calculation:151' coder.varsize('result{2}',[Inf 1],[1 0]);
  // Simulatin
  // 'reflectivity_calculation:152' coder.varsize('result{2}{:}',[Inf 2],[1 0]);
  // 'reflectivity_calculation:154' coder.varsize('result{3}',[Inf 1],[1 0]);
  // Shifted data
  // 'reflectivity_calculation:155' coder.varsize('result{3}{:}',[Inf 3],[1 0]);
  // 'reflectivity_calculation:157' coder.varsize('result{4}',[Inf 1],[1 0]);
  // Layers slds
  // 'reflectivity_calculation:158' coder.varsize('result{4}{:}',[Inf 3],[1 0]);
  // 'reflectivity_calculation:160' coder.varsize('result{5}',[Inf 1],[1 0]);
  // Sld profiles
  // 'reflectivity_calculation:161' coder.varsize('results{5}{:}',[Inf 2],[1
  // 0]); 'reflectivity_calculation:163' coder.varsize('result{6}',[Inf 1],[1
  // 0]); All layers (resampled) 'reflectivity_calculation:164'
  // coder.varsize('result{6}{:}',[Inf 3],[1 0]);
}

} // namespace RAT

// End of code generation (reflectivity_calculation.cpp)

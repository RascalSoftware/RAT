//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// reflectivity_calculation_internal_types.h
//
// Code generation for function 'reflectivity_calculation'
//

#ifndef REFLECTIVITY_CALCULATION_INTERNAL_TYPES_H
#define REFLECTIVITY_CALCULATION_INTERNAL_TYPES_H

// Include files
#include "reflectivity_calculation_types.h"
#include "rtwtypes.h"
#include "coder_array.h"

// Type Definitions
namespace RAT {
struct cell_wrap_17 {
  double f1[5];
};

struct cell_wrap_12 {
  ::coder::array<double, 2U> f1;
};

struct cell_16 {
  ::coder::array<cell_wrap_0, 2U> f1;
  ::coder::array<cell_wrap_14, 2U> f2;
  ::coder::array<cell_wrap_0, 2U> f3;
  ::coder::array<cell_wrap_14, 2U> f4;
  ::coder::array<cell_wrap_14, 2U> f5;
  ::coder::array<cell_wrap_14, 1U> f6;
  ::coder::array<cell_wrap_5, 2U> f7;
  ::coder::array<cell_wrap_6, 2U> f8;
  ::coder::array<cell_wrap_6, 2U> f9;
  ::coder::array<cell_wrap_6, 2U> f10;
  ::coder::array<cell_wrap_6, 2U> f11;
  ::coder::array<cell_wrap_6, 2U> f12;
  ::coder::array<cell_wrap_6, 2U> f13;
  ::coder::array<cell_wrap_7, 2U> f14;
};

struct struct_T {
  ::coder::array<double, 1U> ssubs;
  ::coder::array<double, 1U> backgrounds;
  ::coder::array<double, 1U> qshifts;
  ::coder::array<double, 1U> scalefactors;
  ::coder::array<double, 1U> nbairs;
  ::coder::array<double, 1U> nbsubs;
  ::coder::array<double, 1U> resolutions;
  struct5_T calculations;
  ::coder::array<double, 1U> allSubRough;
  ::coder::array<double, 2U> resample;
};

struct cell_wrap_32 {
  ::coder::array<double, 2U> f1;
};

struct cell_wrap_33 {
  ::coder::array<double, 2U> f1;
};

struct cell_21 {
  ::coder::array<double, 2U> f1;
};

} // namespace RAT

#endif
// End of code generation (reflectivity_calculation_internal_types.h)

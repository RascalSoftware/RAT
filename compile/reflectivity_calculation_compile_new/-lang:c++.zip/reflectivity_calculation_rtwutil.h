//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// reflectivity_calculation_rtwutil.h
//
// Code generation for function 'reflectivity_calculation_rtwutil'
//

#ifndef REFLECTIVITY_CALCULATION_RTWUTIL_H
#define REFLECTIVITY_CALCULATION_RTWUTIL_H

// Include files
#include "reflectivity_calculation_types.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT {
extern void cast(const ::coder::array<cell_wrap_31, 1U> &b,
                 ::coder::array<cell_wrap_14, 1U> &c);

extern double rt_hypotd_snf(double u0, double u1);

extern double rt_powd_snf(double u0, double u1);

} // namespace RAT

#endif
// End of code generation (reflectivity_calculation_rtwutil.h)

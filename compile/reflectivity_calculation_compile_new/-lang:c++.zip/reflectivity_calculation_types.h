//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// reflectivity_calculation_types.h
//
// Code generation for function 'reflectivity_calculation'
//

#ifndef REFLECTIVITY_CALCULATION_TYPES_H
#define REFLECTIVITY_CALCULATION_TYPES_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "coder_bounded_array.h"
#define MAX_THREADS omp_get_max_threads()

// Type Definitions
namespace RAT {
struct cell_wrap_0 {
  double f1[2];
};

struct struct0_T {
  ::coder::array<double, 2U> contrastBacks;
  ::coder::array<double, 2U> contrastBacksType;
  ::coder::array<char, 2U> TF;
  ::coder::array<double, 2U> resample;
  ::coder::array<double, 2U> dataPresent;
  double numberOfContrasts;
  ::coder::array<char, 2U> geometry;
  ::coder::array<double, 2U> contrastShifts;
  ::coder::array<double, 2U> contrastScales;
  ::coder::array<double, 2U> contrastNbas;
  ::coder::array<double, 2U> contrastNbss;
  ::coder::array<double, 2U> contrastRes;
  ::coder::array<double, 2U> backs;
  ::coder::array<double, 2U> shifts;
  ::coder::array<double, 2U> sf;
  ::coder::array<double, 2U> nba;
  ::coder::array<double, 2U> nbs;
  ::coder::array<double, 2U> res;
  ::coder::array<double, 2U> params;
  double numberOfLayers;
  ::coder::array<char, 2U> modelType;
  ::coder::array<double, 2U> contrastCustomFiles;
  ::coder::array<double, 2U> fitpars;
  ::coder::array<double, 2U> otherpars;
  ::coder::array<double, 2U> fitconstr;
  ::coder::array<double, 2U> otherconstr;
};

struct cell_wrap_1 {
  ::coder::array<double, 2U> f1;
};

struct cell_wrap_2 {
  ::coder::bounded_array<double, 2U, 2U> f1;
};

struct cell_wrap_3 {
  ::coder::array<double, 2U> f1;
};

struct cell_wrap_4 {
  ::coder::bounded_array<double, 10U, 2U> f1;
};

struct cell_wrap_5 {
  ::coder::array<char, 2U> f1;
};

struct cell_wrap_6 {
  ::coder::array<char, 2U> f1;
};

struct cell_wrap_7 {
  cell_wrap_6 f1[3];
};

struct cell_8 {
  ::coder::array<cell_wrap_0, 2U> f1;
  ::coder::array<cell_wrap_1, 2U> f2;
  ::coder::array<cell_wrap_0, 2U> f3;
  ::coder::array<cell_wrap_2, 2U> f4;
  ::coder::array<cell_wrap_3, 2U> f5;
  ::coder::array<cell_wrap_4, 1U> f6;
  ::coder::array<cell_wrap_5, 2U> f7;
  ::coder::array<cell_wrap_6, 2U> f8;
  ::coder::array<cell_wrap_6, 2U> f9;
  ::coder::array<cell_wrap_6, 2U> f10;
  ::coder::array<cell_wrap_6, 2U> f11;
  ::coder::array<cell_wrap_6, 2U> f12;
  ::coder::array<cell_wrap_6, 2U> f13;
  ::coder::array<cell_wrap_7, 2U> f14;
};

struct struct1_T {
  ::coder::array<double, 2U> params;
  ::coder::array<double, 2U> backs;
  ::coder::array<double, 2U> scales;
  ::coder::array<double, 2U> shifts;
  ::coder::array<double, 2U> nba;
  ::coder::array<double, 2U> nbs;
  ::coder::array<double, 2U> res;
};

struct struct3_T {
  ::coder::array<double, 2U> params_fitYesNo;
  ::coder::array<double, 2U> backs_fitYesNo;
  ::coder::array<double, 2U> shifts_fitYesNo;
  ::coder::array<double, 2U> scales_fitYesNo;
  ::coder::array<double, 2U> nbairs_fitYesNo;
  ::coder::array<double, 2U> nbsubs_fitYesNo;
  ::coder::array<double, 2U> resol_fitYesNo;
};

struct struct2_T {
  ::coder::array<char, 2U> para;
  ::coder::array<char, 2U> proc;
  ::coder::array<char, 2U> display;
  double tolX;
  double tolFun;
  double maxFunEvals;
  double maxIter;
  double populationSize;
  double F_weight;
  double F_CR;
  double VTR;
  double numGen;
  double strategy;
  double Nlive;
  double nmcmc;
  double propScale;
  double nsTolerance;
  double calcSld;
  double repeats;
  double nsimu;
  double burnin;
  double resamPars[2];
  double updateFreq;
  double updatePlotFreq;
  struct3_T checks;
};

struct struct5_T {
  ::coder::array<double, 1U> all_chis;
  double sum_chi;
};

struct struct4_T {
  ::coder::array<double, 1U> ssubs;
  ::coder::array<double, 1U> backgrounds;
  ::coder::array<double, 1U> qshifts;
  ::coder::array<double, 1U> scalefactors;
  ::coder::array<double, 1U> nbairs;
  ::coder::array<double, 1U> nbsubs;
  ::coder::array<double, 1U> resolutions;
  struct5_T calculations;
  ::coder::array<double, 1U> allSubRough;
  ::coder::array<double, 2U> resample;
};

struct cell_wrap_9 {
  ::coder::array<double, 2U> f1;
};

struct cell_wrap_10 {
  ::coder::array<double, 2U> f1;
};

struct cell_11 {
  ::coder::array<cell_wrap_9, 1U> f1;
  ::coder::array<cell_wrap_9, 1U> f2;
  ::coder::array<cell_wrap_10, 1U> f3;
  ::coder::array<cell_wrap_10, 1U> f4;
  ::coder::array<cell_wrap_9, 1U> f5;
  ::coder::array<cell_wrap_10, 1U> f6;
};

struct cell_wrap_14 {
  ::coder::array<double, 2U> f1;
};

struct cell_wrap_31 {
  ::coder::bounded_array<double, 5000U, 2U> f1;
};

} // namespace RAT

#endif
// End of code generation (reflectivity_calculation_types.h)

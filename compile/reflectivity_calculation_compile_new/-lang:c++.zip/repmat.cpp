//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// repmat.cpp
//
// Code generation for function 'repmat'
//

// Include files
#include "repmat.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
//
namespace RAT {
namespace coder {
void repmat(const double a[2], double varargin_1, ::coder::array<double, 2U> &b)
{
  b.set_size(static_cast<int>(varargin_1), 2);
  if (static_cast<int>(varargin_1) != 0) {
    int i;
    i = static_cast<int>(varargin_1) - 1;
    for (int k{0}; k < 2; k++) {
      for (int t{0}; t <= i; t++) {
        b[t + b.size(0) * k] = a[k];
      }
    }
  }
}

} // namespace coder
} // namespace RAT

// End of code generation (repmat.cpp)

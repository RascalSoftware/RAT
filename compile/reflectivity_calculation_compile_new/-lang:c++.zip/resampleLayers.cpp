//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// resampleLayers.cpp
//
// Code generation for function 'resampleLayers'
//

// Include files
#include "resampleLayers.h"
#include "adaptive_new.h"
#include "length.h"
#include "reflectivity_calculation_internal_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function newSLD = resampleLayers_new(sldProfile,resamPars)
namespace RAT {
void resampleLayers(const ::coder::array<double, 2U> &sldProfile,
                    const double resamPars[2],
                    ::coder::array<double, 2U> &newSLD)
{
  cell_21 expl_temp;
  double b_sldProfile[2];
  int i;
  int n;
  //  Function handle for adaptive resampling
  //  f = @(x) sldFunc(x);
  //
  // 'resampleLayers:8' x = sldProfile(:,1);
  // 'resampleLayers:9' prof = sldProfile(:,2);
  // 'resampleLayers:11' xstart = x(1);
  // 'resampleLayers:12' xend = x(end);
  //  Keep points and minangle as constants for now
  //  will fix later
  // 'resampleLayers:16' minAngle = resamPars(1);
  // 'resampleLayers:17' nPoints = resamPars(2);
  // 'resampleLayers:19' newX = linspace(xstart,xend,100);
  // 'resampleLayers:20' out = adaptive_new(sldProfile, [xstart xend],
  // minAngle*pi, nPoints);
  b_sldProfile[0] = sldProfile[0];
  b_sldProfile[1] = sldProfile[sldProfile.size(0) - 1];
  adaptive_new(sldProfile, b_sldProfile, resamPars[0] * 3.1415926535897931,
               resamPars[1], &expl_temp);
  // 'resampleLayers:21' yy = out{1};
  // 'resampleLayers:23' newX = yy(:,1);
  // 'resampleLayers:24' newY = yy(:,2);
  // 'resampleLayers:25' layers = zeros(length(newX)-1,3);
  n = coder::internal::intlength(expl_temp.f1.size(0), 1);
  newSLD.set_size(n - 1, 3);
  n--;
  for (i = 0; i < 3; i++) {
    for (int i1{0}; i1 < n; i1++) {
      newSLD[i1 + newSLD.size(0) * i] = 0.0;
    }
  }
  //  Now build a layer model from these resampled points
  // 'resampleLayers:28' for n = 1:length(newX)-1
  i = coder::internal::intlength(expl_temp.f1.size(0), 1);
  for (n = 0; n <= i - 2; n++) {
    double d;
    double d1;
    double thisLayRho;
    // 'resampleLayers:29' thisX = newX(n);
    // 'resampleLayers:30' nextX = newX(n+1);
    // 'resampleLayers:31' thisY = newY(n);
    // 'resampleLayers:32' nextY = newY(n+1);
    // 'resampleLayers:34' thisLayThick = nextX - thisX;
    // 'resampleLayers:35' if nextY > thisY
    d = expl_temp.f1[(n + expl_temp.f1.size(0)) + 1];
    d1 = expl_temp.f1[n + expl_temp.f1.size(0)];
    if (d > d1) {
      // 'resampleLayers:36' thisLayRho = ((nextY - thisY)/2) + thisY;
      thisLayRho = (d - d1) / 2.0 + d1;
    } else {
      // 'resampleLayers:37' else
      // 'resampleLayers:38' thisLayRho = ((thisY - nextY)/2) + nextY;
      thisLayRho = (d1 - d) / 2.0 + d;
    }
    // 'resampleLayers:41' layers(n,:) = [thisLayThick thisLayRho eps];
    newSLD[n] = expl_temp.f1[n + 1] - expl_temp.f1[n];
    newSLD[n + newSLD.size(0)] = thisLayRho;
    newSLD[n + newSLD.size(0) * 2] = 2.2204460492503131E-16;
  }
  // 'resampleLayers:43' newSLD = layers;
}

//
// function newSLD = resampleLayers_new(sldProfile,resamPars)
void resampleLayers(const double sldProfile_data[],
                    const int sldProfile_size[2], const double resamPars[2],
                    ::coder::array<double, 2U> &newSLD)
{
  cell_21 expl_temp;
  double sldProfile[2];
  int i;
  int n;
  //  Function handle for adaptive resampling
  //  f = @(x) sldFunc(x);
  //
  // 'resampleLayers:8' x = sldProfile(:,1);
  // 'resampleLayers:9' prof = sldProfile(:,2);
  // 'resampleLayers:11' xstart = x(1);
  // 'resampleLayers:12' xend = x(end);
  //  Keep points and minangle as constants for now
  //  will fix later
  // 'resampleLayers:16' minAngle = resamPars(1);
  // 'resampleLayers:17' nPoints = resamPars(2);
  // 'resampleLayers:19' newX = linspace(xstart,xend,100);
  // 'resampleLayers:20' out = adaptive_new(sldProfile, [xstart xend],
  // minAngle*pi, nPoints);
  sldProfile[0] = sldProfile_data[0];
  sldProfile[1] = sldProfile_data[sldProfile_size[0] - 1];
  adaptive_new(sldProfile_data, sldProfile_size, sldProfile,
               resamPars[0] * 3.1415926535897931, resamPars[1], &expl_temp);
  // 'resampleLayers:21' yy = out{1};
  // 'resampleLayers:23' newX = yy(:,1);
  // 'resampleLayers:24' newY = yy(:,2);
  // 'resampleLayers:25' layers = zeros(length(newX)-1,3);
  n = coder::internal::intlength(expl_temp.f1.size(0), 1);
  newSLD.set_size(n - 1, 3);
  n--;
  for (i = 0; i < 3; i++) {
    for (int i1{0}; i1 < n; i1++) {
      newSLD[i1 + newSLD.size(0) * i] = 0.0;
    }
  }
  //  Now build a layer model from these resampled points
  // 'resampleLayers:28' for n = 1:length(newX)-1
  i = coder::internal::intlength(expl_temp.f1.size(0), 1);
  for (n = 0; n <= i - 2; n++) {
    double d;
    double d1;
    double thisLayRho;
    // 'resampleLayers:29' thisX = newX(n);
    // 'resampleLayers:30' nextX = newX(n+1);
    // 'resampleLayers:31' thisY = newY(n);
    // 'resampleLayers:32' nextY = newY(n+1);
    // 'resampleLayers:34' thisLayThick = nextX - thisX;
    // 'resampleLayers:35' if nextY > thisY
    d = expl_temp.f1[(n + expl_temp.f1.size(0)) + 1];
    d1 = expl_temp.f1[n + expl_temp.f1.size(0)];
    if (d > d1) {
      // 'resampleLayers:36' thisLayRho = ((nextY - thisY)/2) + thisY;
      thisLayRho = (d - d1) / 2.0 + d1;
    } else {
      // 'resampleLayers:37' else
      // 'resampleLayers:38' thisLayRho = ((thisY - nextY)/2) + nextY;
      thisLayRho = (d1 - d) / 2.0 + d;
    }
    // 'resampleLayers:41' layers(n,:) = [thisLayThick thisLayRho eps];
    newSLD[n] = expl_temp.f1[n + 1] - expl_temp.f1[n];
    newSLD[n + newSLD.size(0)] = thisLayRho;
    newSLD[n + newSLD.size(0) * 2] = 2.2204460492503131E-16;
  }
  // 'resampleLayers:43' newSLD = layers;
}

} // namespace RAT

// End of code generation (resampleLayers.cpp)

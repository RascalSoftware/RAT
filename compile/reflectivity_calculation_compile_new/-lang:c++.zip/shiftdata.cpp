//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// shiftdata.cpp
//
// Code generation for function 'shiftdata'
//

// Include files
#include "shiftdata.h"
#include "find.h"
#include "linspace.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
//
// function shifted_data =
// shiftdata(scalefac,horshift,dataPresent,data,dataLimits,simLimits)
namespace RAT {
void shiftdata(double scalefac, double horshift, double dataPresent,
               ::coder::array<double, 2U> &data, const double dataLimits[2],
               const double simLimits_data[],
               ::coder::array<double, 2U> &shifted_data)
{
  ::coder::array<double, 1U> c_data;
  ::coder::array<int, 1U> lowIndex;
  ::coder::array<boolean_T, 1U> d_data;
  double dv1[3][100];
  double dv[100];
  //  Shifts the data according to scale factor. If there is no data, makes
  //  x-data over the simulation range.
  //
  //  INPUTS:
  //
  //      * scalefac = problem.scalefactors;
  //      * horshift = problem.qshifts;
  //      * numberOfContrasts = problem.numberOfContrasts;
  //      * dataPresent = problem.dataPresent;
  //      * allData = problem.data;
  //      * dataLimits = problem.dataLimits;
  // 'shiftdata:15' switch dataPresent
  switch (static_cast<int>(dataPresent)) {
  case 1: {
    int b_data;
    int b_lowIndex;
    int hiIndex;
    int i;
    int i1;
    int loop_ub;
    // 'shiftdata:16' case 1
    // 'shiftdata:17' if scalefac == 0
    if (scalefac == 0.0) {
      // 'shiftdata:18' scalefac = 1e-30;
      scalefac = 1.0E-30;
    }
    // 'shiftdata:20' data(:,1) = data(:,1) + horshift;
    b_data = data.size(0) - 1;
    c_data.set_size(data.size(0));
    for (i = 0; i <= b_data; i++) {
      c_data[i] = data[i] + horshift;
    }
    loop_ub = c_data.size(0);
    for (i = 0; i < loop_ub; i++) {
      data[i] = c_data[i];
    }
    // 'shiftdata:21' data(:,2) = data(:,2) ./ scalefac;
    b_data = data.size(0) - 1;
    c_data.set_size(data.size(0));
    for (i = 0; i <= b_data; i++) {
      c_data[i] = data[i + data.size(0)] / scalefac;
    }
    loop_ub = c_data.size(0);
    for (i = 0; i < loop_ub; i++) {
      data[i + data.size(0)] = c_data[i];
    }
    // 'shiftdata:22' data(:,3) = data(:,3) ./ scalefac;
    b_data = data.size(0) - 1;
    c_data.set_size(data.size(0));
    for (i = 0; i <= b_data; i++) {
      c_data[i] = data[i + data.size(0) * 2] / scalefac;
    }
    loop_ub = c_data.size(0);
    for (i = 0; i < loop_ub; i++) {
      data[i + data.size(0) * 2] = c_data[i];
    }
    // 'shiftdata:24' lowLimit = dataLimits(1);
    // 'shiftdata:25' hiLimit = dataLimits(2);
    // 'shiftdata:27' lowIndex = find(data(:,1) < lowLimit);
    loop_ub = data.size(0);
    d_data.set_size(data.size(0));
    for (i = 0; i < loop_ub; i++) {
      d_data[i] = (data[i] < dataLimits[0]);
    }
    coder::eml_find(d_data, lowIndex);
    // 'shiftdata:28' if ~isempty(lowIndex)
    if (lowIndex.size(0) != 0) {
      // 'shiftdata:29' lowIndex = lowIndex(end);
      b_lowIndex = lowIndex[lowIndex.size(0) - 1];
    } else {
      // 'shiftdata:30' else
      // 'shiftdata:31' lowIndex = 1;
      b_lowIndex = 1;
    }
    // 'shiftdata:34' hiIndex = find(data(:,1) > hiLimit);
    loop_ub = data.size(0);
    d_data.set_size(data.size(0));
    for (i = 0; i < loop_ub; i++) {
      d_data[i] = (data[i] > dataLimits[1]);
    }
    coder::eml_find(d_data, lowIndex);
    // 'shiftdata:35' if  ~isempty(hiIndex)
    if (lowIndex.size(0) != 0) {
      // 'shiftdata:36' hiIndex = hiIndex(1);
      hiIndex = lowIndex[0];
    } else {
      // 'shiftdata:37' else
      // 'shiftdata:38' hiIndex = length(data(:,1));
      hiIndex = data.size(0);
    }
    // 'shiftdata:41' shifted_data = data(lowIndex:hiIndex,:);
    if (b_lowIndex > hiIndex) {
      i = 0;
      i1 = 0;
    } else {
      i = b_lowIndex - 1;
      i1 = hiIndex;
    }
    loop_ub = data.size(1);
    b_data = i1 - i;
    shifted_data.set_size(b_data, data.size(1));
    for (i1 = 0; i1 < loop_ub; i1++) {
      for (int i2{0}; i2 < b_data; i2++) {
        shifted_data[i2 + shifted_data.size(0) * i1] =
            data[(i + i2) + data.size(0) * i1];
      }
    }
  } break;
  default: {
    int i;
    // 'shiftdata:42' otherwise
    // 'shiftdata:43' simPoints = 100;
    // 'shiftdata:44' simLo = simLimits(1);
    // 'shiftdata:45' simHi = simLimits(2);
    // 'shiftdata:46' simXData = linspace(simLo,simHi,simPoints);
    // 'shiftdata:47' simYData = zeros(length(simXData),1);
    // 'shiftdata:48' shifted_data = [simXData(:) simYData(:) simYData(:)];
    coder::linspace(simLimits_data[0], simLimits_data[1], dv);
    for (i = 0; i < 100; i++) {
      dv1[0][i] = dv[i];
      dv1[1][i] = 0.0;
      dv1[2][i] = 0.0;
    }
    shifted_data.set_size(100, 3);
    for (i = 0; i < 3; i++) {
      for (int i1{0}; i1 < 100; i1++) {
        shifted_data[i1 + shifted_data.size(0) * i] = dv1[i][i1];
      }
    }
  } break;
  }
}

} // namespace RAT

// End of code generation (shiftdata.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// shiftdata.cpp
//
// Code generation for function 'shiftdata'
//

// Include files
#include "shiftdata.h"
#include "find.h"
#include "linspace.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <algorithm>

// Function Definitions
namespace RAT
{
  void shiftdata(real_T scalefac, real_T horshift, real_T dataPresent, real_T
                 data_data[], const int32_T data_size[2], const real_T
                 dataLimits[2], const real_T simLimits_data[], real_T
                 shifted_data_data[], int32_T shifted_data_size[2])
  {
    ::coder::array<int32_T, 1U> b_i;
    ::coder::array<boolean_T, 1U> c_data_data;
    ::coder::array<boolean_T, 1U> e_data_data;
    real_T b_data_data[1000];
    real_T dv1[3][100];
    real_T dv[100];
    boolean_T d_data_data[1000];

    //  Shifts the data according to scale factor. If there is no data, makes
    //  x-data over the simulation range.
    //
    //  INPUTS:
    //
    //      * scalefac = problem.scalefactors;
    //      * horshift = problem.qshifts;
    //      * numberOfContrasts = problem.numberOfContrasts;
    //      * dataPresent = problem.dataPresent;
    //      * allData = problem.data;
    //      * dataLimits = problem.dataLimits;
    switch (static_cast<int32_T>(dataPresent)) {
     case 1:
      {
        int32_T b_data_size;
        int32_T data_tmp;
        int32_T hiIndex;
        int32_T i;
        int32_T i1;
        int32_T lowIndex;
        if (scalefac == 0.0) {
          scalefac = 1.0E-30;
        }

        data_tmp = data_size[0] - 1;
        b_data_size = data_size[0];
        for (i = 0; i <= data_tmp; i++) {
          b_data_data[i] = data_data[i] + horshift;
        }

        if (0 <= b_data_size - 1) {
          std::copy(&b_data_data[0], &b_data_data[b_data_size], &data_data[0]);
        }

        b_data_size = data_size[0];
        for (i = 0; i <= data_tmp; i++) {
          b_data_data[i] = data_data[i + data_size[0]] / scalefac;
        }

        for (i = 0; i < b_data_size; i++) {
          data_data[i + data_size[0]] = b_data_data[i];
        }

        b_data_size = data_size[0];
        for (i = 0; i <= data_tmp; i++) {
          b_data_data[i] = data_data[i + data_size[0] * 2] / scalefac;
        }

        for (i = 0; i < b_data_size; i++) {
          data_data[i + data_size[0] * 2] = b_data_data[i];
        }

        b_data_size = data_size[0];
        for (i = 0; i < b_data_size; i++) {
          d_data_data[i] = (data_data[i] < dataLimits[0]);
        }

        c_data_data.set(&d_data_data[0], data_size[0]);
        coder::eml_find(c_data_data, b_i);
        if (b_i.size(0) != 0) {
          lowIndex = b_i[b_i.size(0) - 1];
        } else {
          lowIndex = 1;
        }

        b_data_size = data_size[0];
        for (i = 0; i < b_data_size; i++) {
          d_data_data[i] = (data_data[i] > dataLimits[1]);
        }

        e_data_data.set(&d_data_data[0], data_size[0]);
        coder::eml_find(e_data_data, b_i);
        if (b_i.size(0) != 0) {
          hiIndex = b_i[0];
        } else {
          hiIndex = data_size[0];
        }

        if (lowIndex > hiIndex) {
          i = 0;
          i1 = 0;
        } else {
          i = lowIndex - 1;
          i1 = hiIndex;
        }

        b_data_size = data_size[1];
        data_tmp = i1 - i;
        shifted_data_size[0] = data_tmp;
        shifted_data_size[1] = data_size[1];
        for (i1 = 0; i1 < b_data_size; i1++) {
          for (int32_T i2{0}; i2 < data_tmp; i2++) {
            shifted_data_data[i2 + data_tmp * i1] = data_data[(i + i2) +
              data_size[0] * i1];
          }
        }
      }
      break;

     default:
      {
        int32_T i;
        coder::linspace(simLimits_data[0], simLimits_data[1], dv);
        for (i = 0; i < 100; i++) {
          dv1[0][i] = dv[i];
          dv1[1][i] = 0.0;
          dv1[2][i] = 0.0;
        }

        shifted_data_size[0] = 100;
        shifted_data_size[1] = 3;
        for (i = 0; i < 3; i++) {
          for (int32_T i1{0}; i1 < 100; i1++) {
            shifted_data_data[i1 + 100 * i] = dv1[i][i1];
          }
        }
      }
      break;
    }
  }
}

// End of code generation (shiftdata.cpp)

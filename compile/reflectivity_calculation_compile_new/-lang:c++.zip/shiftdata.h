//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// shiftdata.h
//
// Code generation for function 'shiftdata'
//
#ifndef SHIFTDATA_H
#define SHIFTDATA_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  void shiftdata(real_T scalefac, real_T horshift, real_T dataPresent, real_T
                 data_data[], const int32_T data_size[2], const real_T
                 dataLimits[2], const real_T simLimits_data[], real_T
                 shifted_data_data[], int32_T shifted_data_size[2]);
}

#endif

// End of code generation (shiftdata.h)

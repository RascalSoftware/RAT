//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// sldFunc.cpp
//
// Code generation for function 'sldFunc'
//

// Include files
#include "sldFunc.h"
#include "find.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// function sldVal = sldFunc(x,SLD)
namespace RAT {
void sldFunc(double x, const ::coder::array<double, 2U> &SLD,
             ::coder::array<double, 1U> &sldVal)
{
  ::coder::array<int, 1U> belowVals;
  ::coder::array<int, 1U> where;
  ::coder::array<boolean_T, 1U> b_SLD;
  int i;
  int loop_ub;
  //  sldVal = sldFunc(x,SLD)
  //  SLD = [x rho;....xn rho]
  //    x = value in Angstrom.
  //
  //  This function returns the SLD (y) value associated with the
  //  supplied value of x. SLD is a two column, XY array defining an
  //  SLD profile. This function interpolates the SLD profile
  //  to return the SLD at the specific value of X. X can be a vector of
  //  multiple points.
  //
  //  (c) Arwel Hughes 2019.
  //  Last modified - AVH, 26/11/19.
  //  global sldProfile
  //
  //  SLD = sldProfile;
  // SLD = getappdata(0,'sldFuncSLD');
  // 'sldFunc:21' z = SLD(:,1);
  // 'sldFunc:22' rho = SLD(:,2);
  // 'sldFunc:24' where = find(z == x);
  loop_ub = SLD.size(0);
  b_SLD.set_size(SLD.size(0));
  for (i = 0; i < loop_ub; i++) {
    b_SLD[i] = (SLD[i] == x);
  }
  coder::eml_find(b_SLD, where);
  // 'sldFunc:26' if ~isempty(where)
  if (where.size(0) != 0) {
    // 'sldFunc:27' sldVal = rho(where);
    sldVal.set_size(where.size(0));
    loop_ub = where.size(0);
    for (i = 0; i < loop_ub; i++) {
      sldVal[i] = SLD[(where[i] + SLD.size(0)) - 1];
    }
  } else {
    double deltaY;
    double deltaY_tmp;
    // 'sldFunc:28' else
    // 'sldFunc:29' belowVals = find(x > z);
    loop_ub = SLD.size(0);
    b_SLD.set_size(SLD.size(0));
    for (i = 0; i < loop_ub; i++) {
      b_SLD[i] = (x > SLD[i]);
    }
    coder::eml_find(b_SLD, where);
    belowVals.set_size(where.size(0));
    loop_ub = where.size(0);
    for (i = 0; i < loop_ub; i++) {
      belowVals[i] = where[i];
    }
    // 'sldFunc:30' aboveVals = find(x < z);
    loop_ub = SLD.size(0);
    b_SLD.set_size(SLD.size(0));
    for (i = 0; i < loop_ub; i++) {
      b_SLD[i] = (x < SLD[i]);
    }
    coder::eml_find(b_SLD, where);
    // 'sldFunc:31' below = belowVals(end);
    // 'sldFunc:32' above = aboveVals(1);
    // 'sldFunc:34' belowY = rho(below);
    // 'sldFunc:35' aboveY = rho(above);
    // 'sldFunc:37' yDiff = abs(aboveY-belowY);
    // 'sldFunc:38' xDiff = z(above) - z(below);
    // 'sldFunc:40' tanTheta = yDiff/xDiff;
    // 'sldFunc:42' deltaX = x - z(below);
    // 'sldFunc:43' deltaY = deltaX * tanTheta;
    deltaY_tmp = SLD[(where[0] + SLD.size(0)) - 1];
    deltaY =
        (x - SLD[belowVals[belowVals.size(0) - 1] - 1]) *
        (std::abs(deltaY_tmp -
                  SLD[(belowVals[belowVals.size(0) - 1] + SLD.size(0)) - 1]) /
         (SLD[where[0] - 1] - SLD[belowVals[belowVals.size(0) - 1] - 1]));
    // 'sldFunc:45' if belowY < aboveY
    if (SLD[(belowVals[belowVals.size(0) - 1] + SLD.size(0)) - 1] <
        deltaY_tmp) {
      // 'sldFunc:46' sldVal = belowY + deltaY;
      sldVal.set_size(1);
      sldVal[0] =
          SLD[(belowVals[belowVals.size(0) - 1] + SLD.size(0)) - 1] + deltaY;
    } else {
      // 'sldFunc:47' else
      // 'sldFunc:48' sldVal = belowY - deltaY;
      sldVal.set_size(1);
      sldVal[0] =
          SLD[(belowVals[belowVals.size(0) - 1] + SLD.size(0)) - 1] - deltaY;
    }
    // sldVal = interp1(z,rho,x);
  }
}

//
// function sldVal = sldFunc(x,SLD)
void sldFunc(double x, const double SLD_data[], const int SLD_size[2],
             double sldVal_data[], int *sldVal_size)
{
  ::coder::array<int, 1U> b_i;
  ::coder::array<int, 1U> c_i;
  ::coder::array<int, 1U> r;
  ::coder::array<boolean_T, 1U> b_SLD_data;
  ::coder::array<boolean_T, 1U> d_SLD_data;
  ::coder::array<boolean_T, 1U> e_SLD_data;
  ::coder::array<boolean_T, 1U> f_SLD_data;
  ::coder::array<boolean_T, 1U> g_SLD_data;
  int aboveVals_data[2];
  int belowVals_data[2];
  int i;
  int loop_ub;
  boolean_T c_SLD_data[2];
  //  sldVal = sldFunc(x,SLD)
  //  SLD = [x rho;....xn rho]
  //    x = value in Angstrom.
  //
  //  This function returns the SLD (y) value associated with the
  //  supplied value of x. SLD is a two column, XY array defining an
  //  SLD profile. This function interpolates the SLD profile
  //  to return the SLD at the specific value of X. X can be a vector of
  //  multiple points.
  //
  //  (c) Arwel Hughes 2019.
  //  Last modified - AVH, 26/11/19.
  //  global sldProfile
  //
  //  SLD = sldProfile;
  // SLD = getappdata(0,'sldFuncSLD');
  // 'sldFunc:21' z = SLD(:,1);
  // 'sldFunc:22' rho = SLD(:,2);
  // 'sldFunc:24' where = find(z == x);
  loop_ub = SLD_size[0];
  for (i = 0; i < loop_ub; i++) {
    c_SLD_data[i] = (SLD_data[i] == x);
  }
  b_SLD_data.set(&c_SLD_data[0], SLD_size[0]);
  coder::eml_find(b_SLD_data, r);
  b_i.set_size(r.size(0));
  loop_ub = r.size(0);
  for (i = 0; i < loop_ub; i++) {
    b_i[i] = r[i];
  }
  // 'sldFunc:26' if ~isempty(where)
  if (b_i.size(0) != 0) {
    // 'sldFunc:27' sldVal = rho(where);
    *sldVal_size = b_i.size(0);
    loop_ub = b_i.size(0);
    for (i = 0; i < loop_ub; i++) {
      sldVal_data[i] = SLD_data[(b_i[i] + SLD_size[0]) - 1];
    }
  } else {
    double deltaY;
    int belowVals_size;
    // 'sldFunc:28' else
    // 'sldFunc:29' belowVals = find(x > z);
    loop_ub = SLD_size[0];
    for (i = 0; i < loop_ub; i++) {
      c_SLD_data[i] = (x > SLD_data[i]);
    }
    d_SLD_data.set(&c_SLD_data[0], SLD_size[0]);
    coder::eml_find(d_SLD_data, r);
    b_i.set_size(r.size(0));
    loop_ub = r.size(0);
    for (i = 0; i < loop_ub; i++) {
      b_i[i] = r[i];
    }
    loop_ub = SLD_size[0];
    for (i = 0; i < loop_ub; i++) {
      c_SLD_data[i] = (x > SLD_data[i]);
    }
    e_SLD_data.set(&c_SLD_data[0], SLD_size[0]);
    coder::eml_find(e_SLD_data, r);
    belowVals_size = r.size(0);
    loop_ub = r.size(0);
    for (i = 0; i < loop_ub; i++) {
      belowVals_data[i] = r[i];
    }
    // 'sldFunc:30' aboveVals = find(x < z);
    loop_ub = SLD_size[0];
    for (i = 0; i < loop_ub; i++) {
      c_SLD_data[i] = (x < SLD_data[i]);
    }
    f_SLD_data.set(&c_SLD_data[0], SLD_size[0]);
    coder::eml_find(f_SLD_data, r);
    c_i.set_size(r.size(0));
    loop_ub = r.size(0);
    for (i = 0; i < loop_ub; i++) {
      c_i[i] = r[i];
    }
    loop_ub = SLD_size[0];
    for (i = 0; i < loop_ub; i++) {
      c_SLD_data[i] = (x < SLD_data[i]);
    }
    g_SLD_data.set(&c_SLD_data[0], SLD_size[0]);
    coder::eml_find(g_SLD_data, r);
    loop_ub = r.size(0);
    for (i = 0; i < loop_ub; i++) {
      aboveVals_data[i] = r[i];
    }
    // 'sldFunc:31' below = belowVals(end);
    // 'sldFunc:32' above = aboveVals(1);
    // 'sldFunc:34' belowY = rho(below);
    // 'sldFunc:35' aboveY = rho(above);
    // 'sldFunc:37' yDiff = abs(aboveY-belowY);
    // 'sldFunc:38' xDiff = z(above) - z(below);
    // 'sldFunc:40' tanTheta = yDiff/xDiff;
    // 'sldFunc:42' deltaX = x - z(below);
    // 'sldFunc:43' deltaY = deltaX * tanTheta;
    belowVals_size = belowVals_data[belowVals_size - 1];
    deltaY = (x - SLD_data[b_i[b_i.size(0) - 1] - 1]) *
             (std::abs(SLD_data[(aboveVals_data[0] + SLD_size[0]) - 1] -
                       SLD_data[(belowVals_size + SLD_size[0]) - 1]) /
              (SLD_data[aboveVals_data[0] - 1] - SLD_data[belowVals_size - 1]));
    // 'sldFunc:45' if belowY < aboveY
    if (SLD_data[(b_i[b_i.size(0) - 1] + SLD_size[0]) - 1] <
        SLD_data[(c_i[0] + SLD_size[0]) - 1]) {
      // 'sldFunc:46' sldVal = belowY + deltaY;
      *sldVal_size = 1;
      sldVal_data[0] = deltaY;
    } else {
      // 'sldFunc:47' else
      // 'sldFunc:48' sldVal = belowY - deltaY;
      *sldVal_size = 1;
      sldVal_data[0] =
          SLD_data[(b_i[b_i.size(0) - 1] + SLD_size[0]) - 1] - deltaY;
    }
    // sldVal = interp1(z,rho,x);
  }
}

} // namespace RAT

// End of code generation (sldFunc.cpp)

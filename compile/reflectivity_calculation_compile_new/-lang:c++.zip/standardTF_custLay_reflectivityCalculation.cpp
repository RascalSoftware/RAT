//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custLay_reflectivityCalculation.cpp
//
// Code generation for function 'standardTF_custLay_reflectivityCalculation'
//

// Include files
#include "standardTF_custLay_reflectivityCalculation.h"
#include "blockedSummation.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_rtwutil.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_custlay_paraContrasts.h"
#include "standardTF_custlay_paraPoints.h"
#include "standardTF_custlay_single.h"
#include "strcmp.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Function Definitions
namespace RAT
{
  void standardTF_custLay_reflectivityCalculation(const struct0_T *problemDef,
    const cell_18 *problemDef_cells, const struct2_T *controls, struct_T
    *problem, ::coder::array<cell_wrap_9, 1U> &reflectivity, ::coder::array<
    cell_wrap_9, 1U> &Simulation, ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds, ::coder::array<cell_wrap_14, 1U>
    &sldProfiles, ::coder::array<cell_wrap_14, 1U> &allLayers)
  {
    ::coder::array<cell_wrap_1, 1U> r;
    real_T y;
    int32_T i;
    int32_T loop_ub_tmp;

    //  Custom layers reflectivity calculation for standardTF
    //  This function decides on parallelisation options before calling the
    //  relevant version of the main custom layers calculation. It is more
    //  efficient to have multiple versions of the core calculation, each dealing
    //  with a different scheme for paralellisation. These are:
    //  single    - single threaded teflectivity calculation
    //  points    - parallelise over points in the reflectivity calculation
    //  contrasts - parallelise over contrasts.
    //  Pre-allocation - It's necessary to
    //  pre-allocate the memory for all the arrays
    //  for compilation, so do this in this block.
    loop_ub_tmp = static_cast<int32_T>(problemDef->numberOfContrasts);
    problem->ssubs.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->ssubs[i] = 0.0;
    }

    problem->backgrounds.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->backgrounds[i] = 0.0;
    }

    problem->qshifts.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->qshifts[i] = 0.0;
    }

    problem->scalefactors.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->scalefactors[i] = 0.0;
    }

    problem->nbairs.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->nbairs[i] = 0.0;
    }

    problem->nbsubs.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->nbsubs[i] = 0.0;
    }

    problem->calculations.all_chis.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->calculations.all_chis[i] = 0.0;
    }

    problem->resolutions.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->resolutions[i] = 0.0;
    }

    problem->allSubRough.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->allSubRough[i] = 0.0;
    }

    reflectivity.set_size(loop_ub_tmp);
    Simulation.set_size(loop_ub_tmp);
    shifted_data.set_size(loop_ub_tmp);
    layerSlds.set_size(loop_ub_tmp);
    sldProfiles.set_size(loop_ub_tmp);
    allLayers.set_size(loop_ub_tmp);
    for (int32_T b_i{0}; b_i < loop_ub_tmp; b_i++) {
      reflectivity[b_i].f1.set_size(2, 2);
      reflectivity[b_i].f1[0] = 1.0;
      reflectivity[b_i].f1[1] = 1.0;
      reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
      reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
      Simulation[b_i].f1.set_size(2, 2);
      Simulation[b_i].f1[0] = 1.0;
      Simulation[b_i].f1[1] = 1.0;
      Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
      Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
      shifted_data[b_i].f1.set_size(2, 3);
      layerSlds[b_i].f1.set_size(2, 3);
      sldProfiles[b_i].f1.set_size(2, 2);
      sldProfiles[b_i].f1[0] = 1.0;
      sldProfiles[b_i].f1[1] = 1.0;
      sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
      sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
      allLayers[b_i].f1.set_size(2, 3);
      for (i = 0; i < 3; i++) {
        shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i] = 1.0;
        shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i + 1] = 1.0;
        layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i] = 1.0;
        layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i + 1] = 1.0;
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i] = 1.0;
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i + 1] = 1.0;
      }
    }

    //  End pre-allocation
    if (coder::internal::f_strcmp(controls->para.data, controls->para.size)) {
      loop_ub_tmp = 0;
    } else if (coder::internal::g_strcmp(controls->para.data,
                controls->para.size)) {
      loop_ub_tmp = 1;
    } else if (coder::internal::h_strcmp(controls->para.data,
                controls->para.size)) {
      loop_ub_tmp = 2;
    } else {
      loop_ub_tmp = -1;
    }

    switch (loop_ub_tmp) {
     case 0:
      standardTF_custlay_single(problemDef, problemDef_cells, controls,
        problem->ssubs, problem->backgrounds, problem->qshifts,
        problem->scalefactors, problem->nbairs, problem->nbsubs,
        problem->resolutions, problem->calculations.all_chis, reflectivity,
        Simulation, shifted_data, layerSlds, sldProfiles, allLayers,
        problem->allSubRough);
      break;

     case 1:
      standardTF_custlay_paraPoints(problemDef, problemDef_cells, controls,
        problem->ssubs, problem->backgrounds, problem->qshifts,
        problem->scalefactors, problem->nbairs, problem->nbsubs,
        problem->resolutions, problem->calculations.all_chis, reflectivity,
        Simulation, shifted_data, layerSlds, sldProfiles, allLayers,
        problem->allSubRough);
      break;

     case 2:
      standardTF_custlay_paraContrasts(problemDef, problemDef_cells, controls,
        problem->ssubs, problem->backgrounds, problem->qshifts,
        problem->scalefactors, problem->nbairs, problem->nbsubs,
        problem->resolutions, problem->calculations.all_chis, reflectivity,
        Simulation, shifted_data, layerSlds, sldProfiles, r,
        problem->allSubRough);
      cast(r, allLayers);

      //            [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
      //               Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
      //               allRoughs] = dev_custlay_paraContrasts(problemDef,problemDef_cells,...
      //               problemDef_limits,controls);
      break;
    }

    if (problem->calculations.all_chis.size(0) == 0) {
      y = 0.0;
    } else {
      y = coder::nestedIter(problem->calculations.all_chis,
                            problem->calculations.all_chis.size(0));
    }

    problem->calculations.sum_chi = y;
    problem->resample.set_size(1, problemDef->resample.size[1]);
    loop_ub_tmp = problemDef->resample.size[1];
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->resample[i] = problemDef->resample.data[i];
    }
  }
}

// End of code generation (standardTF_custLay_reflectivityCalculation.cpp)

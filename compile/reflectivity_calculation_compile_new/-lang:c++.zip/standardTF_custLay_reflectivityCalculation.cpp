//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custLay_reflectivityCalculation.cpp
//
// Code generation for function 'standardTF_custLay_reflectivityCalculation'
//

// Include files
#include "standardTF_custLay_reflectivityCalculation.h"
#include "blockedSummation.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_rtwutil.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_custlay_paraContrasts.h"
#include "standardTF_custlay_paraPoints.h"
#include "standardTF_custlay_single.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Definitions
//
// function
// [problem,reflectivity,Simulation,shifted_data,layerSlds,sldProfiles,allLayers]
// =
// standardTF_custLay_reflectivityCalculation(problemDef,problemDef_cells,problemDef_limits,controls)
namespace RAT {
void standardTF_custLay_reflectivityCalculation(
    const struct0_T *problemDef, const cell_16 *problemDef_cells,
    const struct2_T *controls, struct_T *problem,
    ::coder::array<cell_wrap_9, 1U> &reflectivity,
    ::coder::array<cell_wrap_9, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_14, 1U> &allLayers)
{
  ::coder::array<cell_wrap_31, 1U> r;
  double y;
  int i;
  int loop_ub_tmp;
  //  Custom layers reflectivity calculation for standardTF
  //  This function decides on parallelisation options before calling the
  //  relevant version of the main custom layers calculation. It is more
  //  efficient to have multiple versions of the core calculation, each dealing
  //  with a different scheme for paralellisation. These are:
  //  single    - single threaded teflectivity calculation
  //  points    - parallelise over points in the reflectivity calculation
  //  contrasts - parallelise over contrasts.
  //  Pre-allocation - It's necessary to
  //  pre-allocate the memory for all the arrays
  //  for compilation, so do this in this block.
  // 'standardTF_custLay_reflectivityCalculation:18' numberOfContrasts =
  // problemDef.numberOfContrasts;
  // 'standardTF_custLay_reflectivityCalculation:19' outSsubs =
  // zeros(numberOfContrasts,1);
  loop_ub_tmp = static_cast<int>(problemDef->numberOfContrasts);
  problem->ssubs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->ssubs[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:20' backgs =
  // zeros(numberOfContrasts,1);
  problem->backgrounds.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->backgrounds[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:21' qshifts =
  // zeros(numberOfContrasts,1);
  problem->qshifts.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->qshifts[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:22' sfs =
  // zeros(numberOfContrasts,1);
  problem->scalefactors.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->scalefactors[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:23' nbas =
  // zeros(numberOfContrasts,1);
  problem->nbairs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->nbairs[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:24' nbss =
  // zeros(numberOfContrasts,1);
  problem->nbsubs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->nbsubs[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:25' chis =
  // zeros(numberOfContrasts,1);
  problem->calculations.all_chis.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->calculations.all_chis[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:26' resols =
  // zeros(numberOfContrasts,1);
  problem->resolutions.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->resolutions[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:27' allRoughs =
  // zeros(numberOfContrasts,1);
  problem->allSubRough.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->allSubRough[i] = 0.0;
  }
  // 'standardTF_custLay_reflectivityCalculation:29' reflectivity =
  // cell(numberOfContrasts,1); 'standardTF_custLay_reflectivityCalculation:30'
  // for i = 1:numberOfContrasts
  reflectivity.set_size(loop_ub_tmp);
  // 'standardTF_custLay_reflectivityCalculation:34' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_custLay_reflectivityCalculation:35'
  // for i = 1:numberOfContrasts
  Simulation.set_size(loop_ub_tmp);
  // 'standardTF_custLay_reflectivityCalculation:39' shifted_data =
  // cell(numberOfContrasts,1); 'standardTF_custLay_reflectivityCalculation:40'
  // for i = 1:numberOfContrasts
  shifted_data.set_size(loop_ub_tmp);
  // 'standardTF_custLay_reflectivityCalculation:44' layerSlds =
  // cell(numberOfContrasts,1); 'standardTF_custLay_reflectivityCalculation:45'
  // for i = 1:numberOfContrasts
  layerSlds.set_size(loop_ub_tmp);
  // 'standardTF_custLay_reflectivityCalculation:49' sldProfiles =
  // cell(numberOfContrasts,1); 'standardTF_custLay_reflectivityCalculation:50'
  // for i = 1:numberOfContrasts
  sldProfiles.set_size(loop_ub_tmp);
  // 'standardTF_custLay_reflectivityCalculation:54' allLayers =
  // cell(numberOfContrasts,1); 'standardTF_custLay_reflectivityCalculation:55'
  // for i = 1:numberOfContrasts
  allLayers.set_size(loop_ub_tmp);
  for (int b_i{0}; b_i < loop_ub_tmp; b_i++) {
    // 'standardTF_custLay_reflectivityCalculation:31' reflectivity{i} = [1 1 ;
    // 1 1];
    reflectivity[b_i].f1.set_size(2, 2);
    reflectivity[b_i].f1[0] = 1.0;
    reflectivity[b_i].f1[1] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_custLay_reflectivityCalculation:36' Simulation{i} = [1 1 ; 1
    // 1];
    Simulation[b_i].f1.set_size(2, 2);
    Simulation[b_i].f1[0] = 1.0;
    Simulation[b_i].f1[1] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_custLay_reflectivityCalculation:41' shifted_data{i} = [1 1 1;
    // 1 1 1];
    shifted_data[b_i].f1.set_size(2, 3);
    // 'standardTF_custLay_reflectivityCalculation:46' layerSlds{i} = [1 1 1; 1
    // 1 1];
    layerSlds[b_i].f1.set_size(2, 3);
    // 'standardTF_custLay_reflectivityCalculation:51' sldProfiles{i} = [1 1; 1
    // 1];
    sldProfiles[b_i].f1.set_size(2, 2);
    sldProfiles[b_i].f1[0] = 1.0;
    sldProfiles[b_i].f1[1] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_custLay_reflectivityCalculation:56' allLayers{i} = [1 1 1; 1
    // 1 1];
    allLayers[b_i].f1.set_size(2, 3);
    for (i = 0; i < 3; i++) {
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i] = 1.0;
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i + 1] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i + 1] = 1.0;
      allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i] = 1.0;
      allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i + 1] = 1.0;
    }
  }
  //  End pre-allocation
  // 'standardTF_custLay_reflectivityCalculation:60' para = controls.para;
  // 'standardTF_custLay_reflectivityCalculation:62' switch para
  if (coder::internal::f_strcmp(controls->para)) {
    loop_ub_tmp = 0;
  } else if (coder::internal::g_strcmp(controls->para)) {
    loop_ub_tmp = 1;
  } else if (coder::internal::h_strcmp(controls->para)) {
    loop_ub_tmp = 2;
  } else {
    loop_ub_tmp = -1;
  }
  switch (loop_ub_tmp) {
  case 0:
    // 'standardTF_custLay_reflectivityCalculation:63' case 'single'
    // 'standardTF_custLay_reflectivityCalculation:65'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_custLay_reflectivityCalculation:66'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_custLay_reflectivityCalculation:67'              allRoughs] =
    // standardTF_custlay_single(problemDef,problemDef_cells,...
    // 'standardTF_custLay_reflectivityCalculation:68'
    // problemDef_limits,controls);
    standardTF_custlay_single(
        problemDef, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  case 1:
    // 'standardTF_custLay_reflectivityCalculation:70' case 'points'
    // 'standardTF_custLay_reflectivityCalculation:72'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_custLay_reflectivityCalculation:73'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_custLay_reflectivityCalculation:74'              allRoughs] =
    // standardTF_custlay_paraPoints(problemDef,problemDef_cells,...
    // 'standardTF_custLay_reflectivityCalculation:75'
    // problemDef_limits,controls);
    standardTF_custlay_paraPoints(
        problemDef, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  case 2:
    // 'standardTF_custLay_reflectivityCalculation:77' case 'contrasts'
    // 'standardTF_custLay_reflectivityCalculation:79'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_custLay_reflectivityCalculation:80'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_custLay_reflectivityCalculation:81'              allRoughs] =
    // standardTF_custlay_paraContrasts(problemDef,problemDef_cells,...
    // 'standardTF_custLay_reflectivityCalculation:82'
    // problemDef_limits,controls);
    standardTF_custlay_paraContrasts(
        problemDef, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, r, problem->allSubRough);
    cast(r, allLayers);
    //            [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    //               Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    //               allRoughs] =
    //               dev_custlay_paraContrasts(problemDef,problemDef_cells,...
    //               problemDef_limits,controls);
    break;
  }
  // 'standardTF_custLay_reflectivityCalculation:92' problem.ssubs = outSsubs;
  // 'standardTF_custLay_reflectivityCalculation:93' problem.backgrounds =
  // backgs; 'standardTF_custLay_reflectivityCalculation:94' problem.qshifts =
  // qshifts; 'standardTF_custLay_reflectivityCalculation:95'
  // problem.scalefactors = sfs; 'standardTF_custLay_reflectivityCalculation:96'
  // problem.nbairs = nbas; 'standardTF_custLay_reflectivityCalculation:97'
  // problem.nbsubs = nbss; 'standardTF_custLay_reflectivityCalculation:98'
  // problem.resolutions = resols;
  // 'standardTF_custLay_reflectivityCalculation:99'
  // problem.calculations.all_chis = chis;
  // 'standardTF_custLay_reflectivityCalculation:100'
  // problem.calculations.sum_chi = sum(chis);
  if (problem->calculations.all_chis.size(0) == 0) {
    y = 0.0;
  } else {
    y = coder::nestedIter(problem->calculations.all_chis,
                          problem->calculations.all_chis.size(0));
  }
  problem->calculations.sum_chi = y;
  // 'standardTF_custLay_reflectivityCalculation:101' problem.allSubRough =
  // allRoughs; 'standardTF_custLay_reflectivityCalculation:102'
  // problem.resample = problemDef.resample;
  problem->resample.set_size(1, problemDef->resample.size(1));
  loop_ub_tmp = problemDef->resample.size(1);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->resample[i] = problemDef->resample[i];
  }
}

} // namespace RAT

// End of code generation (standardTF_custLay_reflectivityCalculation.cpp)

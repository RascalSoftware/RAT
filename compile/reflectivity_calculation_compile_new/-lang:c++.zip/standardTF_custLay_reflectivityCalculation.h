//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custLay_reflectivityCalculation.h
//
// Code generation for function 'standardTF_custLay_reflectivityCalculation'
//
#ifndef STANDARDTF_CUSTLAY_REFLECTIVITYCALCULATION_H
#define STANDARDTF_CUSTLAY_REFLECTIVITYCALCULATION_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace RAT
{
  struct struct0_T;
  struct cell_18;
  struct struct2_T;
  struct struct_T;
  struct cell_wrap_9;
  struct cell_wrap_14;
  struct cell_wrap_10;
}

// Function Declarations
namespace RAT
{
  void standardTF_custLay_reflectivityCalculation(const struct0_T *problemDef,
    const cell_18 *problemDef_cells, const struct2_T *controls, struct_T
    *problem, ::coder::array<cell_wrap_9, 1U> &reflectivity, ::coder::array<
    cell_wrap_9, 1U> &Simulation, ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds, ::coder::array<cell_wrap_14, 1U>
    &sldProfiles, ::coder::array<cell_wrap_14, 1U> &allLayers);
}

#endif

// End of code generation (standardTF_custLay_reflectivityCalculation.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custXY_paraContrasts.cpp
//
// Code generation for function 'standardTF_custXY_paraContrasts'
//

// Include files
#include "standardTF_custXY_paraContrasts.h"
#include "applyBackgroundCorrection.h"
#include "backSort.h"
#include "callReflectivity.h"
#include "chiSquared.h"
#include "loopCppCustlayWrapper_CustLaysingle.h"
#include "loopMatalbCustlayWrapper_CustLaycontrast.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_rtwutil.h"
#include "reflectivity_calculation_types.h"
#include "resampleLayers.h"
#include "rt_nonfinite.h"
#include "shiftdata.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Definitions
//
// function [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
//     Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
//     allRoughs] =
//     standardTF_custXY_paraContrasts(problemDef,problemDef_cells,...
//     problemDef_limits,controls)
namespace RAT {
void standardTF_custXY_paraContrasts(
    const ::coder::array<double, 2U> &problemDef_contrastBacks,
    const ::coder::array<double, 2U> &problemDef_contrastBacksType,
    const ::coder::array<double, 2U> &problemDef_dataPresent,
    double problemDef_numberOfContrasts,
    const ::coder::array<double, 2U> &problemDef_contrastShifts,
    const ::coder::array<double, 2U> &problemDef_contrastScales,
    const ::coder::array<double, 2U> &problemDef_contrastNbas,
    const ::coder::array<double, 2U> &problemDef_contrastNbss,
    const ::coder::array<double, 2U> &problemDef_contrastRes,
    const ::coder::array<double, 2U> &problemDef_backs,
    const ::coder::array<double, 2U> &problemDef_shifts,
    const ::coder::array<double, 2U> &problemDef_sf,
    const ::coder::array<double, 2U> &problemDef_nba,
    const ::coder::array<double, 2U> &problemDef_nbs,
    const ::coder::array<double, 2U> &problemDef_res,
    const ::coder::array<double, 2U> &problemDef_params,
    const cell_16 *problemDef_cells, const struct2_T *controls,
    ::coder::array<double, 1U> &outSsubs, ::coder::array<double, 1U> &backgs,
    ::coder::array<double, 1U> &qshifts, ::coder::array<double, 1U> &sfs,
    ::coder::array<double, 1U> &nbas, ::coder::array<double, 1U> &nbss,
    ::coder::array<double, 1U> &resols, ::coder::array<double, 1U> &chis,
    ::coder::array<cell_wrap_12, 1U> &reflectivity,
    ::coder::array<cell_wrap_12, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_33, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs)
{
  ::coder::array<cell_wrap_14, 1U> sldProf;
  ::coder::array<cell_wrap_31, 1U> r;
  ::coder::array<double, 2U> Simul;
  ::coder::array<double, 2U> b_problemDef_cells;
  ::coder::array<double, 2U> layerSld;
  ::coder::array<double, 2U> reflect;
  ::coder::array<double, 2U> shifted_dat;
  int iv[2];
  int b_index;
  int i;
  int loop_ub_tmp;
  //  Extract individual cell arrays
  // 'standardTF_custXY_paraContrasts:8' [repeatLayers,...
  // 'standardTF_custXY_paraContrasts:9'  allData,...
  // 'standardTF_custXY_paraContrasts:10'  dataLimits,...
  // 'standardTF_custXY_paraContrasts:11'  simLimits,...
  // 'standardTF_custXY_paraContrasts:12'  contrastLayers,...
  // 'standardTF_custXY_paraContrasts:13'  layersDetails,...
  // 'standardTF_custXY_paraContrasts:14'  customFiles] =
  // RAT_parse_cells(problemDef_cells);
  //  Splits up the master input list of all arrays into separate arrays
  //  The min input array 'problemDef_cells' is a master array where
  //  all the cell arrays are grouped together. There are
  //  repeatLayers      - controls repeating of the layers stack
  //  allData           - Array of all the data arrays
  //  dataLimits        - Min max limits in q for the data arrays
  //  simLimits         - Limits in Q for the reflkectivity simulations
  //  Layers details    - Master array of all available layers
  //  contrastLayers    - Which specific combination of arrays are needed for
  //                      each contrast.
  //  Custom files      - Filenames and path for any custom files used
  // 'RAT_parse_cells:16' repeatLayers = problemDef_cells{1};
  // 'RAT_parse_cells:17' allData = problemDef_cells{2};
  // 'RAT_parse_cells:18' dataLimits = problemDef_cells{3};
  // 'RAT_parse_cells:19' simLimits = problemDef_cells{4};
  // 'RAT_parse_cells:20' contrastLayers = problemDef_cells{5};
  // 'RAT_parse_cells:21' layersDetails = problemDef_cells{6};
  // 'RAT_parse_cells:22' customFiles = problemDef_cells{14};
  //  Extract individual parameters from problemDef struct
  // 'standardTF_custXY_paraContrasts:17' [numberOfContrasts, geometry, cBacks,
  // cShifts, cScales, cNbas, cNbss,... 'standardTF_custXY_paraContrasts:18'
  // cRes, backs, shifts, sf, nba, nbs, res, dataPresent, nParams, params,...
  // 'standardTF_custXY_paraContrasts:19' numberOfLayers, resample, backsType,
  // cCustFiles] =  extractProblemParams(problemDef); Extract individual
  // parameters from problemDef 'extractProblemParams:7' numberOfContrasts =
  // problemDef.numberOfContrasts; 'extractProblemParams:8' geometry =
  // problemDef.geometry; 'extractProblemParams:9' cBacks =
  // problemDef.contrastBacks; 'extractProblemParams:10' cShifts =
  // problemDef.contrastShifts; 'extractProblemParams:11' cScales =
  // problemDef.contrastScales; 'extractProblemParams:12' cNbas =
  // problemDef.contrastNbas; 'extractProblemParams:13' cNbss =
  // problemDef.contrastNbss; 'extractProblemParams:14' cRes =
  // problemDef.contrastRes; 'extractProblemParams:15' backs = problemDef.backs;
  // 'extractProblemParams:16' shifts = problemDef.shifts;
  // 'extractProblemParams:17' sf = problemDef.sf;
  // 'extractProblemParams:18' nba = problemDef.nba;
  // 'extractProblemParams:19' nbs = problemDef.nbs;
  // 'extractProblemParams:20' res = problemDef.res;
  // 'extractProblemParams:21' dataPresent = problemDef.dataPresent;
  // 'extractProblemParams:22' nParams = length(problemDef.params);
  // 'extractProblemParams:23' params = problemDef.params;
  // 'extractProblemParams:24' numberOfLayers = problemDef.numberOfLayers;
  // 'extractProblemParams:25' resample = problemDef.resample;
  // 'extractProblemParams:26' backsType = problemDef.contrastBacksType;
  // 'extractProblemParams:27' cFiles = problemDef.contrastCustomFiles;
  // Pre-Allocation...
  // 'standardTF_custXY_paraContrasts:22' backgs = zeros(numberOfContrasts,1);
  loop_ub_tmp = static_cast<int>(problemDef_numberOfContrasts);
  backgs.set_size(loop_ub_tmp);
  // 'standardTF_custXY_paraContrasts:23' qshifts = zeros(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:24' sfs = zeros(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:25' nbas = zeros(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:26' nbss = zeros(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:27' resols = zeros(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:28' allRoughs =
  // zeros(numberOfContrasts,1);
  allRoughs.set_size(loop_ub_tmp);
  // 'standardTF_custXY_paraContrasts:29' outSsubs = zeros(numberOfContrasts,1);
  outSsubs.set_size(loop_ub_tmp);
  // 'standardTF_custXY_paraContrasts:30' chis =  zeros(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:31' allLayers = cell(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:32' layerSlds = cell(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:33' sldProfiles =
  // cell(numberOfContrasts,1); 'standardTF_custXY_paraContrasts:34'
  // shifted_data = cell(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:36' reflectivity =
  // cell(numberOfContrasts,1); 'standardTF_custXY_paraContrasts:37' for i =
  // 1:numberOfContrasts 'standardTF_custXY_paraContrasts:40'
  // coder.varsize('reflectivity{:}',[10000 2],[1 0]);
  // 'standardTF_custXY_paraContrasts:42' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_custXY_paraContrasts:43' for i =
  // 1:numberOfContrasts 'standardTF_custXY_paraContrasts:46'
  // coder.varsize('Simulation{:}',[10000 2],[1 0]);
  // 'standardTF_custXY_paraContrasts:47' sldProf = cell(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:48' for i = 1:numberOfContrasts
  sldProf.set_size(loop_ub_tmp);
  // 'standardTF_custXY_paraContrasts:51' allLayers = cell(numberOfContrasts,1);
  // 'standardTF_custXY_paraContrasts:52' for i = 1:numberOfContrasts
  // 'standardTF_custXY_paraContrasts:55' sldProfiles =
  // cell(numberOfContrasts,1); 'standardTF_custXY_paraContrasts:56' for i =
  // 1:numberOfContrasts
  sldProfiles.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    allRoughs[i] = 0.0;
    outSsubs[i] = 0.0;
    // 'standardTF_custXY_paraContrasts:49' sldProf{i} = [1 ; 1];
    sldProf[i].f1.set_size(2, 1);
    sldProf[i].f1[0] = 1.0;
    sldProf[i].f1[1] = 1.0;
    // 'standardTF_custXY_paraContrasts:57' sldProfiles{i} = [1 ; 1];
    sldProfiles[i].f1.set_size(2, 1);
    sldProfiles[i].f1[0] = 1.0;
    sldProfiles[i].f1[1] = 1.0;
  }
  // 'standardTF_custXY_paraContrasts:59' coder.varsize('allLayers{:}',[10000
  // 3],[1 1]);
  //  Depending on custom layer language we change the functions used
  // 'standardTF_custXY_paraContrasts:61' lang = customFiles{1}{2};
  //  so if there are multiple language models we should have a variable that
  //  seeks what language model is being used
  // 'standardTF_custXY_paraContrasts:62' switch lang
  if (coder::internal::j_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
    b_index = 0;
  } else if (coder::internal::k_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
    b_index = 1;
  } else {
    b_index = -1;
  }
  switch (b_index) {
  case 0:
    // 'standardTF_custXY_paraContrasts:63' case 'matlab'
    //  Call the Matlab parallel loop to process the custom models.....
    // 'standardTF_custXY_paraContrasts:65' [sldProf, allRoughs] =
    // loopMatalbCustlayWrapper_XYContrasts(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
    // 'standardTF_custXY_paraContrasts:66'
    // shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params);
    loopMatalbCustlayWrapper_CustLaycontrast(problemDef_numberOfContrasts,
                                             sldProf, allRoughs);
    //
    break;
  case 1:
    // 'standardTF_custXY_paraContrasts:68' case 'cpp'
    // 'standardTF_custXY_paraContrasts:69' [sldProf,allRoughs] =
    // loopCppCustlayWrapper_XYContrasts(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
    // 'standardTF_custXY_paraContrasts:70'
    // shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params);
    loopCppCustlayWrapper_CustLaysingle(problemDef_numberOfContrasts, r,
                                        allRoughs);
    cast(r, sldProf);
    break;
  }
  // 'standardTF_custXY_paraContrasts:76' for i = 1:numberOfContrasts
  qshifts.set_size(loop_ub_tmp);
  sfs.set_size(loop_ub_tmp);
  nbas.set_size(loop_ub_tmp);
  nbss.set_size(loop_ub_tmp);
  resols.set_size(loop_ub_tmp);
  layerSlds.set_size(loop_ub_tmp);
  allLayers.set_size(loop_ub_tmp);
  shifted_data.set_size(loop_ub_tmp);
  chis.set_size(loop_ub_tmp);
  Simulation.set_size(loop_ub_tmp);
  reflectivity.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    int b_i;
    int i1;
    int loop_ub;
    // 'standardTF_custXY_paraContrasts:77'
    // [backgs(i),qshifts(i),sfs(i),nbas(i),nbss(i),resols(i)] =
    // backSort(cBacks(i),cShifts(i),cScales(i),cNbas(i),cNbss(i),cRes(i),backs,shifts,sf,nba,nbs,res);
    backSort(problemDef_contrastBacks[i], problemDef_contrastShifts[i],
             problemDef_contrastScales[i], problemDef_contrastNbas[i],
             problemDef_contrastNbss[i], problemDef_contrastRes[i],
             problemDef_backs, problemDef_shifts, problemDef_sf, problemDef_nba,
             problemDef_nbs, problemDef_res, &backgs[i], &qshifts[i], &sfs[i],
             &nbas[i], &nbss[i], &resols[i]);
    //      thisCustomFile = customFiles{cCustFiles(i)};
    //      [sldProfile,allRoughs(i)] =
    //      call_customLayers(params,i,thisCustomFile,nbas,nbss(i),numberOfContrasts);
    // 'standardTF_custXY_paraContrasts:82' sldProfiles{i} = sldProf{i};
    b_index = sldProf[i].f1.size(1);
    sldProfiles[i].f1.set_size(sldProf[i].f1.size(0), sldProf[i].f1.size(1));
    for (b_i = 0; b_i < b_index; b_i++) {
      loop_ub = sldProf[i].f1.size(0);
      for (i1 = 0; i1 < loop_ub; i1++) {
        sldProfiles[i].f1[i1 + sldProfiles[i].f1.size(0) * b_i] =
            sldProf[i].f1[i1 + sldProf[i].f1.size(0) * b_i];
      }
    }
    // 'standardTF_custXY_paraContrasts:84' resamPars = controls.resamPars;
    // 'standardTF_custXY_paraContrasts:85' layerSld =
    // resampleLayers(sldProfiles{i},resamPars);
    iv[0] = (*(int(*)[2])sldProfiles[i].f1.size())[0];
    iv[1] = (*(int(*)[2])sldProfiles[i].f1.size())[1];
    resampleLayers((double *)sldProfiles[i].f1.data(), iv, controls->resamPars,
                   layerSld);
    // 'standardTF_custXY_paraContrasts:86' layerSlds{i} = layerSld;
    layerSlds[i].f1.set_size(layerSld.size(0), 3);
    // 'standardTF_custXY_paraContrasts:87' allLayers{i} = layerSld;
    allLayers[i].f1.set_size(layerSld.size(0), 3);
    b_index = layerSld.size(0);
    for (b_i = 0; b_i < 3; b_i++) {
      for (i1 = 0; i1 < b_index; i1++) {
        double d;
        d = layerSld[i1 + layerSld.size(0) * b_i];
        layerSlds[i].f1[i1 + layerSlds[i].f1.size(0) * b_i] = d;
        allLayers[i].f1[i1 + allLayers[i].f1.size(0) * b_i] = d;
      }
    }
    // 'standardTF_custXY_paraContrasts:89' shifted_dat =
    // shiftdata(sfs(i),qshifts(i),dataPresent(i),allData{i},dataLimits{i},simLimits{i});
    b_problemDef_cells.set_size(
        problemDef_cells->f2[problemDef_cells->f2.size(0) * i].f1.size(0),
        problemDef_cells->f2[problemDef_cells->f2.size(0) * i].f1.size(1));
    b_index = problemDef_cells->f2[i].f1.size(1) - 1;
    for (b_i = 0; b_i <= b_index; b_i++) {
      loop_ub = problemDef_cells->f2[i].f1.size(0) - 1;
      for (i1 = 0; i1 <= loop_ub; i1++) {
        b_problemDef_cells[i1 + b_problemDef_cells.size(0) * b_i] =
            problemDef_cells->f2[i]
                .f1[i1 + problemDef_cells->f2[i].f1.size(0) * b_i];
      }
    }
    shiftdata(
        sfs[i], qshifts[i], problemDef_dataPresent[i], b_problemDef_cells,
        problemDef_cells->f3[i].f1,
        (double *)((::coder::array<double, 2U> *)&problemDef_cells->f4[i].f1)
            ->data(),
        shifted_dat);
    // 'standardTF_custXY_paraContrasts:90' shifted_data{i} = shifted_dat;
    shifted_data[i].f1.set_size(shifted_dat.size(0), shifted_dat.size(1));
    b_index = shifted_dat.size(1);
    for (b_i = 0; b_i < b_index; b_i++) {
      loop_ub = shifted_dat.size(0);
      for (i1 = 0; i1 < loop_ub; i1++) {
        shifted_data[i].f1[i1 + shifted_data[i].f1.size(0) * b_i] =
            shifted_dat[i1 + shifted_dat.size(0) * b_i];
      }
    }
    // 'standardTF_custXY_paraContrasts:92' reflectivityType =
    // 'standardAbeles_realOnly'; 'standardTF_custXY_paraContrasts:93'
    // [reflect,Simul] =
    // callReflectivity(nbas(i),nbss(i),simLimits{i},repeatLayers{i},shifted_dat,layerSld,outSsubs(i),resols(i),'single',reflectivityType);
    callReflectivity(
        nbas[i], nbss[i],
        (double *)((::coder::array<double, 2U> *)&problemDef_cells->f4[i].f1)
            ->data(),
        problemDef_cells->f1[i].f1, shifted_dat, layerSld, 0.0, resols[i],
        reflect, Simul);
    // 'standardTF_custXY_paraContrasts:95' [reflect,Simul,shifted_dat] =
    // applyBackgroundCorrection(reflect,Simul,shifted_dat,backgs(i),backsType(i));
    applyBackgroundCorrection(reflect, Simul, shifted_dat, backgs[i],
                              problemDef_contrastBacksType[i]);
    // 'standardTF_custXY_paraContrasts:97' reflectivity{i} = reflect;
    b_index = reflect.size(0);
    reflectivity[i].f1.set_size(reflect.size(0), 2);
    // 'standardTF_custXY_paraContrasts:98' Simulation{i} = Simul;
    loop_ub = Simul.size(0);
    Simulation[i].f1.set_size(Simul.size(0), 2);
    for (b_i = 0; b_i < 2; b_i++) {
      for (i1 = 0; i1 < b_index; i1++) {
        reflectivity[i].f1[i1 + reflectivity[i].f1.size(0) * b_i] =
            reflect[i1 + reflect.size(0) * b_i];
      }
      for (i1 = 0; i1 < loop_ub; i1++) {
        Simulation[i].f1[i1 + Simulation[i].f1.size(0) * b_i] =
            Simul[i1 + Simul.size(0) * b_i];
      }
    }
    // 'standardTF_custXY_paraContrasts:100' if dataPresent(i)
    if (problemDef_dataPresent[i] != 0.0) {
      // 'standardTF_custXY_paraContrasts:101' chis(i) =
      // chiSquared(shifted_dat,reflect,nParams);
      chis[i] = chiSquared(shifted_dat, reflect,
                           static_cast<double>(problemDef_params.size(1)));
    } else {
      // 'standardTF_custXY_paraContrasts:102' else
      // 'standardTF_custXY_paraContrasts:103' chis(i) = 0;
      chis[i] = 0.0;
    }
  }
}

} // namespace RAT

// End of code generation (standardTF_custXY_paraContrasts.cpp)

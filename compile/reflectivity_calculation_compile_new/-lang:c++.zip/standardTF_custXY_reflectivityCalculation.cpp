//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custXY_reflectivityCalculation.cpp
//
// Code generation for function 'standardTF_custXY_reflectivityCalculation'
//

// Include files
#include "standardTF_custXY_reflectivityCalculation.h"
#include "blockedSummation.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_custXY_paraContrasts.h"
#include "standardTF_custXY_paraPoints.h"
#include "standardTF_custXY_single.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Declarations
namespace RAT {
static void cast(const ::coder::array<cell_wrap_12, 1U> &b,
                 ::coder::array<cell_wrap_9, 1U> &c);

static void cast(const ::coder::array<cell_wrap_33, 1U> &b,
                 ::coder::array<cell_wrap_14, 1U> &c);

} // namespace RAT

// Function Definitions
namespace RAT {
static void cast(const ::coder::array<cell_wrap_12, 1U> &b,
                 ::coder::array<cell_wrap_9, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(0);
    c[i1].f1.set_size(b[i1].f1.size(0), 2);
    for (int i2{0}; i2 < 2; i2++) {
      for (int i3{0}; i3 < loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

static void cast(const ::coder::array<cell_wrap_33, 1U> &b,
                 ::coder::array<cell_wrap_14, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    loop_ub = b[i1].f1.size(1);
    c[i1].f1.set_size(b[i1].f1.size(0), b[i1].f1.size(1));
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size(0);
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1[i3 + c[i1].f1.size(0) * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

//
// function
// [problem,reflectivity,Simulation,shifted_data,layerSlds,sldProfiles,allLayers]
// =
// standardTF_custXY_reflectivityCalculation(problemDef,problemDef_cells,problemDef_limits,controls)
void standardTF_custXY_reflectivityCalculation(
    const ::coder::array<double, 2U> &problemDef_contrastBacks,
    const ::coder::array<double, 2U> &problemDef_contrastBacksType,
    const ::coder::array<double, 2U> &problemDef_dataPresent,
    double problemDef_numberOfContrasts,
    const ::coder::array<double, 2U> &problemDef_contrastShifts,
    const ::coder::array<double, 2U> &problemDef_contrastScales,
    const ::coder::array<double, 2U> &problemDef_contrastNbas,
    const ::coder::array<double, 2U> &problemDef_contrastNbss,
    const ::coder::array<double, 2U> &problemDef_contrastRes,
    const ::coder::array<double, 2U> &problemDef_backs,
    const ::coder::array<double, 2U> &problemDef_shifts,
    const ::coder::array<double, 2U> &problemDef_sf,
    const ::coder::array<double, 2U> &problemDef_nba,
    const ::coder::array<double, 2U> &problemDef_nbs,
    const ::coder::array<double, 2U> &problemDef_res,
    const ::coder::array<double, 2U> &problemDef_params,
    const cell_16 *problemDef_cells, const struct2_T *controls,
    struct_T *problem, ::coder::array<cell_wrap_9, 1U> &reflectivity,
    ::coder::array<cell_wrap_9, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_14, 1U> &allLayers)
{
  ::coder::array<cell_wrap_12, 1U> r;
  ::coder::array<cell_wrap_12, 1U> r1;
  ::coder::array<cell_wrap_33, 1U> r2;
  double y;
  int i;
  int loop_ub_tmp;
  //  Custom XP profile reflectivity calculation for standardTF
  //  This function decides on parallelisation options before calling the
  //  relevant version of the main custom XY calculation. It is more
  //  efficient to have multiple versions of the core calculation, each dealing
  //  with a different scheme for paralellisation. These are:
  //  single    - single threaded teflectivity calculation
  //  points    - parallelise over points in the reflectivity calculation
  //  contrasts - parallelise over contrasts.
  //  Pre-allocation - It's necessary to
  //  pre-allocate the memory for all the arrays
  //  for compilation, so do this in this block.
  // 'standardTF_custXY_reflectivityCalculation:18' numberOfContrasts =
  // problemDef.numberOfContrasts;
  // 'standardTF_custXY_reflectivityCalculation:19' outSsubs =
  // zeros(numberOfContrasts,1);
  loop_ub_tmp = static_cast<int>(problemDef_numberOfContrasts);
  problem->ssubs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->ssubs[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:20' backgs =
  // zeros(numberOfContrasts,1);
  problem->backgrounds.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->backgrounds[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:21' qshifts =
  // zeros(numberOfContrasts,1);
  problem->qshifts.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->qshifts[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:22' sfs =
  // zeros(numberOfContrasts,1);
  problem->scalefactors.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->scalefactors[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:23' nbas =
  // zeros(numberOfContrasts,1);
  problem->nbairs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->nbairs[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:24' nbss =
  // zeros(numberOfContrasts,1);
  problem->nbsubs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->nbsubs[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:25' chis =
  // zeros(numberOfContrasts,1);
  problem->calculations.all_chis.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->calculations.all_chis[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:26' resols =
  // zeros(numberOfContrasts,1);
  problem->resolutions.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->resolutions[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:27' allRoughs =
  // zeros(numberOfContrasts,1);
  problem->allSubRough.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->allSubRough[i] = 0.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:29' reflectivity =
  // cell(numberOfContrasts,1); 'standardTF_custXY_reflectivityCalculation:30'
  // for i = 1:numberOfContrasts
  reflectivity.set_size(loop_ub_tmp);
  // 'standardTF_custXY_reflectivityCalculation:34' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_custXY_reflectivityCalculation:35'
  // for i = 1:numberOfContrasts
  Simulation.set_size(loop_ub_tmp);
  // 'standardTF_custXY_reflectivityCalculation:39' shifted_data =
  // cell(numberOfContrasts,1); 'standardTF_custXY_reflectivityCalculation:40'
  // for i = 1:numberOfContrasts
  shifted_data.set_size(loop_ub_tmp);
  // 'standardTF_custXY_reflectivityCalculation:44' layerSlds =
  // cell(numberOfContrasts,1); 'standardTF_custXY_reflectivityCalculation:45'
  // for i = 1:numberOfContrasts
  layerSlds.set_size(loop_ub_tmp);
  // 'standardTF_custXY_reflectivityCalculation:49' sldProfiles =
  // cell(numberOfContrasts,1); 'standardTF_custXY_reflectivityCalculation:50'
  // for i = 1:numberOfContrasts
  sldProfiles.set_size(loop_ub_tmp);
  // 'standardTF_custXY_reflectivityCalculation:54' allLayers =
  // cell(numberOfContrasts,1); 'standardTF_custXY_reflectivityCalculation:55'
  // for i = 1:numberOfContrasts
  allLayers.set_size(loop_ub_tmp);
  for (int b_i{0}; b_i < loop_ub_tmp; b_i++) {
    // 'standardTF_custXY_reflectivityCalculation:31' reflectivity{i} = [1 1 ; 1
    // 1];
    reflectivity[b_i].f1.set_size(2, 2);
    reflectivity[b_i].f1[0] = 1.0;
    reflectivity[b_i].f1[1] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_custXY_reflectivityCalculation:36' Simulation{i} = [1 1 ; 1
    // 1];
    Simulation[b_i].f1.set_size(2, 2);
    Simulation[b_i].f1[0] = 1.0;
    Simulation[b_i].f1[1] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_custXY_reflectivityCalculation:41' shifted_data{i} = [1 1 1;
    // 1 1 1];
    shifted_data[b_i].f1.set_size(2, 3);
    // 'standardTF_custXY_reflectivityCalculation:46' layerSlds{i} = [1 1 1; 1 1
    // 1];
    layerSlds[b_i].f1.set_size(2, 3);
    for (i = 0; i < 3; i++) {
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i] = 1.0;
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i + 1] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i + 1] = 1.0;
    }
    // 'standardTF_custXY_reflectivityCalculation:51' sldProfiles{i} = [1 1; 1
    // 1];
    sldProfiles[b_i].f1.set_size(2, 2);
    sldProfiles[b_i].f1[0] = 1.0;
    sldProfiles[b_i].f1[1] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_custXY_reflectivityCalculation:56' allLayers{i} = [1 ; 1];
    allLayers[b_i].f1.set_size(2, 1);
    allLayers[b_i].f1[0] = 1.0;
    allLayers[b_i].f1[1] = 1.0;
  }
  // 'standardTF_custXY_reflectivityCalculation:59' para = controls.para;
  // 'standardTF_custXY_reflectivityCalculation:61' switch para
  if (coder::internal::f_strcmp(controls->para)) {
    loop_ub_tmp = 0;
  } else if (coder::internal::g_strcmp(controls->para)) {
    loop_ub_tmp = 1;
  } else if (coder::internal::h_strcmp(controls->para)) {
    loop_ub_tmp = 2;
  } else {
    loop_ub_tmp = -1;
  }
  switch (loop_ub_tmp) {
  case 0:
    // 'standardTF_custXY_reflectivityCalculation:62' case 'single'
    // 'standardTF_custXY_reflectivityCalculation:64'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_custXY_reflectivityCalculation:65'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_custXY_reflectivityCalculation:66'              allRoughs] =
    // standardTF_custXY_single(problemDef,problemDef_cells,...
    // 'standardTF_custXY_reflectivityCalculation:67'
    // problemDef_limits,controls);
    standardTF_custXY_single(
        problemDef_contrastBacks, problemDef_contrastBacksType,
        problemDef_dataPresent, problemDef_numberOfContrasts,
        problemDef_contrastShifts, problemDef_contrastScales,
        problemDef_contrastNbas, problemDef_contrastNbss,
        problemDef_contrastRes, problemDef_backs, problemDef_shifts,
        problemDef_sf, problemDef_nba, problemDef_nbs, problemDef_res,
        problemDef_params, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  case 1:
    // 'standardTF_custXY_reflectivityCalculation:69' case 'points'
    // 'standardTF_custXY_reflectivityCalculation:71'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_custXY_reflectivityCalculation:72'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_custXY_reflectivityCalculation:73'              allRoughs] =
    // standardTF_custXY_paraPoints(problemDef,problemDef_cells,...
    // 'standardTF_custXY_reflectivityCalculation:74'
    // problemDef_limits,controls);
    standardTF_custXY_paraPoints(
        problemDef_contrastBacks, problemDef_contrastBacksType,
        problemDef_dataPresent, problemDef_numberOfContrasts,
        problemDef_contrastShifts, problemDef_contrastScales,
        problemDef_contrastNbas, problemDef_contrastNbss,
        problemDef_contrastRes, problemDef_backs, problemDef_shifts,
        problemDef_sf, problemDef_nba, problemDef_nbs, problemDef_res,
        problemDef_params, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  case 2:
    // 'standardTF_custXY_reflectivityCalculation:76' case 'contrasts'
    // 'standardTF_custXY_reflectivityCalculation:78'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_custXY_reflectivityCalculation:79'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_custXY_reflectivityCalculation:80'              allRoughs] =
    // standardTF_custXY_paraContrasts(problemDef,problemDef_cells,...
    // 'standardTF_custXY_reflectivityCalculation:81'
    // problemDef_limits,controls);
    standardTF_custXY_paraContrasts(
        problemDef_contrastBacks, problemDef_contrastBacksType,
        problemDef_dataPresent, problemDef_numberOfContrasts,
        problemDef_contrastShifts, problemDef_contrastScales,
        problemDef_contrastNbas, problemDef_contrastNbss,
        problemDef_contrastRes, problemDef_backs, problemDef_shifts,
        problemDef_sf, problemDef_nba, problemDef_nbs, problemDef_res,
        problemDef_params, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, r, r1, shifted_data, layerSlds,
        sldProfiles, r2, problem->allSubRough);
    cast(r, reflectivity);
    cast(r1, Simulation);
    cast(r2, allLayers);
    break;
  }
  // 'standardTF_custXY_reflectivityCalculation:85' problem.ssubs = outSsubs;
  // 'standardTF_custXY_reflectivityCalculation:86' problem.backgrounds =
  // backgs; 'standardTF_custXY_reflectivityCalculation:87' problem.qshifts =
  // qshifts; 'standardTF_custXY_reflectivityCalculation:88'
  // problem.scalefactors = sfs; 'standardTF_custXY_reflectivityCalculation:89'
  // problem.nbairs = nbas; 'standardTF_custXY_reflectivityCalculation:90'
  // problem.nbsubs = nbss; 'standardTF_custXY_reflectivityCalculation:91'
  // problem.resolutions = resols;
  // 'standardTF_custXY_reflectivityCalculation:92'
  // problem.calculations.all_chis = chis;
  // 'standardTF_custXY_reflectivityCalculation:93' problem.calculations.sum_chi
  // = sum(chis);
  if (problem->calculations.all_chis.size(0) == 0) {
    y = 0.0;
  } else {
    y = coder::nestedIter(problem->calculations.all_chis,
                          problem->calculations.all_chis.size(0));
  }
  problem->calculations.sum_chi = y;
  // 'standardTF_custXY_reflectivityCalculation:94' problem.allSubRough =
  // allRoughs; 'standardTF_custXY_reflectivityCalculation:95' problem.resample
  // = ones(1,length(allRoughs));
  problem->resample.set_size(1, problem->allSubRough.size(0));
  loop_ub_tmp = problem->allSubRough.size(0);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->resample[i] = 1.0;
  }
}

} // namespace RAT

// End of code generation (standardTF_custXY_reflectivityCalculation.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custlay_paraContrasts.cpp
//
// Code generation for function 'standardTF_custlay_paraContrasts'
//

// Include files
#include "standardTF_custlay_paraContrasts.h"
#include "backSort.h"
#include "loopCppCustlayWrapper_CustLaycontrast.h"
#include "loopMatalbCustlayWrapper_CustLaycontrast.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_rtwutil.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_layers_core.h"
#include "strcmp.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Function Declarations
namespace RAT {
static void cast(const ::coder::array<cell_wrap_14, 1U> &b,
                 ::coder::array<cell_wrap_31, 1U> &c);

}

// Function Definitions
namespace RAT {
static void cast(const ::coder::array<cell_wrap_14, 1U> &b,
                 ::coder::array<cell_wrap_31, 1U> &c)
{
  int i;
  c.set_size(b.size(0));
  i = b.size(0);
  for (int i1{0}; i1 < i; i1++) {
    int loop_ub;
    c[i1].f1.size[0] = b[i1].f1.size(0);
    loop_ub = b[i1].f1.size(1);
    c[i1].f1.size[1] = b[i1].f1.size(1);
    for (int i2{0}; i2 < loop_ub; i2++) {
      int b_loop_ub;
      b_loop_ub = b[i1].f1.size(0);
      for (int i3{0}; i3 < b_loop_ub; i3++) {
        c[i1].f1.data[i3 + c[i1].f1.size[0] * i2] =
            b[i1].f1[i3 + b[i1].f1.size(0) * i2];
      }
    }
  }
}

//
// function [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
//     Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
//     allRoughs] =
//     standardTF_custlay_paraContrasts(problemDef,problemDef_cells,...
//     problemDef_limits,controls)
void standardTF_custlay_paraContrasts(
    const struct0_T *problemDef, const cell_16 *problemDef_cells,
    const struct2_T *controls, ::coder::array<double, 1U> &outSsubs,
    ::coder::array<double, 1U> &backgs, ::coder::array<double, 1U> &qshifts,
    ::coder::array<double, 1U> &sfs, ::coder::array<double, 1U> &nbas,
    ::coder::array<double, 1U> &nbss, ::coder::array<double, 1U> &resols,
    ::coder::array<double, 1U> &chis,
    ::coder::array<cell_wrap_9, 1U> &reflectivity,
    ::coder::array<cell_wrap_9, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_31, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs)
{
  ::coder::array<cell_wrap_14, 1U> b_allLayers;
  ::coder::array<cell_wrap_31, 1U> r;
  ::coder::array<double, 2U> Simul;
  ::coder::array<double, 2U> c_allLayers;
  ::coder::array<double, 2U> reflect;
  ::coder::array<double, 2U> resamLayers;
  ::coder::array<double, 2U> shifted_dat;
  ::coder::array<double, 2U> sldProfile;
  double calcSld;
  double thisBackground;
  double thisChiSquared;
  double thisNba;
  double thisNbs;
  double thisQshift;
  double thisResol;
  double thisSf;
  double thisSsubs;
  int b_i;
  int b_index;
  int b_loop_ub;
  int c_i;
  int c_loop_ub;
  int i1;
  int loop_ub;
  int loop_ub_tmp;
  int nParams;
  //  Multi threaded version of the custom layers over reflectivity contrasts
  //  for standardTF reflectivity calculation. The function extracts the
  //  relevant parameters from the input arrays, allocates these on a
  //  pre-contrast basis, then calls the 'core' calculation (the core layers
  //  standardTf calc is shared between multiple calculation types). This
  //  differs from the other two paralellisations in that the custom model files
  //  are processed in a paralell loop (using the Matlab Paralell Computing
  //  Toolbox) outside the main loop, before the main loop is then processed in
  //  the compiled version using OpenMP. Extract individual cell arrays
  // 'standardTF_custlay_paraContrasts:17' [repeatLayers,...
  // 'standardTF_custlay_paraContrasts:18'  allData,...
  // 'standardTF_custlay_paraContrasts:19'  dataLimits,...
  // 'standardTF_custlay_paraContrasts:20'  simLimits,...
  // 'standardTF_custlay_paraContrasts:21'  contrastLayers,...
  // 'standardTF_custlay_paraContrasts:22'  layersDetails...
  // 'standardTF_custlay_paraContrasts:23'  customFiles] =
  // RAT_parse_cells(problemDef_cells);
  //  Splits up the master input list of all arrays into separate arrays
  //  The min input array 'problemDef_cells' is a master array where
  //  all the cell arrays are grouped together. There are
  //  repeatLayers      - controls repeating of the layers stack
  //  allData           - Array of all the data arrays
  //  dataLimits        - Min max limits in q for the data arrays
  //  simLimits         - Limits in Q for the reflkectivity simulations
  //  Layers details    - Master array of all available layers
  //  contrastLayers    - Which specific combination of arrays are needed for
  //                      each contrast.
  //  Custom files      - Filenames and path for any custom files used
  // 'RAT_parse_cells:16' repeatLayers = problemDef_cells{1};
  // 'RAT_parse_cells:17' allData = problemDef_cells{2};
  // 'RAT_parse_cells:18' dataLimits = problemDef_cells{3};
  // 'RAT_parse_cells:19' simLimits = problemDef_cells{4};
  // 'RAT_parse_cells:20' contrastLayers = problemDef_cells{5};
  // 'RAT_parse_cells:21' layersDetails = problemDef_cells{6};
  // 'RAT_parse_cells:22' customFiles = problemDef_cells{14};
  //  Extract individual parameters from problemDef struct
  // 'standardTF_custlay_paraContrasts:26' [numberOfContrasts, geometry, cBacks,
  // cShifts, cScales, cNbas, cNbss,... 'standardTF_custlay_paraContrasts:27'
  // cRes, backs, shifts, sf, nba, nbs, res, dataPresent, nParams, params,...
  // 'standardTF_custlay_paraContrasts:28' numberOfLayers, resample, backsType,
  // cCustFiles] =  extractProblemParams(problemDef); Extract individual
  // parameters from problemDef 'extractProblemParams:7' numberOfContrasts =
  // problemDef.numberOfContrasts; 'extractProblemParams:8' geometry =
  // problemDef.geometry; 'extractProblemParams:9' cBacks =
  // problemDef.contrastBacks; 'extractProblemParams:10' cShifts =
  // problemDef.contrastShifts; 'extractProblemParams:11' cScales =
  // problemDef.contrastScales; 'extractProblemParams:12' cNbas =
  // problemDef.contrastNbas; 'extractProblemParams:13' cNbss =
  // problemDef.contrastNbss; 'extractProblemParams:14' cRes =
  // problemDef.contrastRes; 'extractProblemParams:15' backs = problemDef.backs;
  // 'extractProblemParams:16' shifts = problemDef.shifts;
  // 'extractProblemParams:17' sf = problemDef.sf;
  // 'extractProblemParams:18' nba = problemDef.nba;
  // 'extractProblemParams:19' nbs = problemDef.nbs;
  // 'extractProblemParams:20' res = problemDef.res;
  // 'extractProblemParams:21' dataPresent = problemDef.dataPresent;
  // 'extractProblemParams:22' nParams = length(problemDef.params);
  nParams = problemDef->params.size(1);
  // 'extractProblemParams:23' params = problemDef.params;
  // 'extractProblemParams:24' numberOfLayers = problemDef.numberOfLayers;
  // 'extractProblemParams:25' resample = problemDef.resample;
  // 'extractProblemParams:26' backsType = problemDef.contrastBacksType;
  // 'extractProblemParams:27' cFiles = problemDef.contrastCustomFiles;
  // 'standardTF_custlay_paraContrasts:30' calcSld = controls.calcSld;
  calcSld = controls->calcSld;
  //  Pre-Allocation of output arrays...
  // 'standardTF_custlay_paraContrasts:34' backgs = zeros(numberOfContrasts,1);
  loop_ub_tmp = static_cast<int>(problemDef->numberOfContrasts);
  backgs.set_size(loop_ub_tmp);
  // 'standardTF_custlay_paraContrasts:35' qshifts = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:36' sfs = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:37' nbas = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:38' nbss = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:39' resols = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:40' allRoughs =
  // zeros(numberOfContrasts,1);
  allRoughs.set_size(loop_ub_tmp);
  // 'standardTF_custlay_paraContrasts:41' outSsubs =
  // zeros(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:42' chis =
  // zeros(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:43' allLayers
  // = cell(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:44'
  // layerSlds = cell(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:45' sldProfiles =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:46'
  // shifted_data = cell(numberOfContrasts,1);
  // 'standardTF_custlay_paraContrasts:48' reflectivity =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:49' for i =
  // 1:numberOfContrasts 'standardTF_custlay_paraContrasts:53' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:54' for i =
  // 1:numberOfContrasts 'standardTF_custlay_paraContrasts:58' allLayers =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraContrasts:59' for i =
  // 1:numberOfContrasts
  allLayers.set_size(loop_ub_tmp);
  for (int i{0}; i < loop_ub_tmp; i++) {
    allRoughs[i] = 0.0;
    // 'standardTF_custlay_paraContrasts:60' allLayers{i} = [1 ; 1];
    allLayers[i].f1.size[0] = 2;
    allLayers[i].f1.size[1] = 1;
    allLayers[i].f1.data[0] = 1.0;
    allLayers[i].f1.data[1] = 1.0;
  }
  // 'standardTF_custlay_paraContrasts:62'
  // coder.varsize('allLayers{:}',[1000,5],[1,1]);
  //    --- End Memory Allocation ---
  // 'standardTF_custlay_paraContrasts:69' resamPars = controls.resamPars;
  //  Depending on custom layer language we change the functions used
  // 'standardTF_custlay_paraContrasts:72' lang = customFiles{1}{2};
  //  so if there are multiple language models we should have a variable that
  //  seeks what language model is being used
  // 'standardTF_custlay_paraContrasts:74' switch lang
  if (coder::internal::j_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
    b_index = 0;
  } else if (coder::internal::k_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
    b_index = 1;
  } else {
    b_index = -1;
  }
  switch (b_index) {
  case 0:
    // 'standardTF_custlay_paraContrasts:75' case 'matlab'
    //  Call the Matlab parallel loop to process the custom models.....
    // 'standardTF_custlay_paraContrasts:77' [allLayers, allRoughs] =
    // loopMatalbCustlayWrapper_CustLaycontrast(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
    // 'standardTF_custlay_paraContrasts:78'
    // shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params);
    loopMatalbCustlayWrapper_CustLaycontrast(problemDef->numberOfContrasts,
                                             b_allLayers, allRoughs);
    cast(b_allLayers, allLayers);
    break;
  case 1:
    // 'standardTF_custlay_paraContrasts:79' case 'cpp'
    // 'standardTF_custlay_paraContrasts:80' [allLayers,allRoughs] =
    // loopCppCustlayWrapper_CustLaycontrast(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
    // 'standardTF_custlay_paraContrasts:81'
    // shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params);
    loopCppCustlayWrapper_CustLaycontrast(problemDef->numberOfContrasts, r,
                                          allRoughs);
    cast(r, b_allLayers);
    cast(b_allLayers, allLayers);
    break;
  }
  //  Multi cored over all contrasts
  // 'standardTF_custlay_paraContrasts:85' parfor i = 1:numberOfContrasts
  outSsubs.set_size(loop_ub_tmp);
  sldProfiles.set_size(loop_ub_tmp);
  reflectivity.set_size(loop_ub_tmp);
  Simulation.set_size(loop_ub_tmp);
  shifted_data.set_size(loop_ub_tmp);
  layerSlds.set_size(loop_ub_tmp);
  chis.set_size(loop_ub_tmp);
  qshifts.set_size(loop_ub_tmp);
  sfs.set_size(loop_ub_tmp);
  nbas.set_size(loop_ub_tmp);
  nbss.set_size(loop_ub_tmp);
  resols.set_size(loop_ub_tmp);
  b_index = loop_ub_tmp - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
    sldProfile, reflect, Simul, shifted_dat, resamLayers, thisSsubs,           \
    thisChiSquared, thisResol, thisNbs, thisNba, thisSf, thisQshift,           \
    thisBackground, b_i, loop_ub, b_loop_ub, c_loop_ub, c_i, i1)               \
    firstprivate(c_allLayers)

  for (b_i = 0; b_i <= b_index; b_i++) {
    //  Extract the relevant parameter values for this contrast
    //  from the input arrays.
    //  First need to decide which values of the backrounds, scalefactors
    //  data shifts and bulk contrasts are associated with this contrast
    // 'standardTF_custlay_paraContrasts:90'
    // [thisBackground,thisQshift,thisSf,thisNba,thisNbs,thisResol] =
    // backSort(cBacks(i),cShifts(i),cScales(i),cNbas(i),cNbss(i),cRes(i),backs,shifts,sf,nba,nbs,res);
    backSort(problemDef->contrastBacks[b_i], problemDef->contrastShifts[b_i],
             problemDef->contrastScales[b_i], problemDef->contrastNbas[b_i],
             problemDef->contrastNbss[b_i], problemDef->contrastRes[b_i],
             problemDef->backs, problemDef->shifts, problemDef->sf,
             problemDef->nba, problemDef->nbs, problemDef->res, &thisBackground,
             &thisQshift, &thisSf, &thisNba, &thisNbs, &thisResol);
    //  Get the custom layers output for this contrast
    // 'standardTF_custlay_paraContrasts:92' thisContrastLayers = allLayers{i};
    //  For the other parameters, we extract the correct ones from the input
    //  arrays
    // 'standardTF_custlay_paraContrasts:95' thisRough = allRoughs(i);
    // 'standardTF_custlay_paraContrasts:96' thisRepeatLayers = repeatLayers{i};
    // 'standardTF_custlay_paraContrasts:97' thisResample = resample(i);
    // 'standardTF_custlay_paraContrasts:98' thisCalcSld = calcSld;
    // 'standardTF_custlay_paraContrasts:99' thisData = allData{i};
    // 'standardTF_custlay_paraContrasts:100' thisDataPresent = dataPresent(i);
    // 'standardTF_custlay_paraContrasts:101' thisDataLimits = dataLimits{i};
    // 'standardTF_custlay_paraContrasts:102' thisSimLimits = simLimits{i};
    // 'standardTF_custlay_paraContrasts:103' thisBacksType = backsType(i);
    //  Now call the core standardTF_stanlay reflectivity calculation
    //  In this case we are single cored, so we do not parallelise over
    //  points
    // 'standardTF_custlay_paraContrasts:108' paralellPoints = 'single';
    //  Call the reflectivity calculation
    // 'standardTF_custlay_paraContrasts:111'
    // [sldProfile,reflect,Simul,shifted_dat,layerSld,resamLayers,thisChiSquared,thisSsubs]
    // = ... 'standardTF_custlay_paraContrasts:112' standardTF_layers_core...
    // 'standardTF_custlay_paraContrasts:113'     (thisContrastLayers,
    // thisRough, ... 'standardTF_custlay_paraContrasts:114'     geometry,
    // thisNba, thisNbs, thisResample, thisCalcSld, thisSf, thisQshift,...
    // 'standardTF_custlay_paraContrasts:115'     thisDataPresent, thisData,
    // thisDataLimits, thisSimLimits, thisRepeatLayers,...
    // 'standardTF_custlay_paraContrasts:116'
    // thisBackground,thisResol,thisBacksType,nParams,paralellPoints,resamPars);
    c_allLayers.set(&allLayers[b_i].f1.data[0], allLayers[b_i].f1.size[0],
                    allLayers[b_i].f1.size[1]);
    c_standardTF_layers_core(
        c_allLayers, allRoughs[b_i], problemDef->geometry, thisNba, thisNbs,
        problemDef->resample[b_i], calcSld, thisSf, thisQshift,
        problemDef->dataPresent[b_i], problemDef_cells->f2[b_i].f1,
        problemDef_cells->f3[b_i].f1,
        (double *)((::coder::array<double, 2U> *)&problemDef_cells->f4[b_i].f1)
            ->data(),
        problemDef_cells->f1[b_i].f1, thisBackground, thisResol,
        problemDef->contrastBacksType[b_i], static_cast<double>(nParams),
        controls->resamPars, sldProfile, reflect, Simul, shifted_dat,
        layerSlds[b_i].f1, resamLayers, &thisChiSquared, &thisSsubs);
    //  Store returned values for this contrast in the output arrays.
    //  As well as the calculated profiles, we also store a record of
    //  the other values (background, scalefactors etc) for each contrast
    //  for future use.
    // 'standardTF_custlay_paraContrasts:122' outSsubs(i) = thisSsubs;
    outSsubs[b_i] = thisSsubs;
    // 'standardTF_custlay_paraContrasts:123' sldProfiles{i} = sldProfile;
    loop_ub = sldProfile.size(0);
    sldProfiles[b_i].f1.set_size(sldProfile.size(0), 2);
    // 'standardTF_custlay_paraContrasts:124' reflectivity{i} = reflect;
    b_loop_ub = reflect.size(0);
    reflectivity[b_i].f1.set_size(reflect.size(0), 2);
    // 'standardTF_custlay_paraContrasts:125' Simulation{i} = Simul;
    c_loop_ub = Simul.size(0);
    Simulation[b_i].f1.set_size(Simul.size(0), 2);
    for (c_i = 0; c_i < 2; c_i++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        sldProfiles[b_i].f1[i1 + sldProfiles[b_i].f1.size(0) * c_i] =
            sldProfile[i1 + sldProfile.size(0) * c_i];
      }
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        reflectivity[b_i].f1[i1 + reflectivity[b_i].f1.size(0) * c_i] =
            reflect[i1 + reflect.size(0) * c_i];
      }
      for (i1 = 0; i1 < c_loop_ub; i1++) {
        Simulation[b_i].f1[i1 + Simulation[b_i].f1.size(0) * c_i] =
            Simul[i1 + Simul.size(0) * c_i];
      }
    }
    // 'standardTF_custlay_paraContrasts:126' shifted_data{i} = shifted_dat;
    loop_ub = shifted_dat.size(1);
    shifted_data[b_i].f1.set_size(shifted_dat.size(0), shifted_dat.size(1));
    for (c_i = 0; c_i < loop_ub; c_i++) {
      b_loop_ub = shifted_dat.size(0);
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        shifted_data[b_i].f1[i1 + shifted_data[b_i].f1.size(0) * c_i] =
            shifted_dat[i1 + shifted_dat.size(0) * c_i];
      }
    }
    // 'standardTF_custlay_paraContrasts:127' layerSlds{i} = layerSld;
    // 'standardTF_custlay_paraContrasts:128' allLayers{i} = resamLayers;
    loop_ub = resamLayers.size(0);
    allLayers[b_i].f1.size[0] = resamLayers.size(0);
    allLayers[b_i].f1.size[1] = 3;
    for (c_i = 0; c_i < 3; c_i++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        allLayers[b_i].f1.data[i1 + allLayers[b_i].f1.size[0] * c_i] =
            resamLayers[i1 + resamLayers.size(0) * c_i];
      }
    }
    // 'standardTF_custlay_paraContrasts:130' chis(i) = thisChiSquared;
    chis[b_i] = thisChiSquared;
    // 'standardTF_custlay_paraContrasts:131' backgs(i) = thisBackground;
    backgs[b_i] = thisBackground;
    // 'standardTF_custlay_paraContrasts:132' qshifts(i) = thisQshift;
    qshifts[b_i] = thisQshift;
    // 'standardTF_custlay_paraContrasts:133' sfs(i) = thisSf;
    sfs[b_i] = thisSf;
    // 'standardTF_custlay_paraContrasts:134' nbas(i) = thisNba;
    nbas[b_i] = thisNba;
    // 'standardTF_custlay_paraContrasts:135' nbss(i) = thisNbs;
    nbss[b_i] = thisNbs;
    // 'standardTF_custlay_paraContrasts:136' resols(i) = thisResol;
    resols[b_i] = thisResol;
    // 'standardTF_custlay_paraContrasts:137' allRoughs(i) = thisRough;
  }
}

} // namespace RAT

// End of code generation (standardTF_custlay_paraContrasts.cpp)

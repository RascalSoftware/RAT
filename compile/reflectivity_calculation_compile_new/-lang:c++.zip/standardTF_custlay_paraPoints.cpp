//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_custlay_paraPoints.cpp
//
// Code generation for function 'standardTF_custlay_paraPoints'
//

// Include files
#include "standardTF_custlay_paraPoints.h"
#include "backSort.h"
#include "loopCppCustlayWrapper_CustLaysingle.h"
#include "loopMatalbCustlayWrapper_CustLaysingle.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_rtwutil.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_layers_core.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Definitions
//
// function [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
//     Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
//     allRoughs] =
//     standardTF_custlay_paraPoints(problemDef,problemDef_cells,...
//     problemDef_limits,controls)
namespace RAT {
void standardTF_custlay_paraPoints(
    const struct0_T *problemDef, const cell_16 *problemDef_cells,
    const struct2_T *controls, ::coder::array<double, 1U> &outSsubs,
    ::coder::array<double, 1U> &backgs, ::coder::array<double, 1U> &qshifts,
    ::coder::array<double, 1U> &sfs, ::coder::array<double, 1U> &nbas,
    ::coder::array<double, 1U> &nbss, ::coder::array<double, 1U> &resols,
    ::coder::array<double, 1U> &chis,
    ::coder::array<cell_wrap_9, 1U> &reflectivity,
    ::coder::array<cell_wrap_9, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_14, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs)
{
  ::coder::array<cell_wrap_31, 1U> r;
  ::coder::array<double, 2U> resamLayers;
  ::coder::array<double, 2U> shifted_dat;
  ::coder::array<double, 2U> sldProfile;
  double thisBackground;
  double thisNba;
  double thisNbs;
  double thisQshift;
  double thisResol;
  double thisSf;
  int b_index;
  int i;
  int loop_ub_tmp;
  //  Multi threaded version of the custom layers over reflectivity poimnts
  //  for standardTF reflectivity calculation.
  //  The function extracts the relevant parameters from the input
  //  arrays, allocates these on a pre-contrast basis, then calls the 'core'
  //  calculation (the core layers standardTf calc is shared between multiple
  //  calculation types).
  //  Extract individual cell arrays
  // 'standardTF_custlay_paraPoints:13' [repeatLayers,...
  // 'standardTF_custlay_paraPoints:14'  allData,...
  // 'standardTF_custlay_paraPoints:15'  dataLimits,...
  // 'standardTF_custlay_paraPoints:16'  simLimits,...
  // 'standardTF_custlay_paraPoints:17'  contrastLayers,...
  // 'standardTF_custlay_paraPoints:18'  layersDetails...
  // 'standardTF_custlay_paraPoints:19'  customFiles] =
  // RAT_parse_cells(problemDef_cells);
  //  Splits up the master input list of all arrays into separate arrays
  //  The min input array 'problemDef_cells' is a master array where
  //  all the cell arrays are grouped together. There are
  //  repeatLayers      - controls repeating of the layers stack
  //  allData           - Array of all the data arrays
  //  dataLimits        - Min max limits in q for the data arrays
  //  simLimits         - Limits in Q for the reflkectivity simulations
  //  Layers details    - Master array of all available layers
  //  contrastLayers    - Which specific combination of arrays are needed for
  //                      each contrast.
  //  Custom files      - Filenames and path for any custom files used
  // 'RAT_parse_cells:16' repeatLayers = problemDef_cells{1};
  // 'RAT_parse_cells:17' allData = problemDef_cells{2};
  // 'RAT_parse_cells:18' dataLimits = problemDef_cells{3};
  // 'RAT_parse_cells:19' simLimits = problemDef_cells{4};
  // 'RAT_parse_cells:20' contrastLayers = problemDef_cells{5};
  // 'RAT_parse_cells:21' layersDetails = problemDef_cells{6};
  // 'RAT_parse_cells:22' customFiles = problemDef_cells{14};
  //  Extract individual parameters from problemDef struct
  // 'standardTF_custlay_paraPoints:22' [numberOfContrasts, geometry, cBacks,
  // cShifts, cScales, cNbas, cNbss,... 'standardTF_custlay_paraPoints:23' cRes,
  // backs, shifts, sf, nba, nbs, res, dataPresent, nParams, params,...
  // 'standardTF_custlay_paraPoints:24' numberOfLayers, resample, backsType,
  // cCustFiles] =  extractProblemParams(problemDef); Extract individual
  // parameters from problemDef 'extractProblemParams:7' numberOfContrasts =
  // problemDef.numberOfContrasts; 'extractProblemParams:8' geometry =
  // problemDef.geometry; 'extractProblemParams:9' cBacks =
  // problemDef.contrastBacks; 'extractProblemParams:10' cShifts =
  // problemDef.contrastShifts; 'extractProblemParams:11' cScales =
  // problemDef.contrastScales; 'extractProblemParams:12' cNbas =
  // problemDef.contrastNbas; 'extractProblemParams:13' cNbss =
  // problemDef.contrastNbss; 'extractProblemParams:14' cRes =
  // problemDef.contrastRes; 'extractProblemParams:15' backs = problemDef.backs;
  // 'extractProblemParams:16' shifts = problemDef.shifts;
  // 'extractProblemParams:17' sf = problemDef.sf;
  // 'extractProblemParams:18' nba = problemDef.nba;
  // 'extractProblemParams:19' nbs = problemDef.nbs;
  // 'extractProblemParams:20' res = problemDef.res;
  // 'extractProblemParams:21' dataPresent = problemDef.dataPresent;
  // 'extractProblemParams:22' nParams = length(problemDef.params);
  // 'extractProblemParams:23' params = problemDef.params;
  // 'extractProblemParams:24' numberOfLayers = problemDef.numberOfLayers;
  // 'extractProblemParams:25' resample = problemDef.resample;
  // 'extractProblemParams:26' backsType = problemDef.contrastBacksType;
  // 'extractProblemParams:27' cFiles = problemDef.contrastCustomFiles;
  // 'standardTF_custlay_paraPoints:26' calcSld = controls.calcSld;
  //  Pre-Allocation of output arrays...
  //    --- Begin Memory Allocation ---
  // 'standardTF_custlay_paraPoints:30' backgs = zeros(numberOfContrasts,1);
  loop_ub_tmp = static_cast<int>(problemDef->numberOfContrasts);
  backgs.set_size(loop_ub_tmp);
  // 'standardTF_custlay_paraPoints:31' qshifts = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:32' sfs = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:33' nbas = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:34' nbss = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:35' resols = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:36' allRoughs = zeros(numberOfContrasts,1);
  allRoughs.set_size(loop_ub_tmp);
  // 'standardTF_custlay_paraPoints:37' outSsubs = zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:38' chis =  zeros(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:39' allLayers = cell(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:40' layerSlds = cell(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:41' sldProfiles = cell(numberOfContrasts,1);
  // 'standardTF_custlay_paraPoints:42' shifted_data =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraPoints:44' reflectivity
  // = cell(numberOfContrasts,1); 'standardTF_custlay_paraPoints:45' for i =
  // 1:numberOfContrasts 'standardTF_custlay_paraPoints:49' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraPoints:50' for i =
  // 1:numberOfContrasts 'standardTF_custlay_paraPoints:54' allLayers =
  // cell(numberOfContrasts,1); 'standardTF_custlay_paraPoints:55' for i =
  // 1:numberOfContrasts
  allLayers.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    allRoughs[i] = 0.0;
    // 'standardTF_custlay_paraPoints:56' allLayers{i} = [1 ; 1];
    allLayers[i].f1.set_size(2, 1);
    allLayers[i].f1[0] = 1.0;
    allLayers[i].f1[1] = 1.0;
  }
  //    --- End Memory Allocation ---
  // 'standardTF_custlay_paraPoints:61' resamPars = controls.resamPars;
  //  Depending on custom layer language we change the functions used
  // 'standardTF_custlay_paraPoints:63' lang = customFiles{1}{2};
  //  so if there are multiple language models we should have a variable that
  //  seeks what language model is being used
  // 'standardTF_custlay_paraPoints:64' switch lang
  if (coder::internal::j_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
    b_index = 0;
  } else if (coder::internal::k_strcmp(problemDef_cells->f14[0].f1[1].f1)) {
    b_index = 1;
  } else {
    b_index = -1;
  }
  switch (b_index) {
  case 0:
    // 'standardTF_custlay_paraPoints:65' case 'matlab'
    //  Call the Matlab parallel loop to process the custom models.....
    // 'standardTF_custlay_paraPoints:67' [allLayers, allRoughs] =
    // loopMatalbCustlayWrapper_CustLaypoints(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
    // 'standardTF_custlay_paraPoints:68'
    // shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params);
    loopMatalbCustlayWrapper_CustLaysingle(problemDef->numberOfContrasts,
                                           allLayers, allRoughs);
    //
    break;
  case 1:
    // 'standardTF_custlay_paraPoints:70' case 'cpp'
    // 'standardTF_custlay_paraPoints:71' [allLayers,allRoughs] =
    // loopCppCustlayWrapper_CustLaypoints(cBacks,cShifts,cScales,cNbas,cNbss,cRes,backs,...
    // 'standardTF_custlay_paraPoints:72'
    // shifts,sf,nba,nbs,res,cCustFiles,numberOfContrasts,customFiles,params);
    loopCppCustlayWrapper_CustLaysingle(problemDef->numberOfContrasts, r,
                                        allRoughs);
    cast(r, allLayers);
    break;
  }
  //  Single cored over all contrasts
  // 'standardTF_custlay_paraPoints:78' for i = 1:numberOfContrasts
  outSsubs.set_size(loop_ub_tmp);
  sldProfiles.set_size(loop_ub_tmp);
  reflectivity.set_size(loop_ub_tmp);
  Simulation.set_size(loop_ub_tmp);
  shifted_data.set_size(loop_ub_tmp);
  layerSlds.set_size(loop_ub_tmp);
  chis.set_size(loop_ub_tmp);
  qshifts.set_size(loop_ub_tmp);
  sfs.set_size(loop_ub_tmp);
  nbas.set_size(loop_ub_tmp);
  nbss.set_size(loop_ub_tmp);
  resols.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    int b_i;
    int i1;
    //  Extract the relevant parameter values for this contrast
    //  from the input arrays.
    //  First need to decide which values of the backrounds, scalefactors
    //  data shifts and bulk contrasts are associated with this contrast
    // 'standardTF_custlay_paraPoints:83'
    // [thisBackground,thisQshift,thisSf,thisNba,thisNbs,thisResol] =
    // backSort(cBacks(i),cShifts(i),cScales(i),cNbas(i),cNbss(i),cRes(i),backs,shifts,sf,nba,nbs,res);
    backSort(problemDef->contrastBacks[i], problemDef->contrastShifts[i],
             problemDef->contrastScales[i], problemDef->contrastNbas[i],
             problemDef->contrastNbss[i], problemDef->contrastRes[i],
             problemDef->backs, problemDef->shifts, problemDef->sf,
             problemDef->nba, problemDef->nbs, problemDef->res, &thisBackground,
             &thisQshift, &thisSf, &thisNba, &thisNbs, &thisResol);
    //  Call the custom layers function to get the layers array...
    // 'standardTF_custlay_paraPoints:88' thisContrastLayers = allLayers{i};
    //  For the other parameters, we extract the correct ones from the input
    //  arrays
    // 'standardTF_custlay_paraPoints:92' thisRough = allRoughs(i);
    // 'standardTF_custlay_paraPoints:93' thisRepeatLayers = repeatLayers{i};
    // 'standardTF_custlay_paraPoints:94' thisResample = resample(i);
    // 'standardTF_custlay_paraPoints:95' thisCalcSld = calcSld;
    // 'standardTF_custlay_paraPoints:96' thisData = allData{i};
    // 'standardTF_custlay_paraPoints:97' thisDataPresent = dataPresent(i);
    // 'standardTF_custlay_paraPoints:98' thisDataLimits = dataLimits{i};
    // 'standardTF_custlay_paraPoints:99' thisSimLimits = simLimits{i};
    // 'standardTF_custlay_paraPoints:100' thisBacksType = backsType(i);
    //  Now call the core standardTF_stanlay reflectivity calculation
    //  In this case we are single cored, so we do not parallelise over
    //  points
    // 'standardTF_custlay_paraPoints:105' paralellPoints = 'points';
    //  Call the reflectivity calculation
    // 'standardTF_custlay_paraPoints:108'
    // [sldProfile,reflect,Simul,shifted_dat,layerSld,resamLayers,thisChiSquared,thisSsubs]
    // = ... 'standardTF_custlay_paraPoints:109'     standardTF_layers_core...
    // 'standardTF_custlay_paraPoints:110'     (thisContrastLayers, thisRough,
    // ... 'standardTF_custlay_paraPoints:111'     geometry, thisNba, thisNbs,
    // thisResample, thisCalcSld, thisSf, thisQshift,...
    // 'standardTF_custlay_paraPoints:112'     thisDataPresent, thisData,
    // thisDataLimits, thisSimLimits, thisRepeatLayers,...
    // 'standardTF_custlay_paraPoints:113'
    // thisBackground,thisResol,thisBacksType,nParams,paralellPoints,resamPars);
    d_standardTF_layers_core(
        allLayers[i].f1, allRoughs[i], problemDef->geometry, thisNba, thisNbs,
        problemDef->resample[i], controls->calcSld, thisSf, thisQshift,
        problemDef->dataPresent[i], problemDef_cells->f2[i].f1,
        problemDef_cells->f3[i].f1,
        (double *)((::coder::array<double, 2U> *)&problemDef_cells->f4[i].f1)
            ->data(),
        problemDef_cells->f1[i].f1, thisBackground, thisResol,
        problemDef->contrastBacksType[i],
        static_cast<double>(problemDef->params.size(1)), controls->resamPars,
        sldProfile, reflectivity[i].f1, Simulation[i].f1, shifted_dat,
        layerSlds[i].f1, resamLayers, &chis[i], &outSsubs[i]);
    //  Store returned values for this contrast in the output arrays.
    //  As well as the calculated profiles, we also store a record of
    //  the other values (background, scalefactors etc) for each contrast
    //  for future use.
    // 'standardTF_custlay_paraPoints:119' outSsubs(i) = thisSsubs;
    // 'standardTF_custlay_paraPoints:120' sldProfiles{i} = sldProfile;
    b_index = sldProfile.size(0);
    sldProfiles[i].f1.set_size(sldProfile.size(0), 2);
    for (b_i = 0; b_i < 2; b_i++) {
      for (i1 = 0; i1 < b_index; i1++) {
        sldProfiles[i].f1[i1 + sldProfiles[i].f1.size(0) * b_i] =
            sldProfile[i1 + sldProfile.size(0) * b_i];
      }
    }
    // 'standardTF_custlay_paraPoints:121' reflectivity{i} = reflect;
    // 'standardTF_custlay_paraPoints:122' Simulation{i} = Simul;
    // 'standardTF_custlay_paraPoints:123' shifted_data{i} = shifted_dat;
    b_index = shifted_dat.size(1);
    shifted_data[i].f1.set_size(shifted_dat.size(0), shifted_dat.size(1));
    for (b_i = 0; b_i < b_index; b_i++) {
      int loop_ub;
      loop_ub = shifted_dat.size(0);
      for (i1 = 0; i1 < loop_ub; i1++) {
        shifted_data[i].f1[i1 + shifted_data[i].f1.size(0) * b_i] =
            shifted_dat[i1 + shifted_dat.size(0) * b_i];
      }
    }
    // 'standardTF_custlay_paraPoints:124' layerSlds{i} = layerSld;
    // 'standardTF_custlay_paraPoints:125' allLayers{i} = resamLayers;
    b_index = resamLayers.size(0);
    allLayers[i].f1.set_size(resamLayers.size(0), 3);
    for (b_i = 0; b_i < 3; b_i++) {
      for (i1 = 0; i1 < b_index; i1++) {
        allLayers[i].f1[i1 + allLayers[i].f1.size(0) * b_i] =
            resamLayers[i1 + resamLayers.size(0) * b_i];
      }
    }
    // 'standardTF_custlay_paraPoints:127' chis(i) = thisChiSquared;
    // 'standardTF_custlay_paraPoints:128' backgs(i) = thisBackground;
    backgs[i] = thisBackground;
    // 'standardTF_custlay_paraPoints:129' qshifts(i) = thisQshift;
    qshifts[i] = thisQshift;
    // 'standardTF_custlay_paraPoints:130' sfs(i) = thisSf;
    sfs[i] = thisSf;
    // 'standardTF_custlay_paraPoints:131' nbas(i) = thisNba;
    nbas[i] = thisNba;
    // 'standardTF_custlay_paraPoints:132' nbss(i) = thisNbs;
    nbss[i] = thisNbs;
    // 'standardTF_custlay_paraPoints:133' resols(i) = thisResol;
    resols[i] = thisResol;
    // 'standardTF_custlay_paraPoints:134' allRoughs(i) = thisRough;
  }
}

} // namespace RAT

// End of code generation (standardTF_custlay_paraPoints.cpp)

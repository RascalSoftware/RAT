//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_reflectivityCalculation.cpp
//
// Code generation for function 'standardTF_reflectivityCalculation'
//

// Include files
#include "standardTF_reflectivityCalculation.h"
#include "lower.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_custLay_reflectivityCalculation.h"
#include "standardTF_custXY_reflectivityCalculation.h"
#include "standardTF_stanLay_reflectivityCalculation.h"
#include "strcmp.h"
#include "coder_array.h"
#include "coder_bounded_array.h"

// Function Definitions
namespace RAT
{
  void standardTF_reflectivityCalculation(const struct0_T *problemDef, const
    cell_18 *problemDef_cells, const struct2_T *controls, struct4_T *problem, ::
    coder::array<cell_wrap_9, 1U> &reflectivity, ::coder::array<cell_wrap_9, 1U>
    &Simulation, ::coder::array<cell_wrap_14, 1U> &shifted_data, ::coder::array<
    cell_wrap_10, 1U> &layerSlds, ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_14, 1U> &allLayers)
  {
    ::coder::array<int8_T, 1U> t1_calculations_all_chis;
    struct_T b_problem;
    struct_T c_problem;
    int32_T switch_expression_size[2];
    int32_T i;
    int32_T loop_ub;
    int32_T loop_ub_tmp;
    char_T switch_expression_data[1000];

    //  Main function for the standardTF reflectivity calculation
    //  This function decides what type of model is being analysed and barnches
    //  to the correct one. The main options are:
    //  layers            - This is the equivalent of Standard Layers in RasCAL
    //  Custom Layers     - This is also a layers calculation, but the
    //                    specification of the layers is dne using a user defined
    //                    function.
    //  Custom XY         - This also has a model described by a user supplied
    //                    function, but in this case the function generates an
    //                    SLD profile (i.e. XY function) rather than a list of
    //                    layers.
    //  Find out the model type from the input structs
    //  Pre-allocate the output arrays.. this is necessary because otherwise
    //  the compiler complains with 'Output argument <....> is not assigned on
    //  some execution paths' error.
    loop_ub_tmp = static_cast<int32_T>(problemDef->numberOfContrasts);
    t1_calculations_all_chis.set_size(loop_ub_tmp);
    problem->ssubs.set_size(loop_ub_tmp);
    problem->backgrounds.set_size(loop_ub_tmp);
    problem->qshifts.set_size(loop_ub_tmp);
    problem->scalefactors.set_size(loop_ub_tmp);
    problem->nbairs.set_size(loop_ub_tmp);
    problem->nbsubs.set_size(loop_ub_tmp);
    problem->resolutions.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      t1_calculations_all_chis[i] = 0;
      problem->ssubs[i] = 0.0;
      problem->backgrounds[i] = 0.0;
      problem->qshifts[i] = 0.0;
      problem->scalefactors[i] = 0.0;
      problem->nbairs[i] = 0.0;
      problem->nbsubs[i] = 0.0;
      problem->resolutions[i] = 0.0;
    }

    problem->calculations.all_chis.set_size(t1_calculations_all_chis.size(0));
    loop_ub = t1_calculations_all_chis.size(0);
    for (i = 0; i < loop_ub; i++) {
      problem->calculations.all_chis[i] = 0.0;
    }

    problem->calculations.sum_chi = 0.0;
    problem->allSubRough.set_size(loop_ub_tmp);
    for (i = 0; i < loop_ub_tmp; i++) {
      problem->allSubRough[i] = 0.0;
    }

    problem->resample.set_size(loop_ub_tmp, 1);
    for (i = 0; i < 1; i++) {
      for (loop_ub = 0; loop_ub < loop_ub_tmp; loop_ub++) {
        problem->resample[loop_ub] = 0.0;
      }
    }

    reflectivity.set_size(loop_ub_tmp);
    Simulation.set_size(loop_ub_tmp);
    shifted_data.set_size(loop_ub_tmp);
    layerSlds.set_size(loop_ub_tmp);
    sldProfiles.set_size(loop_ub_tmp);
    allLayers.set_size(loop_ub_tmp);
    for (int32_T b_i{0}; b_i < loop_ub_tmp; b_i++) {
      reflectivity[b_i].f1.set_size(2, 2);
      reflectivity[b_i].f1[0] = 1.0;
      reflectivity[b_i].f1[1] = 1.0;
      reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
      reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
      Simulation[b_i].f1.set_size(2, 2);
      Simulation[b_i].f1[0] = 1.0;
      Simulation[b_i].f1[1] = 1.0;
      Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
      Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
      shifted_data[b_i].f1.set_size(2, 3);
      layerSlds[b_i].f1.set_size(2, 3);
      sldProfiles[b_i].f1.set_size(2, 2);
      sldProfiles[b_i].f1[0] = 1.0;
      sldProfiles[b_i].f1[1] = 1.0;
      sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
      sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
      allLayers[b_i].f1.set_size(2, 3);
      for (i = 0; i < 3; i++) {
        shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i] = 1.0;
        shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i + 1] = 1.0;
        layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i] = 1.0;
        layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i + 1] = 1.0;
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i] = 1.0;
        allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i + 1] = 1.0;
      }
    }

    coder::lower(problemDef->modelType.data, problemDef->modelType.size,
                 switch_expression_data, switch_expression_size);
    if (coder::internal::c_strcmp(switch_expression_data, switch_expression_size))
    {
      loop_ub = 0;
    } else if (coder::internal::d_strcmp(switch_expression_data,
                switch_expression_size)) {
      loop_ub = 1;
    } else if (coder::internal::e_strcmp(switch_expression_data,
                switch_expression_size)) {
      loop_ub = 2;
    } else {
      loop_ub = -1;
    }

    switch (loop_ub) {
     case 0:
      //  Standard layers calculation
      standardTF_stanLay_reflectivityCalculation(problemDef, problemDef_cells,
        controls, &b_problem, reflectivity, Simulation, shifted_data, layerSlds,
        sldProfiles, allLayers);
      problem->ssubs.set_size(b_problem.ssubs.size(0));
      loop_ub = b_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->ssubs[i] = b_problem.ssubs[i];
      }

      problem->backgrounds.set_size(b_problem.backgrounds.size(0));
      loop_ub = b_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->backgrounds[i] = b_problem.backgrounds[i];
      }

      problem->qshifts.set_size(b_problem.qshifts.size(0));
      loop_ub = b_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->qshifts[i] = b_problem.qshifts[i];
      }

      problem->scalefactors.set_size(b_problem.scalefactors.size(0));
      loop_ub = b_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->scalefactors[i] = b_problem.scalefactors[i];
      }

      problem->nbairs.set_size(b_problem.nbairs.size(0));
      loop_ub = b_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbairs[i] = b_problem.nbairs[i];
      }

      problem->nbsubs.set_size(b_problem.nbsubs.size(0));
      loop_ub = b_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbsubs[i] = b_problem.nbsubs[i];
      }

      problem->resolutions.set_size(b_problem.resolutions.size(0));
      loop_ub = b_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->resolutions[i] = b_problem.resolutions[i];
      }

      problem->calculations = b_problem.calculations;
      problem->allSubRough.set_size(b_problem.allSubRough.size(0));
      loop_ub = b_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->allSubRough[i] = b_problem.allSubRough[i];
      }

      problem->resample.set_size(1, b_problem.resample.size(1));
      loop_ub = b_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        problem->resample[problem->resample.size(0) * i] = b_problem.resample[i];
      }
      break;

     case 1:
      //  Custom layers with user supplied custom model file
      standardTF_custLay_reflectivityCalculation(problemDef, problemDef_cells,
        controls, &c_problem, reflectivity, Simulation, shifted_data, layerSlds,
        sldProfiles, allLayers);
      b_problem.ssubs.set_size(c_problem.ssubs.size(0));
      loop_ub = c_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.ssubs[i] = c_problem.ssubs[i];
      }

      b_problem.backgrounds.set_size(c_problem.backgrounds.size(0));
      loop_ub = c_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.backgrounds[i] = c_problem.backgrounds[i];
      }

      b_problem.qshifts.set_size(c_problem.qshifts.size(0));
      loop_ub = c_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.qshifts[i] = c_problem.qshifts[i];
      }

      b_problem.scalefactors.set_size(c_problem.scalefactors.size(0));
      loop_ub = c_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.scalefactors[i] = c_problem.scalefactors[i];
      }

      b_problem.nbairs.set_size(c_problem.nbairs.size(0));
      loop_ub = c_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbairs[i] = c_problem.nbairs[i];
      }

      b_problem.nbsubs.set_size(c_problem.nbsubs.size(0));
      loop_ub = c_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbsubs[i] = c_problem.nbsubs[i];
      }

      b_problem.resolutions.set_size(c_problem.resolutions.size(0));
      loop_ub = c_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resolutions[i] = c_problem.resolutions[i];
      }

      b_problem.allSubRough.set_size(c_problem.allSubRough.size(0));
      loop_ub = c_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.allSubRough[i] = c_problem.allSubRough[i];
      }

      b_problem.resample.set_size(1, c_problem.resample.size(1));
      loop_ub = c_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resample[i] = c_problem.resample[i];
      }

      problem->ssubs.set_size(b_problem.ssubs.size(0));
      loop_ub = b_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->ssubs[i] = b_problem.ssubs[i];
      }

      problem->backgrounds.set_size(b_problem.backgrounds.size(0));
      loop_ub = b_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->backgrounds[i] = b_problem.backgrounds[i];
      }

      problem->qshifts.set_size(b_problem.qshifts.size(0));
      loop_ub = b_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->qshifts[i] = b_problem.qshifts[i];
      }

      problem->scalefactors.set_size(b_problem.scalefactors.size(0));
      loop_ub = b_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->scalefactors[i] = b_problem.scalefactors[i];
      }

      problem->nbairs.set_size(b_problem.nbairs.size(0));
      loop_ub = b_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbairs[i] = b_problem.nbairs[i];
      }

      problem->nbsubs.set_size(b_problem.nbsubs.size(0));
      loop_ub = b_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbsubs[i] = b_problem.nbsubs[i];
      }

      problem->resolutions.set_size(b_problem.resolutions.size(0));
      loop_ub = b_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->resolutions[i] = b_problem.resolutions[i];
      }

      problem->calculations = c_problem.calculations;
      problem->allSubRough.set_size(b_problem.allSubRough.size(0));
      loop_ub = b_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->allSubRough[i] = b_problem.allSubRough[i];
      }

      problem->resample.set_size(1, b_problem.resample.size(1));
      loop_ub = b_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        problem->resample[problem->resample.size(0) * i] = b_problem.resample[i];
      }
      break;

     case 2:
      //  Custom SLD profile with user defined model file
      standardTF_custXY_reflectivityCalculation(problemDef->contrastBacks.data,
        problemDef->contrastBacksType.data, problemDef->dataPresent.data,
        problemDef->numberOfContrasts, problemDef->contrastShifts.data,
        problemDef->contrastScales.data, problemDef->contrastNbas.data,
        problemDef->contrastNbss.data, problemDef->contrastRes.data,
        problemDef->backs.data, problemDef->shifts.data, problemDef->sf.data,
        problemDef->nba.data, problemDef->nbs.data, problemDef->res.data,
        problemDef->params.size, problemDef_cells, controls, &c_problem,
        reflectivity, Simulation, shifted_data, layerSlds, sldProfiles,
        allLayers);
      b_problem.ssubs.set_size(c_problem.ssubs.size(0));
      loop_ub = c_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.ssubs[i] = c_problem.ssubs[i];
      }

      b_problem.backgrounds.set_size(c_problem.backgrounds.size(0));
      loop_ub = c_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.backgrounds[i] = c_problem.backgrounds[i];
      }

      b_problem.qshifts.set_size(c_problem.qshifts.size(0));
      loop_ub = c_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.qshifts[i] = c_problem.qshifts[i];
      }

      b_problem.scalefactors.set_size(c_problem.scalefactors.size(0));
      loop_ub = c_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.scalefactors[i] = c_problem.scalefactors[i];
      }

      b_problem.nbairs.set_size(c_problem.nbairs.size(0));
      loop_ub = c_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbairs[i] = c_problem.nbairs[i];
      }

      b_problem.nbsubs.set_size(c_problem.nbsubs.size(0));
      loop_ub = c_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.nbsubs[i] = c_problem.nbsubs[i];
      }

      b_problem.resolutions.set_size(c_problem.resolutions.size(0));
      loop_ub = c_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resolutions[i] = c_problem.resolutions[i];
      }

      b_problem.allSubRough.set_size(c_problem.allSubRough.size(0));
      loop_ub = c_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_problem.allSubRough[i] = c_problem.allSubRough[i];
      }

      b_problem.resample.set_size(1, c_problem.resample.size(1));
      loop_ub = c_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_problem.resample[i] = c_problem.resample[i];
      }

      problem->ssubs.set_size(b_problem.ssubs.size(0));
      loop_ub = b_problem.ssubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->ssubs[i] = b_problem.ssubs[i];
      }

      problem->backgrounds.set_size(b_problem.backgrounds.size(0));
      loop_ub = b_problem.backgrounds.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->backgrounds[i] = b_problem.backgrounds[i];
      }

      problem->qshifts.set_size(b_problem.qshifts.size(0));
      loop_ub = b_problem.qshifts.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->qshifts[i] = b_problem.qshifts[i];
      }

      problem->scalefactors.set_size(b_problem.scalefactors.size(0));
      loop_ub = b_problem.scalefactors.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->scalefactors[i] = b_problem.scalefactors[i];
      }

      problem->nbairs.set_size(b_problem.nbairs.size(0));
      loop_ub = b_problem.nbairs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbairs[i] = b_problem.nbairs[i];
      }

      problem->nbsubs.set_size(b_problem.nbsubs.size(0));
      loop_ub = b_problem.nbsubs.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->nbsubs[i] = b_problem.nbsubs[i];
      }

      problem->resolutions.set_size(b_problem.resolutions.size(0));
      loop_ub = b_problem.resolutions.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->resolutions[i] = b_problem.resolutions[i];
      }

      problem->calculations = c_problem.calculations;
      problem->allSubRough.set_size(b_problem.allSubRough.size(0));
      loop_ub = b_problem.allSubRough.size(0);
      for (i = 0; i < loop_ub; i++) {
        problem->allSubRough[i] = b_problem.allSubRough[i];
      }

      problem->resample.set_size(1, b_problem.resample.size(1));
      loop_ub = b_problem.resample.size(1);
      for (i = 0; i < loop_ub; i++) {
        problem->resample[problem->resample.size(0) * i] = b_problem.resample[i];
      }
      break;
    }
  }
}

// End of code generation (standardTF_reflectivityCalculation.cpp)

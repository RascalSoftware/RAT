//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_stanLay_reflectivityCalculation.cpp
//
// Code generation for function 'standardTF_stanLay_reflectivityCalculation'
//

// Include files
#include "standardTF_stanLay_reflectivityCalculation.h"
#include "blockedSummation.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_stanlay_paraContrasts.h"
#include "standardTF_stanlay_paraPoints.h"
#include "standardTF_stanlay_single.h"
#include "strcmp.h"
#include "coder_array.h"

// Function Definitions
//
// function
// [problem,reflectivity,Simulation,shifted_data,layerSlds,sldProfiles,allLayers]
// =
// standardTF_stanLay_reflectivityCalculation(problemDef,problemDef_cells,problemDef_limits,controls)
namespace RAT {
void standardTF_stanLay_reflectivityCalculation(
    const struct0_T *problemDef, const cell_16 *problemDef_cells,
    const struct2_T *controls, struct_T *problem,
    ::coder::array<cell_wrap_9, 1U> &reflectivity,
    ::coder::array<cell_wrap_9, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_14, 1U> &allLayers)
{
  double y;
  int i;
  int loop_ub_tmp;
  //  Standard layers reflectivity calculation for standardTF
  //  This function decides on parallelisation options before calling the
  //  relevant version ofthe main standard layers calculation. Parallelisation
  //  is either over the outer loop ('contrasts'), or the inner loop
  //  ('points'). The easiest way to do this is to have multiple versions of
  //  the same core calculation, rather than trying to make the paralell
  //  for loops conditional (although that would be much neater) There are:
  //  points    - parallelise over points in the reflectivity calculation
  //  contrasts - parallelise over contrasts (outer for loop)
  //  Pre-allocation - It's necessary to
  //  pre-define the types for all the arrays
  //  for compilation, so do this in this block.
  // 'standardTF_stanLay_reflectivityCalculation:17' numberOfContrasts =
  // problemDef.numberOfContrasts;
  // 'standardTF_stanLay_reflectivityCalculation:18' outSsubs =
  // zeros(numberOfContrasts,1);
  loop_ub_tmp = static_cast<int>(problemDef->numberOfContrasts);
  problem->ssubs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->ssubs[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:19' backgs =
  // zeros(numberOfContrasts,1);
  problem->backgrounds.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->backgrounds[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:20' qshifts =
  // zeros(numberOfContrasts,1);
  problem->qshifts.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->qshifts[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:21' sfs =
  // zeros(numberOfContrasts,1);
  problem->scalefactors.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->scalefactors[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:22' nbas =
  // zeros(numberOfContrasts,1);
  problem->nbairs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->nbairs[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:23' nbss =
  // zeros(numberOfContrasts,1);
  problem->nbsubs.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->nbsubs[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:24' chis =
  // zeros(numberOfContrasts,1);
  problem->calculations.all_chis.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->calculations.all_chis[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:25' resols =
  // zeros(numberOfContrasts,1);
  problem->resolutions.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->resolutions[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:26' allRoughs =
  // zeros(numberOfContrasts,1);
  problem->allSubRough.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->allSubRough[i] = 0.0;
  }
  // 'standardTF_stanLay_reflectivityCalculation:28' reflectivity =
  // cell(numberOfContrasts,1); 'standardTF_stanLay_reflectivityCalculation:29'
  // for i = 1:numberOfContrasts
  reflectivity.set_size(loop_ub_tmp);
  // 'standardTF_stanLay_reflectivityCalculation:33' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_stanLay_reflectivityCalculation:34'
  // for i = 1:numberOfContrasts
  Simulation.set_size(loop_ub_tmp);
  // 'standardTF_stanLay_reflectivityCalculation:38' shifted_data =
  // cell(numberOfContrasts,1); 'standardTF_stanLay_reflectivityCalculation:39'
  // for i = 1:numberOfContrasts
  shifted_data.set_size(loop_ub_tmp);
  // 'standardTF_stanLay_reflectivityCalculation:43' layerSlds =
  // cell(numberOfContrasts,1); 'standardTF_stanLay_reflectivityCalculation:44'
  // for i = 1:numberOfContrasts
  layerSlds.set_size(loop_ub_tmp);
  // 'standardTF_stanLay_reflectivityCalculation:48' sldProfiles =
  // cell(numberOfContrasts,1); 'standardTF_stanLay_reflectivityCalculation:49'
  // for i = 1:numberOfContrasts
  sldProfiles.set_size(loop_ub_tmp);
  // 'standardTF_stanLay_reflectivityCalculation:53' allLayers =
  // cell(numberOfContrasts,1); 'standardTF_stanLay_reflectivityCalculation:54'
  // for i = 1:numberOfContrasts
  allLayers.set_size(loop_ub_tmp);
  for (int b_i{0}; b_i < loop_ub_tmp; b_i++) {
    // 'standardTF_stanLay_reflectivityCalculation:30' reflectivity{i} = [1 1 ;
    // 1 1];
    reflectivity[b_i].f1.set_size(2, 2);
    reflectivity[b_i].f1[0] = 1.0;
    reflectivity[b_i].f1[1] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0)] = 1.0;
    reflectivity[b_i].f1[reflectivity[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_stanLay_reflectivityCalculation:35' Simulation{i} = [1 1 ; 1
    // 1];
    Simulation[b_i].f1.set_size(2, 2);
    Simulation[b_i].f1[0] = 1.0;
    Simulation[b_i].f1[1] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0)] = 1.0;
    Simulation[b_i].f1[Simulation[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_stanLay_reflectivityCalculation:40' shifted_data{i} = [1 1 1;
    // 1 1 1];
    shifted_data[b_i].f1.set_size(2, 3);
    // 'standardTF_stanLay_reflectivityCalculation:45' layerSlds{i} = [1 1 1; 1
    // 1 1];
    layerSlds[b_i].f1.set_size(2, 3);
    // 'standardTF_stanLay_reflectivityCalculation:50' sldProfiles{i} = [1 1; 1
    // 1];
    sldProfiles[b_i].f1.set_size(2, 2);
    sldProfiles[b_i].f1[0] = 1.0;
    sldProfiles[b_i].f1[1] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0)] = 1.0;
    sldProfiles[b_i].f1[sldProfiles[b_i].f1.size(0) + 1] = 1.0;
    // 'standardTF_stanLay_reflectivityCalculation:55' allLayers{i} = [1 1 1; 1
    // 1 1];
    allLayers[b_i].f1.set_size(2, 3);
    for (i = 0; i < 3; i++) {
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i] = 1.0;
      shifted_data[b_i].f1[shifted_data[b_i].f1.size(0) * i + 1] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i] = 1.0;
      layerSlds[b_i].f1[layerSlds[b_i].f1.size(0) * i + 1] = 1.0;
      allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i] = 1.0;
      allLayers[b_i].f1[allLayers[b_i].f1.size(0) * i + 1] = 1.0;
    }
  }
  //  ------- End type definitions -------------
  // 'standardTF_stanLay_reflectivityCalculation:60' para = controls.para;
  // 'standardTF_stanLay_reflectivityCalculation:62' switch para
  if (coder::internal::f_strcmp(controls->para)) {
    loop_ub_tmp = 0;
  } else if (coder::internal::g_strcmp(controls->para)) {
    loop_ub_tmp = 1;
  } else if (coder::internal::h_strcmp(controls->para)) {
    loop_ub_tmp = 2;
  } else {
    loop_ub_tmp = -1;
  }
  switch (loop_ub_tmp) {
  case 0:
    // 'standardTF_stanLay_reflectivityCalculation:63' case 'single'
    // 'standardTF_stanLay_reflectivityCalculation:64'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_stanLay_reflectivityCalculation:65'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_stanLay_reflectivityCalculation:66'              allRoughs] =
    // standardTF_stanlay_single(problemDef,problemDef_cells,...
    // 'standardTF_stanLay_reflectivityCalculation:67'
    // problemDef_limits,controls);
    standardTF_stanlay_single(
        problemDef, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  case 1:
    // 'standardTF_stanLay_reflectivityCalculation:69' case 'points'
    // 'standardTF_stanLay_reflectivityCalculation:70'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_stanLay_reflectivityCalculation:71'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_stanLay_reflectivityCalculation:72'              allRoughs] =
    // standardTF_stanlay_paraPoints(problemDef,problemDef_cells,...
    // 'standardTF_stanLay_reflectivityCalculation:73'
    // problemDef_limits,controls);
    standardTF_stanlay_paraPoints(
        problemDef, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  case 2:
    // 'standardTF_stanLay_reflectivityCalculation:75' case 'contrasts'
    // 'standardTF_stanLay_reflectivityCalculation:76'
    // [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
    // 'standardTF_stanLay_reflectivityCalculation:77'
    // Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
    // 'standardTF_stanLay_reflectivityCalculation:78'              allRoughs] =
    // standardTF_stanlay_paraContrasts(problemDef,problemDef_cells,...
    // 'standardTF_stanLay_reflectivityCalculation:79'
    // problemDef_limits,controls);
    standardTF_stanlay_paraContrasts(
        problemDef, problemDef_cells, controls, problem->ssubs,
        problem->backgrounds, problem->qshifts, problem->scalefactors,
        problem->nbairs, problem->nbsubs, problem->resolutions,
        problem->calculations.all_chis, reflectivity, Simulation, shifted_data,
        layerSlds, sldProfiles, allLayers, problem->allSubRough);
    break;
  }
  //  Package everything into one array for tidy output
  // 'standardTF_stanLay_reflectivityCalculation:83' problem.ssubs = outSsubs;
  // 'standardTF_stanLay_reflectivityCalculation:84' problem.backgrounds =
  // backgs; 'standardTF_stanLay_reflectivityCalculation:85' problem.qshifts =
  // qshifts; 'standardTF_stanLay_reflectivityCalculation:86'
  // problem.scalefactors = sfs; 'standardTF_stanLay_reflectivityCalculation:87'
  // problem.nbairs = nbas; 'standardTF_stanLay_reflectivityCalculation:88'
  // problem.nbsubs = nbss; 'standardTF_stanLay_reflectivityCalculation:89'
  // problem.resolutions = resols;
  // 'standardTF_stanLay_reflectivityCalculation:90'
  // problem.calculations.all_chis = chis;
  // 'standardTF_stanLay_reflectivityCalculation:91'
  // problem.calculations.sum_chi = sum(chis);
  if (problem->calculations.all_chis.size(0) == 0) {
    y = 0.0;
  } else {
    y = coder::nestedIter(problem->calculations.all_chis,
                          problem->calculations.all_chis.size(0));
  }
  problem->calculations.sum_chi = y;
  // 'standardTF_stanLay_reflectivityCalculation:92' problem.allSubRough =
  // allRoughs; 'standardTF_stanLay_reflectivityCalculation:93' problem.resample
  // = problemDef.resample;
  problem->resample.set_size(1, problemDef->resample.size(1));
  loop_ub_tmp = problemDef->resample.size(1);
  for (i = 0; i < loop_ub_tmp; i++) {
    problem->resample[i] = problemDef->resample[i];
  }
}

} // namespace RAT

// End of code generation (standardTF_stanLay_reflectivityCalculation.cpp)

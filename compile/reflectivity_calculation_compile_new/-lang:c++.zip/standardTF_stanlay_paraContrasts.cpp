//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// standardTF_stanlay_paraContrasts.cpp
//
// Code generation for function 'standardTF_stanlay_paraContrasts'
//

// Include files
#include "standardTF_stanlay_paraContrasts.h"
#include "allocateLayersForContrast.h"
#include "allocateParamsToLayers.h"
#include "backSort.h"
#include "reflectivity_calculation_internal_types.h"
#include "reflectivity_calculation_types.h"
#include "rt_nonfinite.h"
#include "standardTF_layers_core.h"
#include "coder_array.h"

// Function Definitions
//
// function [outSsubs,backgs,qshifts,sfs,nbas,nbss,resols,chis,reflectivity,...
//     Simulation,shifted_data,layerSlds,sldProfiles,allLayers,...
//     allRoughs] =
//     standardTF_stanlay_paraContrasts(problemDef,problemDef_cells,...
//     problemDef_limits,controls)
namespace RAT {
void standardTF_stanlay_paraContrasts(
    const struct0_T *problemDef, const cell_16 *problemDef_cells,
    const struct2_T *controls, ::coder::array<double, 1U> &outSsubs,
    ::coder::array<double, 1U> &backgs, ::coder::array<double, 1U> &qshifts,
    ::coder::array<double, 1U> &sfs, ::coder::array<double, 1U> &nbas,
    ::coder::array<double, 1U> &nbss, ::coder::array<double, 1U> &resols,
    ::coder::array<double, 1U> &chis,
    ::coder::array<cell_wrap_9, 1U> &reflectivity,
    ::coder::array<cell_wrap_9, 1U> &Simulation,
    ::coder::array<cell_wrap_14, 1U> &shifted_data,
    ::coder::array<cell_wrap_10, 1U> &layerSlds,
    ::coder::array<cell_wrap_14, 1U> &sldProfiles,
    ::coder::array<cell_wrap_14, 1U> &allLayers,
    ::coder::array<double, 1U> &allRoughs)
{
  ::coder::array<cell_wrap_17, 2U> outParameterisedLayers;
  ::coder::array<double, 2U> Simul;
  ::coder::array<double, 2U> layerSld;
  ::coder::array<double, 2U> reflect;
  ::coder::array<double, 2U> resampledLayers;
  ::coder::array<double, 2U> shifted_dat;
  ::coder::array<double, 2U> sldProfile;
  ::coder::array<double, 2U> thisContrastLayers;
  double calcSld;
  double thisBackground;
  double thisChiSquared;
  double thisNba;
  double thisNbs;
  double thisQshift;
  double thisResol;
  double thisSf;
  double thisSsubs;
  int b_i;
  int b_loop_ub;
  int c_loop_ub;
  int i;
  int i1;
  int loop_ub;
  int nParams;
  int ub_loop;
  //  Standard Layers calculation paralelised over the outer loop
  //  This is the main reflectivity calculation of the standard layers
  //  calculation type. It extracts the required paramters for the contrasts
  //  from the input arrays, then passes the main calculation to
  //  'standardLayersCore', which carries out the calculation iteslf.
  //  The core calculation is common for both standard and custom layers.
  //  Extract individual cell arrays
  // 'standardTF_stanlay_paraContrasts:14' [repeatLayers,...
  // 'standardTF_stanlay_paraContrasts:15'  allData,...
  // 'standardTF_stanlay_paraContrasts:16'  dataLimits,...
  // 'standardTF_stanlay_paraContrasts:17'  simLimits,...
  // 'standardTF_stanlay_paraContrasts:18'  contrastLayers,...
  // 'standardTF_stanlay_paraContrasts:19'  layersDetails...
  // 'standardTF_stanlay_paraContrasts:20'  customFiles] =
  // RAT_parse_cells(problemDef_cells);
  //  Splits up the master input list of all arrays into separate arrays
  //  The min input array 'problemDef_cells' is a master array where
  //  all the cell arrays are grouped together. There are
  //  repeatLayers      - controls repeating of the layers stack
  //  allData           - Array of all the data arrays
  //  dataLimits        - Min max limits in q for the data arrays
  //  simLimits         - Limits in Q for the reflkectivity simulations
  //  Layers details    - Master array of all available layers
  //  contrastLayers    - Which specific combination of arrays are needed for
  //                      each contrast.
  //  Custom files      - Filenames and path for any custom files used
  // 'RAT_parse_cells:16' repeatLayers = problemDef_cells{1};
  // 'RAT_parse_cells:17' allData = problemDef_cells{2};
  // 'RAT_parse_cells:18' dataLimits = problemDef_cells{3};
  // 'RAT_parse_cells:19' simLimits = problemDef_cells{4};
  // 'RAT_parse_cells:20' contrastLayers = problemDef_cells{5};
  // 'RAT_parse_cells:21' layersDetails = problemDef_cells{6};
  // 'RAT_parse_cells:22' customFiles = problemDef_cells{14};
  //  Extract individual parameters from problemDef struct
  // 'standardTF_stanlay_paraContrasts:23' [numberOfContrasts, geometry, cBacks,
  // cShifts, cScales, cNbas, cNbss,... 'standardTF_stanlay_paraContrasts:24'
  // cRes, backs, shifts, sf, nba, nbs, res, dataPresent, nParams, params,...
  // 'standardTF_stanlay_paraContrasts:25' numberOfLayers, resample, backsType,
  // cCustFiles] =  extractProblemParams(problemDef); Extract individual
  // parameters from problemDef 'extractProblemParams:7' numberOfContrasts =
  // problemDef.numberOfContrasts; 'extractProblemParams:8' geometry =
  // problemDef.geometry; 'extractProblemParams:9' cBacks =
  // problemDef.contrastBacks; 'extractProblemParams:10' cShifts =
  // problemDef.contrastShifts; 'extractProblemParams:11' cScales =
  // problemDef.contrastScales; 'extractProblemParams:12' cNbas =
  // problemDef.contrastNbas; 'extractProblemParams:13' cNbss =
  // problemDef.contrastNbss; 'extractProblemParams:14' cRes =
  // problemDef.contrastRes; 'extractProblemParams:15' backs = problemDef.backs;
  // 'extractProblemParams:16' shifts = problemDef.shifts;
  // 'extractProblemParams:17' sf = problemDef.sf;
  // 'extractProblemParams:18' nba = problemDef.nba;
  // 'extractProblemParams:19' nbs = problemDef.nbs;
  // 'extractProblemParams:20' res = problemDef.res;
  // 'extractProblemParams:21' dataPresent = problemDef.dataPresent;
  // 'extractProblemParams:22' nParams = length(problemDef.params);
  nParams = problemDef->params.size(1);
  // 'extractProblemParams:23' params = problemDef.params;
  // 'extractProblemParams:24' numberOfLayers = problemDef.numberOfLayers;
  // 'extractProblemParams:25' resample = problemDef.resample;
  // 'extractProblemParams:26' backsType = problemDef.contrastBacksType;
  // 'extractProblemParams:27' cFiles = problemDef.contrastCustomFiles;
  // 'standardTF_stanlay_paraContrasts:27' calcSld = controls.calcSld;
  calcSld = controls->calcSld;
  //  Allocate the memory for the output arrays before the main loop
  // 'standardTF_stanlay_paraContrasts:30' backgs = zeros(numberOfContrasts,1);
  backgs.set_size(static_cast<int>(problemDef->numberOfContrasts));
  // 'standardTF_stanlay_paraContrasts:31' qshifts = zeros(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:32' sfs = zeros(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:33' nbas = zeros(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:34' nbss = zeros(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:35' resols = zeros(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:36' allRoughs =
  // zeros(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:37' outSsubs
  // = zeros(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:38' chis =
  // zeros(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:39' layerSlds
  // = cell(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:40'
  // sldProfiles = cell(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:41' shifted_data =
  // cell(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:43'
  // reflectivity = cell(numberOfContrasts,1);
  // 'standardTF_stanlay_paraContrasts:44' for i = 1:numberOfContrasts
  // 'standardTF_stanlay_paraContrasts:48' Simulation =
  // cell(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:49' for i =
  // 1:numberOfContrasts 'standardTF_stanlay_paraContrasts:53' allLayers =
  // cell(numberOfContrasts,1); 'standardTF_stanlay_paraContrasts:54' for i =
  // 1:numberOfContrasts
  //  end memory allocation.
  //  First we need to allocate the absolute values of the input
  //  parameters to all the layers in the layers list. This only needs
  //  to be done once, and so is done outside the contrasts loop
  // 'standardTF_stanlay_paraContrasts:63' outParameterisedLayers =
  // allocateParamsToLayers(params, layersDetails);
  allocateParamsToLayers(problemDef->params, problemDef_cells->f6,
                         outParameterisedLayers);
  //  Resample parameters is required
  // 'standardTF_stanlay_paraContrasts:66' resamPars = controls.resamPars;
  //  Parallel loop over all the contrasts
  // 'standardTF_stanlay_paraContrasts:69' parfor i = 1:numberOfContrasts
  outSsubs.set_size(static_cast<int>(problemDef->numberOfContrasts));
  sldProfiles.set_size(static_cast<int>(problemDef->numberOfContrasts));
  reflectivity.set_size(static_cast<int>(problemDef->numberOfContrasts));
  Simulation.set_size(static_cast<int>(problemDef->numberOfContrasts));
  shifted_data.set_size(static_cast<int>(problemDef->numberOfContrasts));
  layerSlds.set_size(static_cast<int>(problemDef->numberOfContrasts));
  chis.set_size(static_cast<int>(problemDef->numberOfContrasts));
  qshifts.set_size(static_cast<int>(problemDef->numberOfContrasts));
  sfs.set_size(static_cast<int>(problemDef->numberOfContrasts));
  nbas.set_size(static_cast<int>(problemDef->numberOfContrasts));
  nbss.set_size(static_cast<int>(problemDef->numberOfContrasts));
  resols.set_size(static_cast<int>(problemDef->numberOfContrasts));
  allRoughs.set_size(static_cast<int>(problemDef->numberOfContrasts));
  allLayers.set_size(static_cast<int>(problemDef->numberOfContrasts));
  ub_loop = static_cast<int>(problemDef->numberOfContrasts) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
    thisContrastLayers, sldProfile, reflect, Simul, shifted_dat, layerSld,     \
    resampledLayers, thisSsubs, thisChiSquared, thisResol, thisNbs, thisNba,   \
    thisSf, thisQshift, thisBackground, i, loop_ub, b_loop_ub, c_loop_ub, b_i, \
    i1)

  for (i = 0; i <= ub_loop; i++) {
    //  Extract the relevant parameter values for this contrast
    //  from the input arrays.
    //  First need to decide which values of the backrounds, scalefactors
    //  data shifts and bulk contrasts are associated with this contrast
    // 'standardTF_stanlay_paraContrasts:75'
    // [thisBackground,thisQshift,thisSf,thisNba,thisNbs,thisResol] =
    // backSort(cBacks(i),cShifts(i),cScales(i),cNbas(i),cNbss(i),cRes(i),backs,shifts,sf,nba,nbs,res);
    backSort(problemDef->contrastBacks[i], problemDef->contrastShifts[i],
             problemDef->contrastScales[i], problemDef->contrastNbas[i],
             problemDef->contrastNbss[i], problemDef->contrastRes[i],
             problemDef->backs, problemDef->shifts, problemDef->sf,
             problemDef->nba, problemDef->nbs, problemDef->res, &thisBackground,
             &thisQshift, &thisSf, &thisNba, &thisNbs, &thisResol);
    //  Also need to determine which layers from the overall layers list
    //  are required for this contrast, and put them in the correct order
    //  according to geometry
    // 'standardTF_stanlay_paraContrasts:80' thisContrastLayers =
    // allocateLayersForContrast(contrastLayers{i},outParameterisedLayers);
    allocateLayersForContrast(problemDef_cells->f5[i].f1,
                              outParameterisedLayers, thisContrastLayers);
    //  For the other parameters, we extract the correct ones from the input
    //  arrays
    // 'standardTF_stanlay_paraContrasts:84' thisRough = params(1);
    //  Substrate roughness is always first parameter for standard layers
    // 'standardTF_stanlay_paraContrasts:85' thisRepeatLayers = repeatLayers{i};
    // 'standardTF_stanlay_paraContrasts:86' thisResample = resample(i);
    // 'standardTF_stanlay_paraContrasts:87' thisCalcSld = calcSld;
    // 'standardTF_stanlay_paraContrasts:88' thisData = allData{i};
    // 'standardTF_stanlay_paraContrasts:89' thisDataPresent = dataPresent(i);
    // 'standardTF_stanlay_paraContrasts:90' thisDataLimits = dataLimits{i};
    // 'standardTF_stanlay_paraContrasts:91' thisSimLimits = simLimits{i};
    // 'standardTF_stanlay_paraContrasts:92' thisBacksType = backsType(i);
    //  Now call the core standardTF_stanlay reflectivity calculation
    //  In this case we are single cored, so we do not parallelise over
    //  points
    // 'standardTF_stanlay_paraContrasts:97' paralellPoints = 'single';
    //  Call the core layers calculation
    // 'standardTF_stanlay_paraContrasts:100'
    // [sldProfile,reflect,Simul,shifted_dat,layerSld,resampledLayers,...
    // 'standardTF_stanlay_paraContrasts:101'         thisChiSquared,thisSsubs]
    // = standardTF_layers_core(thisContrastLayers, thisRough, ...
    // 'standardTF_stanlay_paraContrasts:102'     geometry, thisNba, thisNbs,
    // thisResample, thisCalcSld, thisSf, thisQshift,...
    // 'standardTF_stanlay_paraContrasts:103'     thisDataPresent, thisData,
    // thisDataLimits, thisSimLimits, thisRepeatLayers,...
    // 'standardTF_stanlay_paraContrasts:104'
    // thisBackground,thisResol,thisBacksType,nParams,paralellPoints,resamPars);
    standardTF_layers_core(
        thisContrastLayers, problemDef->params[0], problemDef->geometry,
        thisNba, thisNbs, problemDef->resample[i], calcSld, thisSf, thisQshift,
        problemDef->dataPresent[i], problemDef_cells->f2[i].f1,
        problemDef_cells->f3[i].f1,
        (double *)((::coder::array<double, 2U> *)&problemDef_cells->f4[i].f1)
            ->data(),
        problemDef_cells->f1[i].f1, thisBackground, thisResol,
        problemDef->contrastBacksType[i], static_cast<double>(nParams),
        controls->resamPars, sldProfile, reflect, Simul, shifted_dat, layerSld,
        resampledLayers, &thisChiSquared, &thisSsubs);
    //  Store returned values for this contrast in the output arrays.
    //  As well as the calculated profiles, we also store a record of
    //  the other values (background, scalefactors etc) for each contrast
    //  for future use.
    // 'standardTF_stanlay_paraContrasts:110' outSsubs(i) = thisSsubs;
    outSsubs[i] = thisSsubs;
    // 'standardTF_stanlay_paraContrasts:111' sldProfiles{i} = sldProfile;
    loop_ub = sldProfile.size(0);
    sldProfiles[i].f1.set_size(sldProfile.size(0), 2);
    // 'standardTF_stanlay_paraContrasts:112' reflectivity{i} = reflect;
    b_loop_ub = reflect.size(0);
    reflectivity[i].f1.set_size(reflect.size(0), 2);
    // 'standardTF_stanlay_paraContrasts:113' Simulation{i} = Simul;
    c_loop_ub = Simul.size(0);
    Simulation[i].f1.set_size(Simul.size(0), 2);
    for (b_i = 0; b_i < 2; b_i++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        sldProfiles[i].f1[i1 + sldProfiles[i].f1.size(0) * b_i] =
            sldProfile[i1 + sldProfile.size(0) * b_i];
      }
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        reflectivity[i].f1[i1 + reflectivity[i].f1.size(0) * b_i] =
            reflect[i1 + reflect.size(0) * b_i];
      }
      for (i1 = 0; i1 < c_loop_ub; i1++) {
        Simulation[i].f1[i1 + Simulation[i].f1.size(0) * b_i] =
            Simul[i1 + Simul.size(0) * b_i];
      }
    }
    // 'standardTF_stanlay_paraContrasts:114' shifted_data{i} = shifted_dat;
    loop_ub = shifted_dat.size(1);
    shifted_data[i].f1.set_size(shifted_dat.size(0), shifted_dat.size(1));
    for (b_i = 0; b_i < loop_ub; b_i++) {
      b_loop_ub = shifted_dat.size(0);
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        shifted_data[i].f1[i1 + shifted_data[i].f1.size(0) * b_i] =
            shifted_dat[i1 + shifted_dat.size(0) * b_i];
      }
    }
    // 'standardTF_stanlay_paraContrasts:115' layerSlds{i} = layerSld;
    loop_ub = layerSld.size(0);
    layerSlds[i].f1.set_size(layerSld.size(0), 3);
    // 'standardTF_stanlay_paraContrasts:116' chis(i) = thisChiSquared;
    chis[i] = thisChiSquared;
    // 'standardTF_stanlay_paraContrasts:117' backgs(i) = thisBackground;
    backgs[i] = thisBackground;
    // 'standardTF_stanlay_paraContrasts:118' qshifts(i) = thisQshift;
    qshifts[i] = thisQshift;
    // 'standardTF_stanlay_paraContrasts:119' sfs(i) = thisSf;
    sfs[i] = thisSf;
    // 'standardTF_stanlay_paraContrasts:120' nbas(i) = thisNba;
    nbas[i] = thisNba;
    // 'standardTF_stanlay_paraContrasts:121' nbss(i) = thisNbs;
    nbss[i] = thisNbs;
    // 'standardTF_stanlay_paraContrasts:122' resols(i) = thisResol;
    resols[i] = thisResol;
    // 'standardTF_stanlay_paraContrasts:123' allRoughs(i) = thisRough;
    allRoughs[i] = problemDef->params[0];
    // 'standardTF_stanlay_paraContrasts:124' allLayers{i} = resampledLayers;
    b_loop_ub = resampledLayers.size(0);
    allLayers[i].f1.set_size(resampledLayers.size(0), 3);
    for (b_i = 0; b_i < 3; b_i++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        layerSlds[i].f1[i1 + layerSlds[i].f1.size(0) * b_i] =
            layerSld[i1 + layerSld.size(0) * b_i];
      }
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        allLayers[i].f1[i1 + allLayers[i].f1.size(0) * b_i] =
            resampledLayers[i1 + resampledLayers.size(0) * b_i];
      }
    }
  }
}

} // namespace RAT

// End of code generation (standardTF_stanlay_paraContrasts.cpp)

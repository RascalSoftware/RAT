//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abs.h
//
// Code generation for function 'abs'
//

#ifndef ABS_H
#define ABS_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
real_T b_abs(real_T x);

}

#endif
// End of code generation (abs.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abs1.cpp
//
// Code generation for function 'abs1'
//

// Include files
#include "abs1.h"
#include "rt_nonfinite.h"
#include <cmath>

// Function Definitions
//
//
namespace coder {
namespace internal {
namespace scalar {
real_T c_abs(real_T x)
{
  return std::abs(x);
}

} // namespace scalar
} // namespace internal
} // namespace coder

// End of code generation (abs1.cpp)

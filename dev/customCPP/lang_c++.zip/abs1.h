//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abs1.h
//
// Code generation for function 'abs1'
//

#ifndef ABS1_H
#define ABS1_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace scalar {
real_T c_abs(real_T x);

}
} // namespace internal
} // namespace coder

#endif
// End of code generation (abs1.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// exp1.h
//
// Code generation for function 'exp1'
//

#ifndef EXP1_H
#define EXP1_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace scalar {
void d_exp(real_T *x);

}
} // namespace internal
} // namespace coder

#endif
// End of code generation (exp1.h)

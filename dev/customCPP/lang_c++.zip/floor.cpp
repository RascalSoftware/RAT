//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// floor.cpp
//
// Code generation for function 'floor'
//

// Include files
#include "floor.h"
#include "floor1.h"
#include "rt_nonfinite.h"

// Function Definitions
//
//
namespace coder {
void b_floor(real_T *x)
{
  internal::scalar::c_floor(x);
}

} // namespace coder

// End of code generation (floor.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// floor1.h
//
// Code generation for function 'floor1'
//

#ifndef FLOOR1_H
#define FLOOR1_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace scalar {
void c_floor(real_T *x);

}
} // namespace internal
} // namespace coder

#endif
// End of code generation (floor1.h)

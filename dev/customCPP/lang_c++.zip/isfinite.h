//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// isfinite.h
//
// Code generation for function 'isfinite'
//

#ifndef ISFINITE_H
#define ISFINITE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
boolean_T b_isfinite(real_T x);

}

#endif
// End of code generation (isfinite.h)

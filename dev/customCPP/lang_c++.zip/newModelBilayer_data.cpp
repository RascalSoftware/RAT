//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_data.cpp
//
// Code generation for function 'newModelBilayer_data'
//

// Include files
#include "newModelBilayer_data.h"
#include "rt_nonfinite.h"

// End of code generation (newModelBilayer_data.cpp)

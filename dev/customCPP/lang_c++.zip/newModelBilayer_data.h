//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_data.h
//
// Code generation for function 'newModelBilayer_data'
//

#ifndef NEWMODELBILAYER_DATA_H
#define NEWMODELBILAYER_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
// End of code generation (newModelBilayer_data.h)

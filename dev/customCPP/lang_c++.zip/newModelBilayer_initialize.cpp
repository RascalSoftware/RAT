//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_initialize.cpp
//
// Code generation for function 'newModelBilayer_initialize'
//

// Include files
#include "newModelBilayer_initialize.h"
#include "rt_nonfinite.h"

// Function Definitions
void newModelBilayer_initialize()
{
}

// End of code generation (newModelBilayer_initialize.cpp)

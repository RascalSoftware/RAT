//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_initialize.h
//
// Code generation for function 'newModelBilayer_initialize'
//

#ifndef NEWMODELBILAYER_INITIALIZE_H
#define NEWMODELBILAYER_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void newModelBilayer_initialize();

#endif
// End of code generation (newModelBilayer_initialize.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_rtwutil.h
//
// Code generation for function 'newModelBilayer_rtwutil'
//

#ifndef NEWMODELBILAYER_RTWUTIL_H
#define NEWMODELBILAYER_RTWUTIL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern real_T rt_powd_snf(real_T u0, real_T u1);

#endif
// End of code generation (newModelBilayer_rtwutil.h)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_terminate.cpp
//
// Code generation for function 'newModelBilayer_terminate'
//

// Include files
#include "newModelBilayer_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
void newModelBilayer_terminate()
{
  // (no terminate code required)
}

// End of code generation (newModelBilayer_terminate.cpp)

//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// newModelBilayer_terminate.h
//
// Code generation for function 'newModelBilayer_terminate'
//

#ifndef NEWMODELBILAYER_TERMINATE_H
#define NEWMODELBILAYER_TERMINATE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void newModelBilayer_terminate();

#endif
// End of code generation (newModelBilayer_terminate.h)

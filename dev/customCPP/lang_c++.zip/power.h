//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// power.h
//
// Code generation for function 'power'
//

#ifndef POWER_H
#define POWER_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void power(const real_T a[200], real_T y[200]);

}

#endif
// End of code generation (power.h)

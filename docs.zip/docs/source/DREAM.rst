.. _DREAM:

Bayesian Analysis - DREAM
.........................

The main Bayesian Sampler bundled with RAT is an implementation of the DREAM (DiffeRential Evolution Adaptive Metropolis)
algorithm first described by `Vrugt`_. 













.. _Vrugt: https://www.sciencedirect.com/science/article/abs/pii/S1364815215300396

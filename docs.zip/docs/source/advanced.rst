.. _advanced:

===============
Advanced Topics
===============
In this section we discuss some of the advanced features of the toolbox:-


.. toctree::
   :maxdepth: 2

   resampling
   parallelisation
   customLanguages
   events




.. _bayesPlot:


Bayesian Plotting Functions.
............................

TODO
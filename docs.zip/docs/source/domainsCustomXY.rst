.. _domainsCustomXY:


Custom XY Models with Domains
.............................

TODO
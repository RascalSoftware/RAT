.. _events:

Handling Events During Calculations
===================================


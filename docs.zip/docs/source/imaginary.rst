.. _imaginary:


Adding the Imaginary Refractive Index
.....................................

TODO



**Srandard Layers Models**
++++++++++++++++++++++++++

**Custom Layers Models**
++++++++++++++++++++++++

**Custom XY Models**
++++++++++++++++++++
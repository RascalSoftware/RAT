.. _livePlot:


Live Updating Plots
...................

TODO
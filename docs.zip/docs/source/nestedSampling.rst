.. _nestedSampling:


Bayesian Model Selection - Nested Sampling
..........................................

TODO
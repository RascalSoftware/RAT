.. _oilWater


Reflectivity from Oil/Water Samples
...................................

.. note::
   Oil/Water has not been implemented in Release 1, and will be included
   in a later release of RAT.



=======
Support
=======

The easiest way to get help with the project is to start discussions or open an issue on 
Github_.

.. _Github: https://github.com/RascalSoftware/RAT





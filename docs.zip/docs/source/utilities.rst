.. _utilities:

=================
Utility Functions
=================

RAT has a number of utility functions that are provided to assist data analysis.
These are mainly plotting functions:-


.. toctree::
   :maxdepth: 2

   simplePlot
   bayesPlot
   livePlot
   conversionFuncs

=================
Utility Functions
=================
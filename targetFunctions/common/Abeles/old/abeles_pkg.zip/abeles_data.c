/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * abeles_data.c
 *
 * Code generation for function 'abeles_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "abeles.h"
#include "abeles_data.h"

/* Variable Definitions */
omp_nest_lock_t emlrtNestLockGlobal;

/* End of code generation (abeles_data.c) */

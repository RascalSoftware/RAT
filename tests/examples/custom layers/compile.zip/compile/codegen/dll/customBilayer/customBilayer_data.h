/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * customBilayer_data.h
 *
 * Code generation for function 'customBilayer_data'
 *
 */

#ifndef CUSTOMBILAYER_DATA_H
#define CUSTOMBILAYER_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/* End of code generation (customBilayer_data.h) */

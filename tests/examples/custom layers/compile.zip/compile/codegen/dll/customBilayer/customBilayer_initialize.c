/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * customBilayer_initialize.c
 *
 * Code generation for function 'customBilayer_initialize'
 *
 */

/* Include files */
#include "customBilayer_initialize.h"

/* Function Definitions */
void customBilayer_initialize(void)
{
}

/* End of code generation (customBilayer_initialize.c) */

/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * customBilayer_terminate.c
 *
 * Code generation for function 'customBilayer_terminate'
 *
 */

/* Include files */
#include "customBilayer_terminate.h"

/* Function Definitions */
void customBilayer_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (customBilayer_terminate.c) */

/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * _coder_customBilayer_info.h
 *
 * Code generation for function 'customBilayer'
 *
 */

#ifndef _CODER_CUSTOMBILAYER_INFO_H
#define _CODER_CUSTOMBILAYER_INFO_H

/* Include files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (_coder_customBilayer_info.h) */
